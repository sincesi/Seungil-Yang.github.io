"""
v2_fault_injection.py -- specification defects: what the direct evaluator does with them
on the full UCI Adult data, and the Alloy artifact file that exposes them.

For each specification variant (correct + 3 seeded defects) we
  (1) run exhaustive and pruned (Algorithm 1) search with the direct evaluator on
      full Adult (7-attribute lattice, Q1-Q4, same semantics as scale_adult_direct.py);
  (2) compare with the CORRECT specification's exhaustive result;
  (3) export the specification artifacts that the evaluator actually used
      (hierarchy maps per attribute and level; question label per label-relevant class)
      to an Alloy file with the validation obligations as checks.

Defects (all silent: the evaluator raises no error):
  D1  age bands anchored at 18 (18-22, 23-27, ...) below decades   -> not order-compatible
  D2  age levels listed in the wrong order (decade before 5-year)  -> not order-compatible
  D3  education-group dictionary with a mis-keyed category ("Some-College")
      -> map partial; pandas turns the gap into NaN, which factorize silently treats
         as one extra category in both the label and the released level.
Usage: python3 v2_fault_injection.py adult.data out_dir
"""
from __future__ import annotations
import itertools, json, sys, time, zlib
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parent))
from scale_adult_direct import load, WORKCLASS, EDU, MARITAL, OCC

ATTRS = ["age", "workclass", "education", "marital", "occupation", "sex", "country"]
QI = ["age", "workclass", "marital", "sex", "country"]

def code(s):
    return pd.factorize(pd.Series(s), use_na_sentinel=True)[0].astype(np.int64)

def spec(df, variant):
    a = df["age"].to_numpy(); z = np.zeros(len(df), np.int64)
    edu_map = dict(EDU)
    if variant == "D3":
        del edu_map["Some-college"]; edu_map["Some-College"] = "College"   # mis-keyed entry
    eg_raw = df["education"].map(edu_map)                                   # NaN for the gap
    if variant == "D1":
        age_lv = [a, (a - 18) // 5, a // 10, a // 20, z]
    elif variant == "D2":
        age_lv = [a, a // 10, a // 5, a // 20, z]
    else:
        age_lv = [a, a // 5, a // 10, a // 20, z]
    raw = {  # attribute -> list of (python-visible) level value arrays, finest first
      "age": age_lv,
      "workclass": [df["workclass"], df["workclass"].map(WORKCLASS), z],
      "education": [df["education"], eg_raw, z],
      "marital": [df["marital-status"], df["marital-status"].map(MARITAL), z],
      "occupation": [df["occupation"], df["occupation"].map(OCC), z],
      "sex": [df["sex"], z],
      "country": [df["native-country"], df["native-country"] == "United-States", z],
    }
    H = {k: [code(v) for v in lv] for k, lv in raw.items()}
    sex = code(df["sex"]); eg = code(eg_raw); ee = code(df["education"])
    mix = lambda *cs: code([tuple(t) for t in zip(*cs)])
    L = {"Q1": sex, "Q2": mix(sex, eg), "Q3": mix(sex, eg, a // 10), "Q4": mix(sex, ee, a // 5)}
    return raw, H, L, eg_raw

class Ev:
    def __init__(self, H, inc):
        self.H = H; self.inc = inc
        self.radix = [max(int(c.max()) + 2 for c in H[x]) for x in ATTRS]
        self.qi_idx = [i for i, x in enumerate(ATTRS) if x in QI]
    def key(self, p, idx):
        k = np.zeros(len(self.H["age"][0]), np.int64)
        for i in idx:
            k = k * self.radix[i] + (self.H[ATTRS[i]][p[i]] + 1)
        return k
    def useful(self, p, lab, nlab):
        t = self.key(p, range(len(ATTRS))) * 2 + self.inc     # income released verbatim
        return len(pd.unique(t)) == len(pd.unique(t * nlab + lab))
    def safe(self, p):
        _, c = np.unique(self.key(p, self.qi_idx), return_counts=True)
        return bool(c.min() >= 2)

def search(ev, lab):
    lab = lab - lab.min(); nlab = int(lab.max()) + 1
    dims = [len(ev.H[x]) for x in ATTRS]
    P = list(itertools.product(*[range(d) for d in dims]))
    U = {p: ev.useful(p, lab, nlab) for p in P}
    Sq = {}
    def safe(p):
        q = tuple(p[i] for i in ev.qi_idx)
        if q not in Sq: Sq[q] = ev.safe(p)
        return Sq[q]
    F = {p for p in P if U[p]}; A = {p for p in F if safe(p)}
    basis = []; Fp = set(); Ap = set(); calls = 0
    for p in P:
        if any(all(b[i] <= p[i] for i in range(len(p))) for b in basis): continue
        calls += 1
        if not U[p]: basis.append(p); continue
        Fp.add(p); calls += 1
        if safe(p): Ap.add(p)
    return dict(F=F, A=A, Fp=Fp, Ap=Ap, calls=calls, B=len(basis))

# ---------------- Alloy export of the artifacts the evaluator used ----------------
def alloy_artifacts(raw, df, eg_raw, name):
    lines = [f"module spec_{name}", "// Exported specification artifacts (values as the pipeline computed them).",
             "abstract sig Attr {}", "one sig " + ", ".join("a_" + a for a in ATTRS) + " extends Attr {}",
             "abstract sig Level {}", "one sig L0, L1, L2, L3, L4 extends Level {}",
             "fun nxt: Level -> Level { L0->L1 + L1->L2 + L2->L3 + L3->L4 }",
             "abstract sig Raw { attr: one Attr }", "abstract sig Img {}",
             "one sig H { map: Raw -> Level -> Img, levels: Attr -> Level }",
             "abstract sig Cls {}", "abstract sig Lab {}", "one sig Q { label: Cls -> Lab }"]
    raws, imgs, maptuples, lvtuples = [], set(), [], []
    for at in ATTRS:
        lv = raw[at]; base = pd.Series(lv[0]).astype(str).to_numpy()
        vals = sorted(set(base))
        for j in range(len(lv)): lvtuples.append(f"a_{at}->L{j}")
        for vi, v in enumerate(vals):
            rid = f"r_{at}_{vi}"; raws.append((rid, at))
            idx = np.nonzero(base == v)[0][0]
            for j in range(len(lv)):
                x = pd.Series(lv[j]).iloc[idx]
                if pd.isna(x): continue                      # partial map: no image exported
                iid = f"i_{at}_{j}_{zlib.crc32(str(x).encode()) % 10**8}"; imgs.add(iid)
                maptuples.append(f"{rid}->L{j}->{iid}")
            # consistency: every record with this raw value must have the same image
    lines.append("one sig " + ", ".join(r for r, _ in raws) + " extends Raw {}")
    lines.append("one sig " + ", ".join(sorted(imgs)) + " extends Img {}")
    lines.append("fact { " + " and ".join(f"{r}.attr = a_{a}" for r, a in raws) + " }")
    lines.append("fact { H.map = " + " + ".join(maptuples) + " }")
    lines.append("fact { H.levels = " + " + ".join(lvtuples) + " }")
    # label classes: distinct (sex, education, age) with the Q3 label as computed
    cls = df[["sex", "education", "age"]].astype(str).agg("|".join, axis=1).to_numpy()
    lab_val = [None if pd.isna(e) else f"{s}|{e}|{a//10}" for s, e, a in zip(df["sex"], eg_raw, df["age"])]
    seen = {}
    for c, l in zip(cls, lab_val): seen.setdefault(c, l)
    cids = {c: f"c{i}" for i, c in enumerate(seen)}; lids = {l: f"l{i}" for i, l in enumerate(sorted({l for l in seen.values() if l}))}
    lines.append("one sig " + ", ".join(cids.values()) + " extends Cls {}")
    lines.append("one sig " + ", ".join(lids.values()) + " extends Lab {}")
    lt = [f"{cids[c]}->{lids[l]}" for c, l in seen.items() if l]
    lines.append("fact { Q.label = " + " + ".join(lt) + " }")
    lines += [
      "// O1 totality: every raw value has exactly one image at every level of its attribute",
      "assert MapsTotal { all r: Raw, l: r.attr.(H.levels) | one H.map[r][l] }",
      "// O2 order compatibility: each level factors through the previous one",
      "assert OrderCompatible { all x, y: Raw, l: Level | (x.attr = y.attr and l.nxt in x.attr.(H.levels)",
      "   and some H.map[x][l] and H.map[x][l] = H.map[y][l]) implies H.map[x][l.nxt] = H.map[y][l.nxt] }",
      "// O3 the question label is a total function on label-relevant classes",
      "assert LabelTotal { all c: Cls | one Q.label[c] }",
      "check MapsTotal for 1", "check OrderCompatible for 1", "check LabelTotal for 1"]
    # Kodkod cannot index high-arity relations over large universes: use fields instead
    rep = [("abstract sig Attr {}", "abstract sig Attr { lv: set Level }"),
           ("abstract sig Raw { attr: one Attr }", "abstract sig Raw { attr: one Attr, img: Level -> Img }"),
           ("one sig H { map: Raw -> Level -> Img, levels: Attr -> Level }", "// img: Raw -> Level -> Img ; lv: Attr -> Level"),
           ("abstract sig Cls {}", "abstract sig Cls { lab: set Lab }"), ("one sig Q { label: Cls -> Lab }", "// lab: Cls -> Lab"),
           ("H.map", "img"), ("H.levels", "lv"), ("Q.label", "lab")]
    for a, b in rep: lines = [l.replace(a, b) for l in lines]
    # split: Kodkod cannot index arity-3 relations over the joint universe
    hier = [l for l in lines if not any(k in l for k in ("Cls", "Lab", "lab", "LabelTotal", "one sig c0", "one sig l0"))]
    labl = [l for l in lines if not any(k in l for k in ("Raw", "Img", "img", "lv", "Level", "nxt", "MapsTotal", "OrderCompatible", "Attr", "a_"))]
    hier[0] = f"module spec_{name}_hier"; labl[0] = f"module spec_{name}_label"
    return ("\n".join(hier) + "\n", "\n".join(labl) + "\n"), len(raws), len(maptuples), len(seen)

def main():
    src, out = Path(sys.argv[1]), Path(sys.argv[2]); out.mkdir(exist_ok=True)
    df = load(src)
    ref = {}
    res = []
    for variant in ["correct", "D1", "D2", "D3"]:
        raw, H, L, eg_raw = spec(df, variant)
        als, nr, nm, nc = alloy_artifacts(raw, df, eg_raw, variant)
        (out / f"spec_{variant}_hier.als").write_text(als[0]); (out / f"spec_{variant}_label.als").write_text(als[1])
        ev = Ev(H, code(df["income"]))
        for q in ["Q1", "Q2", "Q3", "Q4"]:
            t = time.perf_counter(); r = search(ev, L[q]); dt = time.perf_counter() - t
            if variant == "correct": ref[q] = r
            c = ref[q]
            row = {"variant": variant, "question": q, "|F| exh": len(r["F"]), "|F| pruned": len(r["Fp"]),
                   "|A| exh": len(r["A"]), "|A| pruned": len(r["Ap"]), "calls": r["calls"],
                   "pruned==exh": r["F"] == r["Fp"] and r["A"] == r["Ap"],
                   "useful missed by pruning": len(r["F"] - r["Fp"]), "accepted missed by pruning": len(r["A"] - r["Ap"]),
                   "|F| correct": len(c["F"]), "|A| correct": len(c["A"]),
                   "A_pruned==A_correct": r["Ap"] == c["A"],
                   "alloy_raw_atoms": nr, "alloy_map_tuples": nm, "alloy_classes": nc, "time_s": round(dt, 1)}
            res.append(row); print(row, flush=True)
    json.dump(res, open(out / "fault_injection_results.json", "w"), indent=1)

if __name__ == "__main__":
    main()
