"""
v4_practical.py -- practical consequences of the (simple) structural results on full Adult.

V4a  Question-agnostic optimum vs question-driven verdict. Among Safe policies (no singleton
     QI group; equivalently 2-anonymity on the QI), pick the optimum under standard
     question-agnostic utility metrics and test it against Q1-Q4:
       Prec  (Sweeney precision, all attributes: 1 - mean(level / top level))
       LM    (Iyengar loss metric, all attributes: mean over records and attributes of
              (|leaves under released node| - 1) / (|domain| - 1))
       DM    (discernibility on the QI: sum of squared QI-class sizes)
       Cavg  (average QI-class size / k, k = 2)
     Also for k in {5, 10} (k-anonymity on the QI instead of singleton exposure).
V4b  Basis compression and diagnostics: number of failing policies explained by the
     minimal failure basis B; one witness pair per basis element.
V4c  Cost of the pair-based utility check vs the label-grouping check licensed by the
     label-factorization result (timed on subsamples, pairs counted exactly).
Usage: python3 v4_practical.py adult.data out_dir
"""
import itertools, json, sys, time
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parent))
from scale_adult_direct import load, WORKCLASS, EDU, MARITAL, OCC
from scale_policyspace import hierarchies, labels, Ev, BASE, QI, covers_down

def main():
    src, out = Path(sys.argv[1]), Path(sys.argv[2]); out.mkdir(exist_ok=True)
    df = load(src); H = hierarchies(df); Lab = labels(df); ev = Ev(H, BASE)
    dims = [len(H[x]) for x in BASE]; P = list(itertools.product(*[range(d) for d in dims]))
    n = len(df)
    # --- per-policy metrics -------------------------------------------------------
    leaf = {x: H[x][0] for x in BASE}
    dom = {x: int(leaf[x].max()) + 1 for x in BASE}
    # LM contribution per attribute and level: mean over records of (leaves under node - 1)/(|dom|-1)
    lm = {}
    for x in BASE:
        for l in range(dims[BASE.index(x)]):
            node = H[x][l]
            leaves_per_node = pd.Series(leaf[x]).groupby(node).nunique()
            m = leaves_per_node.reindex(node).to_numpy()
            lm[(x, l)] = float(np.mean((m - 1) / max(dom[x] - 1, 1)))
    rows = []
    qi_stats = {}
    for p in P:
        q = tuple(p[i] for i in ev.qi_idx)
        if q not in qi_stats:
            _, c = np.unique(ev.key(p, ev.qi_idx), return_counts=True)
            qi_stats[q] = (int(c.min()), float(np.sum(c.astype(np.float64) ** 2)), float(n / len(c)))
        kmin, dm, cavg = qi_stats[q]
        prec = 1 - np.mean([p[i] / (dims[i] - 1) for i in range(len(BASE))])
        LM = float(np.mean([lm[(BASE[i], p[i])] for i in range(len(BASE))]))
        rows.append(dict(p=p, kmin=kmin, DM=dm, Cavg=cavg, Prec=float(prec), LM=LM))
    useful = {}
    for qn, lab in Lab.items():
        nl = int(lab.max()) + 1
        useful[qn] = {p for p in P if ev.useful(p, lab, nl)}
    res_a = []
    for k in [2, 5, 10]:
        safe = [r for r in rows if r["kmin"] >= k]
        for metric, better in [("Prec", -1), ("LM", 1), ("DM", 1), ("Cavg", 1)]:
            srt = sorted(safe, key=lambda r: (better * r[metric], r["p"]))
            best = srt[0]
            top10 = srt[:10]
            entry = {"k": k, "metric": metric, "|Safe_k|": len(safe), "optimum": best["p"]}
            for qn in Lab:
                acc = [r for r in srt if r["p"] in useful[qn]]
                entry[qn] = {"optimum_useful": best["p"] in useful[qn],
                             "top10_useful": sum(r["p"] in useful[qn] for r in top10),
                             "|accepted|": len(acc),
                             "rank_of_best_accepted": (srt.index(acc[0]) + 1) if acc else None}
            res_a.append(entry); print(entry, flush=True)
    # --- V4b basis compression + witnesses --------------------------------------
    res_b = []
    cols = ["age", "workclass", "education", "marital-status", "occupation", "sex", "native-country"]
    for qn, lab in Lab.items():
        F = useful[qn]; fail = [p for p in P if p not in F]
        B = [p for p in fail if all(q in F for q in covers_down(p))]
        wit = []
        for b in B:
            t = ev.released(b)
            d = pd.DataFrame({"t": t, "l": lab})
            g = d.groupby("t")["l"].nunique()
            bad = g[g > 1].index
            npairs = 0
            for tb in bad:
                cnt = d[d.t == tb]["l"].value_counts().to_numpy()
                npairs += int(cnt.sum() ** 2 - (cnt ** 2).sum()) // 2
            tb = bad[0]; idx = d.index[d.t == tb]
            i = idx[0]; j = next(x for x in idx if lab[x] != lab[i])
            wit.append({"basis_policy": b, "witness_pairs": npairs,
                        "example": [df.loc[i, cols].astype(str).to_dict(), df.loc[j, cols].astype(str).to_dict()]})
        res_b.append({"question": qn, "|P|": len(P), "|F|": len(F), "failing": len(fail), "|B|": len(B),
                      "failing_per_basis_element": round(len(fail) / len(B), 1), "basis": wit})
        print(qn, len(fail), len(B), [w["witness_pairs"] for w in wit], flush=True)
    # --- V4c pair-based vs grouping ---------------------------------------------
    res_c = []
    rng = np.random.default_rng(7)
    p = (1, 1, 1, 1, 1, 0, 1)   # a mid-lattice policy
    for m in [1000, 3000, 10000]:
        sel = np.sort(rng.choice(n, m, replace=False))
        t = ev.released(p)[sel]; lab = Lab["Q3"][sel]
        t0 = time.perf_counter()
        viol = 0
        for i in range(m):                                   # pair-based: Req_l /\ K
            viol += int(np.count_nonzero((t[i] == t) & (lab[i] != lab)))
        t_pair = time.perf_counter() - t0
        t0 = time.perf_counter()
        nl = int(lab.max()) + 1
        ok = len(pd.unique(t)) == len(pd.unique(t * nl + lab))
        t_grp = time.perf_counter() - t0
        req_pairs = int(m * m - np.sum(np.bincount(lab).astype(np.int64) ** 2))
        res_c.append({"records": m, "|Req| ordered pairs": req_pairs, "pair_check_s": round(t_pair, 3),
                      "grouping_check_s": round(t_grp, 5), "agree": (viol == 0) == ok})
        print(res_c[-1], flush=True)
    lab = Lab["Q3"]
    res_c.append({"records": n, "|Req| ordered pairs": int(n * n - np.sum(np.bincount(lab).astype(np.int64) ** 2)),
                  "pair_check_s_extrapolated": round(res_c[-1]["pair_check_s"] * (n / 10000) ** 2, 1),
                  "Req_materialized_GB_int32_pairs": round(8 * (n * n - np.sum(np.bincount(lab).astype(np.int64) ** 2)) / 1e9, 1)})
    json.dump({"V4a_metric_optimum": res_a, "V4b_basis": res_b, "V4c_cost": res_c},
              open(out / "practical_results.json", "w"), indent=1, default=str)

if __name__ == "__main__":
    main()
