"""
scale_adult_direct.py -- question-driven joint verification on the full UCI Adult
training file with a direct (concrete) evaluator.

Semantics are those of the manuscript:
  utility  : Req = Req_l for a task label l; Useful(pi) iff released tuple determines l
             (Proposition "finite task-label factorization", checked by grouping, O(n)).
  privacy  : E = D (the attacker knows every individual's quasi-identifier values);
             QI = (age, workclass, marital-status, sex, native-country);
             income is released verbatim, so a witness exists iff some released QI
             group has exactly one record (singleton linkage exposes income).
  order    : product of attribute-level chains; every coarser level factors through
             the finer one (order-compatible, Eq. coarsen).
Procedures: exhaustive, utility-first short-circuit, utility-first order pruning
(Algorithm 1, linear extension = lexicographic level order). Outputs are compared.

Usage: python3 scale_adult_direct.py adult.data out_dir
"""
from __future__ import annotations
import itertools, json, sys, time, hashlib, platform
from pathlib import Path
import numpy as np
import pandas as pd

COLS = ["age","workclass","fnlwgt","education","education-num","marital-status","occupation",
        "relationship","race","sex","capital-gain","capital-loss","hours-per-week","native-country","income"]

WORKCLASS = {"Private":"Private","Federal-gov":"Gov","State-gov":"Gov","Local-gov":"Gov",
             "Self-emp-not-inc":"Self","Self-emp-inc":"Self","Without-pay":"Other","Never-worked":"Other"}
EDU = {"Preschool":"PreHS","1st-4th":"PreHS","5th-6th":"PreHS","7th-8th":"PreHS","9th":"PreHS","10th":"PreHS",
       "11th":"PreHS","12th":"PreHS","HS-grad":"HS","Some-college":"College","Assoc-voc":"College",
       "Assoc-acdm":"College","Bachelors":"BachPlus","Masters":"BachPlus","Prof-school":"BachPlus","Doctorate":"BachPlus"}
MARITAL = {"Married-civ-spouse":"Married","Married-AF-spouse":"Married","Married-spouse-absent":"Married",
           "Never-married":"Never","Divorced":"Prev","Separated":"Prev","Widowed":"Prev"}
OCC = {"Exec-managerial":"White","Prof-specialty":"White","Adm-clerical":"White","Sales":"White",
       "Tech-support":"White","Protective-serv":"White","Armed-Forces":"White",
       "Craft-repair":"Blue","Machine-op-inspct":"Blue","Transport-moving":"Blue",
       "Handlers-cleaners":"Blue","Farming-fishing":"Blue","Other-service":"Service","Priv-house-serv":"Service"}

def load(path):
    df = pd.read_csv(path, header=None, names=COLS, skipinitialspace=True, na_values="?")
    df = df.dropna().reset_index(drop=True)
    return df

def levels(df):
    """attribute -> list of integer-coded columns, finest (level 0) to suppressed (last)."""
    code = lambda s: pd.factorize(s)[0].astype(np.int32)
    zero = np.zeros(len(df), dtype=np.int32)
    a = df["age"].to_numpy()
    L = {
      "age":       [code(a), code(a//5), code(a//10), code(a//20), zero],
      "workclass": [code(df["workclass"]), code(df["workclass"].map(WORKCLASS)), zero],
      "education": [code(df["education"]), code(df["education"].map(EDU)), zero],
      "marital":   [code(df["marital-status"]), code(df["marital-status"].map(MARITAL)), zero],
      "occupation":[code(df["occupation"]), code(df["occupation"].map(OCC)), zero],
      "sex":       [code(df["sex"]), zero],
      "country":   [code(df["native-country"]), code(df["native-country"]=="United-States"), zero],
    }
    return L

ATTRS = ["age","workclass","education","marital","occupation","sex","country"]
QI = ["age","workclass","marital","sex","country"]

def combine(cols):
    """Row-wise tuple id for a list of int columns (exact, via factorize of stacked keys)."""
    key = np.zeros(len(cols[0]), dtype=np.int64)
    for c in cols:
        m = int(c.max()) + 1
        key = key * m + c
        key = pd.factorize(key)[0].astype(np.int64)   # keep ids small, exact
    return key

def questions(df):
    a = df["age"].to_numpy()
    code = lambda s: pd.factorize(s)[0]
    sex = code(df["sex"]); eg = code(df["education"].map(EDU)); ee = code(df["education"])
    return {
      "Q1 sex":                         combine([sex]),
      "Q2 sex+education group":         combine([sex, eg]),
      "Q3 sex+education group+decade":  combine([sex, eg, (a//10)]),
      "Q4 sex+education+5-year age":    combine([sex, ee, (a//5)]),
    }

def useful(tuple_id, label):
    # released tuple determines label  <=>  every tuple group has one label
    s = pd.DataFrame({"t": tuple_id, "l": label})
    return bool((s.groupby("t")["l"].nunique() == 1).all())

def safe(qi_id):
    # no singleton QI group (E = D, income released verbatim)
    c = np.bincount(qi_id)
    return bool((c[c > 0] >= 2).all())

class Evaluator:
    def __init__(self, df):
        self.L = levels(df); self.Qs = questions(df); self.n = len(df)
        self.inc = pd.factorize(df["income"])[0].astype(np.int32)
        self.cache_t = {}; self.cache_q = {}
    def tup(self, p):
        if p not in self.cache_t:
            # full released tuple: generalized attributes plus income, released verbatim
            self.cache_t[p] = combine([self.L[a][l] for a, l in zip(ATTRS, p)] + [self.inc])
        return self.cache_t[p]
    def qi(self, p):
        k = tuple(l for a, l in zip(ATTRS, p) if a in QI)
        if k not in self.cache_q:
            self.cache_q[k] = combine([self.L[a][l] for a, l in zip(ATTRS, p) if a in QI])
        return self.cache_q[k]

def policies(L):
    return list(itertools.product(*[range(len(L[a])) for a in ATTRS]))

def leq(p, q): return all(x <= y for x, y in zip(p, q))

def run(ev, qname):
    lab = ev.Qs[qname]; P = policies(ev.L)
    # exhaustive
    ev.cache_t = {}; ev.cache_q = {}
    t0 = time.perf_counter(); U = {}; S = {}
    for p in P:
        U[p] = useful(ev.tup(p), lab); S[p] = safe(ev.qi(p))
    t_ex = time.perf_counter() - t0
    F = {p for p in P if U[p]}; A = {p for p in F if S[p]}
    Max = {p for p in F if not any(q != p and leq(p, q) for q in F)}
    fail = [p for p in P if not U[p]]
    B = {p for p in fail if not any(q != p and leq(q, p) for q in fail)}
    # pruned (Algorithm 1), fresh caches to time fairly
    ev.cache_t = {}; ev.cache_q = {}
    t0 = time.perf_counter(); basis = []; Fp = set(); Ap = set(); nU = nP = 0
    for p in sorted(P):                      # lexicographic = linear extension
        if any(leq(b, p) for b in basis): continue
        nU += 1
        if not useful(ev.tup(p), lab): basis.append(p); continue
        Fp.add(p); nP += 1
        if safe(ev.qi(p)): Ap.add(p)
    t_pr = time.perf_counter() - t0
    Maxp = {p for p in Fp if not any(q != p and leq(p, q) for q in Fp)}
    # privacy upward-closure check (generalization property) on the whole lattice
    safe_set = {p for p in P if S[p]}
    viol = sum(1 for p in safe_set for q in P if leq(p, q) and q not in safe_set)
    return {
      "question": qname, "labels": int(lab.max()) + 1, "|P|": len(P),
      "|Req| (ordered pairs)": int(ev.n*ev.n - np.sum(np.bincount(lab).astype(np.int64)**2)),
      "|F|": len(F), "|B|": len(B), "|Max(F)|": len(Max), "|A|": len(A), "|Safe|": len(safe_set),
      "calls_full": 2*len(P), "calls_short": len(P)+len(F), "calls_pruned": nU+nP,
      "calls_pruned_formula": 2*len(F)+len(B),
      "pruned_equals_exhaustive": (Fp == F and Maxp == Max and Ap == A),
      "time_full_s": round(t_ex, 2), "time_pruned_s": round(t_pr, 2),
      "privacy_upward_closure_violations": viol,
      "Max(F)": sorted(Max),
    }

def main():
    src, out = Path(sys.argv[1]), Path(sys.argv[2]); out.mkdir(exist_ok=True)
    df = load(src)
    meta = {"source": src.name, "sha256": hashlib.sha256(src.read_bytes()).hexdigest(),
            "records_after_dropping_missing": len(df), "host": platform.platform(),
            "python": platform.python_version(), "pandas": pd.__version__}
    ev = Evaluator(df)
    res = [run(ev, q) for q in ev.Qs]
    # record-count sweep for Q3: time per policy check
    sweep = []
    rng = np.random.default_rng(42)
    for n in [1000, 3000, 10000, len(df)]:
        sub = df.iloc[np.sort(rng.choice(len(df), n, replace=False))].reset_index(drop=True) if n < len(df) else df
        e2 = Evaluator(sub); r = run(e2, "Q3 sex+education group+decade")
        sweep.append({"n": n, **{k: r[k] for k in ["|F|","|B|","|A|","calls_pruned","time_full_s","time_pruned_s","pruned_equals_exhaustive"]}})
    json.dump({"meta": meta, "results": res, "sweep_Q3": sweep}, open(out/"scale_results.json","w"), indent=1, default=str)
    print(json.dumps(meta, indent=1))
    for r in res: print({k: v for k, v in r.items() if k != "Max(F)"})
    for s in sweep: print(s)

if __name__ == "__main__":
    main()
