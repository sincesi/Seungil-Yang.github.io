# Full-Adult direct-evaluator experiments

Data: the UCI Adult training file `adult.data`. Rows with missing values are dropped, leaving 30,162 records. The SHA-256 of the input is recorded in each JSON output.

Release: every policy releases the generalized attributes plus `income` verbatim. Utility is checked on this full released tuple. Privacy uses exact matching on the quasi-identifier.

All scripts live in this folder and import each other through paths relative to the folder.

    python3 scale_adult_direct.py adult.data out     # Table "Full Adult": nested questions Q1-Q4
    python3 scale_sweep.py        adult.data out     # record-count sweep for Q3
    python3 scale_policyspace.py  adult.data out     # Table "policy-space growth" (2,430-87,480 policies)
    python3 scale_qi_variant.py   adult.data out     # extended quasi-identifier variant
    python3 v2_fault_injection.py adult.data out/v2  # Table "Seeded specification defects" (evaluator side + Alloy exports)
    python3 v4_practical.py       adult.data out/v4  # Table "Metric optima", basis witnesses, pair vs grouping cost
    python3 scale_dependent.py    adult.data out     # Table "Data-dependent questions" (spouse label; cohorts)

The Alloy side of the seeded defects: `java -Xss1g -cp alloy.jar:../validation RunAll out/v2/spec_<variant>_{hier,label}.als minisat`. Compile `RunAll.java` in `../validation` first.

Timings in the manuscript come from a 2-core Linux VM (Python 3.11, pandas 3.0). The times in Table "Full Adult" are from `policyspace_results.json` (7-attribute lattice) and `sweep_Q3_L7.json`, which use the faster implementation. `scale_results.json` (from `scale_adult_direct.py`) gives the same sets and call counts but slower times. Verdicts and call counts do not depend on the host.
