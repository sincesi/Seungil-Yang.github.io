"""
scale_policyspace.py -- policy-space growth on the full UCI Adult data (direct evaluator).

Same semantics as scale_adult_direct.py (utility: the full released tuple, including
income released verbatim, determines the task label; privacy: every individual's quasi-identifier known, income released verbatim,
Unsafe iff a released QI group has one record). The quasi-identifier stays
(age, workclass, marital-status, sex, native-country) in every lattice; extra
hierarchies are released non-QI attributes, so only the policy space grows.

Lattices:  L7 = 7 attributes (2,430 policies, as in scale_adult_direct.py)
           L8 = L7 + race           (7,290)
           L9 = L8 + relationship   (21,870)
           L10 = L9 + hours-per-week (87,480)
For each lattice and question: exhaustive and pruned (Algorithm 1) runs, output
equality, call counts vs 2|F|+|B|, privacy upper-set check (via upper covers), times.
Max(F) and B are computed through covers (valid because F is a lower set in a product
lattice). Tuple identifiers use exact mixed-radix integer keys (no hashing collisions).

Usage: python3 scale_policyspace.py adult.data out_dir
"""
from __future__ import annotations
import itertools, json, sys, time, hashlib, platform
from pathlib import Path
import numpy as np
import pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parent))
from scale_adult_direct import load, WORKCLASS, EDU, MARITAL, OCC

RACE = {"White": "White", "Black": "Other", "Asian-Pac-Islander": "Other",
        "Amer-Indian-Eskimo": "Other", "Other": "Other"}
REL = {"Husband": "Spouse", "Wife": "Spouse", "Own-child": "Child",
       "Not-in-family": "Other", "Other-relative": "Other", "Unmarried": "Other"}

def code(s):
    return pd.factorize(pd.Series(s))[0].astype(np.int64)

def hierarchies(df):
    a = df["age"].to_numpy(); h = df["hours-per-week"].to_numpy(); z = np.zeros(len(df), np.int64)
    H = {
      "age":        [code(a), code(a//5), code(a//10), code(a//20), z],
      "workclass":  [code(df["workclass"]), code(df["workclass"].map(WORKCLASS)), z],
      "education":  [code(df["education"]), code(df["education"].map(EDU)), z],
      "marital":    [code(df["marital-status"]), code(df["marital-status"].map(MARITAL)), z],
      "occupation": [code(df["occupation"]), code(df["occupation"].map(OCC)), z],
      "sex":        [code(df["sex"]), z],
      "country":    [code(df["native-country"]), code(df["native-country"] == "United-States"), z],
      "race":       [code(df["race"]), code(df["race"].map(RACE)), z],
      "relationship":[code(df["relationship"]), code(df["relationship"].map(REL)), z],
      "hours":      [code(h), code(h//10), code(h//20), z],
    }
    H["_income"] = [code(df["income"])]   # released verbatim in every policy (not generalized)
    return H

BASE = ["age","workclass","education","marital","occupation","sex","country"]
LATTICES = {"L7": BASE, "L8": BASE+["race"], "L9": BASE+["race","relationship"],
            "L10": BASE+["race","relationship","hours"]}
QI = ["age","workclass","marital","sex","country"]

def labels(df):
    a = df["age"].to_numpy()
    sex = code(df["sex"]); eg = code(df["education"].map(EDU)); ee = code(df["education"])
    mix = lambda *cs: code([tuple(t) for t in zip(*cs)])
    return {"Q1": sex, "Q2": mix(sex, eg), "Q3": mix(sex, eg, a//10), "Q4": mix(sex, ee, a//5)}

class Ev:
    def __init__(self, H, attrs):
        self.H, self.attrs = H, attrs
        self.radix = [max(int(c.max())+1 for c in H[x]) for x in attrs]
        self.qi_idx = [i for i, x in enumerate(attrs) if x in QI]
        self.qcache = {}
    def key(self, p, idx):
        k = np.zeros(len(self.H[self.attrs[0]][0]), np.int64)
        for i in idx:
            k = k * self.radix[i] + self.H[self.attrs[i]][p[i]]
        return k
    def released(self, p):
        """Full released tuple id: generalized attributes plus income, released verbatim."""
        t = self.key(p, range(len(self.attrs)))
        if "_income" in self.H:
            t = t * 2 + self.H["_income"][0]
        return t
    def useful(self, p, lab, nlab):
        t = self.released(p)
        return len(pd.unique(t)) == len(pd.unique(t * nlab + lab))
    def safe(self, p):
        q = tuple(p[i] for i in self.qi_idx)
        if q not in self.qcache:
            _, c = np.unique(self.key(p, self.qi_idx), return_counts=True)
            self.qcache[q] = bool(c.min() >= 2)
        return self.qcache[q]

def covers_up(p, dims):
    for i, d in enumerate(dims):
        if p[i] + 1 < d: yield p[:i] + (p[i]+1,) + p[i+1:]
def covers_down(p):
    for i in range(len(p)):
        if p[i] > 0: yield p[:i] + (p[i]-1,) + p[i+1:]

def run(ev, lab):
    nlab = int(lab.max()) + 1
    dims = [len(ev.H[x]) for x in ev.attrs]
    P = list(itertools.product(*[range(d) for d in dims]))
    ev.qcache = {}
    t0 = time.perf_counter()
    U = {p: ev.useful(p, lab, nlab) for p in P}
    S = {p: ev.safe(p) for p in P}
    t_ex = time.perf_counter() - t0
    F = {p for p in P if U[p]}; A = {p for p in F if S[p]}
    Max = {p for p in F if not any(q in F for q in covers_up(p, dims))}
    B = {p for p in P if not U[p] and all(U[q] for q in covers_down(p))}
    lower_ok = all(U[q] for p in F for q in covers_down(p))            # F is a lower set
    upper_ok = all(S[q] for p in P if S[p] for q in covers_up(p, dims))  # Safe is an upper set
    ev.qcache = {}
    t0 = time.perf_counter(); basis = []; Fp = set(); Ap = set(); nU = nP = 0
    for p in P:                                  # itertools.product order = lexicographic
        if any(all(b[i] <= p[i] for i in range(len(p))) for b in basis): continue
        nU += 1
        if not ev.useful(p, lab, nlab): basis.append(p); continue
        Fp.add(p); nP += 1
        if ev.safe(p): Ap.add(p)
    t_pr = time.perf_counter() - t0
    return {"|P|": len(P), "|F|": len(F), "|B|": len(B), "|Max|": len(Max), "|A|": len(A),
            "|Safe|": sum(S.values()), "calls_full": 2*len(P), "calls_short": len(P)+len(F),
            "calls_pruned": nU+nP, "formula": 2*len(F)+len(B),
            "reduction_vs_full": round(1-(nU+nP)/(2*len(P)), 4),
            "equal_outputs": (Fp == F and Ap == A and set(basis) == B),
            "F_lower_set": lower_ok, "Safe_upper_set": upper_ok,
            "t_full_s": round(t_ex, 1), "t_pruned_s": round(t_pr, 1),
            "Max": sorted(Max)}

def main():
    src, out = Path(sys.argv[1]), Path(sys.argv[2]); out.mkdir(exist_ok=True)
    df = load(src); H = hierarchies(df); L = labels(df)
    meta = {"sha256": hashlib.sha256(src.read_bytes()).hexdigest(), "records": len(df),
            "host": platform.platform(), "python": platform.python_version(), "pandas": pd.__version__}
    res = []
    for lname, attrs in LATTICES.items():
        ev = Ev(H, attrs)
        for q in ["Q1", "Q2", "Q3", "Q4"]:
            r = {"lattice": lname, "attrs": attrs, "question": q, **run(ev, L[q])}
            res.append(r); print({k: v for k, v in r.items() if k not in ("Max", "attrs")}, flush=True)
            json.dump({"meta": meta, "results": res}, open(out/"policyspace_results.json", "w"), indent=1, default=str)

if __name__ == "__main__":
    main()
