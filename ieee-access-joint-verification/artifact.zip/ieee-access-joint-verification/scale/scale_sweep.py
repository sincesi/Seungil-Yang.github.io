"""scale_sweep.py -- record-count sweep for Q3 on the 7-attribute lattice (direct evaluator,
same semantics as scale_policyspace.py; utility on the full released tuple incl. income).
Subsamples: numpy default_rng(42), drawn in order for n = 1,000, 3,000, 10,000; then all records.
Usage: python3 scale_sweep.py adult.data out_dir"""
import sys, json
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
import scale_policyspace as s
df = s.load(sys.argv[1]); out = []
rng = np.random.default_rng(42)
for n in [1000, 3000, 10000, len(df)]:
    sub = df.iloc[np.sort(rng.choice(len(df), n, replace=False))].reset_index(drop=True) if n < len(df) else df
    H = s.hierarchies(sub); L = s.labels(sub); ev = s.Ev(H, s.BASE)
    r = s.run(ev, L["Q3"]); r.pop("Max"); r["n"] = n; out.append(r); print(r, flush=True)
json.dump(out, open(Path(sys.argv[2]) / "sweep_Q3_L7.json", "w"), indent=1)
