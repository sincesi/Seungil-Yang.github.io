"""scale_dependent.py -- data-dependent questions on full Adult (direct evaluator, 7-attribute
lattice, release = generalized attributes + income verbatim, privacy as in scale_policyspace.py).

The task label is NOT an attribute of the lattice: spouse = relationship in {Husband, Wife}.
Relationship is never released, so a useful policy must let the label be recovered from
the released attributes (marital status, sex, age, ...) through the data.
  Q5  spouse, all 30,162 records                     (Req = pairs with different label)
  Q6a spouse, cohort age >= 65 (975 records)           (Req restricted to cohort pairs)
  Q6b spouse, random 300-record cohort (numpy default_rng(1))
For each: exhaustive and pruned search, F, Max(F), B, A, call counts vs 2|F|+|B|,
equality of outputs, unordered witness pairs per basis element and one example witness.
Usage: python3 scale_dependent.py adult.data out_dir
"""
import itertools, json, sys, time, hashlib
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parent))
import scale_policyspace as s

COLS = ["age", "workclass", "education", "marital-status", "occupation", "sex", "native-country", "relationship", "income"]

def main():
    src, out = Path(sys.argv[1]), Path(sys.argv[2]); out.mkdir(exist_ok=True, parents=True)
    df = s.load(src); H = s.hierarchies(df); ev = s.Ev(H, s.BASE)
    dims = [len(H[x]) for x in s.BASE]; P = list(itertools.product(*[range(d) for d in dims]))
    lab_all = s.code(df["relationship"].isin(["Husband", "Wife"]))
    rng = np.random.default_rng(1)
    cohorts = {"Q5 spouse, all records": np.ones(len(df), bool),
               "Q6a spouse, cohort age>=65": (df["age"] >= 65).to_numpy(),
               "Q6b spouse, random 300-record cohort": np.isin(np.arange(len(df)), rng.choice(len(df), 300, replace=False))}
    res = []
    for name, m in cohorts.items():
        lab = lab_all[m]; nl = 2
        Sq = {}
        def safe(p):
            q = tuple(p[i] for i in ev.qi_idx)
            if q not in Sq: Sq[q] = ev.safe(p)
            return Sq[q]
        def useful(p):
            t = ev.released(p)[m]
            return len(pd.unique(t)) == len(pd.unique(t * nl + lab))
        t0 = time.perf_counter(); U = {p: useful(p) for p in P}; S = {p: safe(p) for p in P}; t_ex = time.perf_counter() - t0
        F = {p for p in P if U[p]}; A = {p for p in F if S[p]}
        Max = sorted(p for p in F if not any(q in F for q in s.covers_up(p, dims)))
        B = sorted(p for p in P if not U[p] and all(U[q] for q in s.covers_down(p)))
        Sq.clear(); t0 = time.perf_counter(); basis = []; Fp = set(); Ap = set(); calls = 0
        for p in P:
            if any(all(b[i] <= p[i] for i in range(len(p))) for b in basis): continue
            calls += 1
            if not useful(p): basis.append(p); continue
            Fp.add(p); calls += 1
            if safe(p): Ap.add(p)
        t_pr = time.perf_counter() - t0
        wit = []
        idx = np.nonzero(m)[0]
        for b in B:
            t = ev.released(b)[m]
            d = pd.DataFrame({"t": t, "l": lab})
            cnt = d.groupby(["t", "l"]).size().unstack(fill_value=0)
            pairs = int((cnt.prod(axis=1)).sum()) if cnt.shape[1] == 2 else 0
            bad = cnt[(cnt > 0).sum(axis=1) > 1].index
            ex = None
            if len(bad):
                rows = idx[np.nonzero(t == bad[0])[0]]
                i = rows[0]; j = next(r for r in rows if lab_all[r] != lab_all[i])
                ex = [df.loc[i, COLS].astype(str).to_dict(), df.loc[j, COLS].astype(str).to_dict()]
            wit.append({"basis": b, "unordered_witness_pairs": pairs, "example": ex})
        r = {"question": name, "cohort_records": int(m.sum()), "|P|": len(P), "|F|": len(F), "|Max|": len(Max),
             "Max": Max, "|B|": len(B), "|A|": len(A), "A": sorted(A), "calls_full": 2 * len(P), "calls_short": len(P) + len(F),
             "calls_pruned": calls, "formula": 2 * len(F) + len(B),
             "pruned_equals_exhaustive": Fp == F and Ap == A and sorted(basis) == B,
             "t_full_s": round(t_ex, 1), "t_pruned_s": round(t_pr, 1), "basis": wit,
             "attrs": s.BASE, "levels": {"age": ["exact", "5y", "10y", "20y", "*"], "workclass": ["exact", "4 groups", "*"],
                 "education": ["exact", "4 groups", "*"], "marital": ["exact", "3 groups", "*"], "occupation": ["exact", "3 groups", "*"],
                 "sex": ["exact", "*"], "country": ["exact", "US/other", "*"]}}
        res.append(r); print({k: v for k, v in r.items() if k not in ("basis", "A", "levels", "attrs")}, flush=True)
    meta = {"sha256": hashlib.sha256(src.read_bytes()).hexdigest(), "records": len(df)}
    json.dump({"meta": meta, "results": res}, open(out / "dependent_results.json", "w"), indent=1, default=str)

if __name__ == "__main__":
    main()
