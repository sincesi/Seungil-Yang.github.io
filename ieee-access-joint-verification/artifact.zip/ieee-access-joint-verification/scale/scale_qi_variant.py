"""Variant: the added attributes also enter the quasi-identifier (attacker knows them).
Utility and pruning are unchanged; privacy and the accepted set change."""
import sys, json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import scale_policyspace as s
df = s.load(sys.argv[1]); H = s.hierarchies(df); L = s.labels(df)
out = []
for lname in ["L8", "L9", "L10"]:
    attrs = s.LATTICES[lname]
    s.QI = ["age","workclass","marital","sex","country"] + [a for a in attrs if a in ("race","relationship","hours")]
    ev = s.Ev(H, attrs)
    for q in ["Q3"]:
        r = s.run(ev, L[q]); r.pop("Max")
        r.update({"lattice": lname, "question": q, "QI": s.QI}); out.append(r); print(r, flush=True)
json.dump(out, open(Path(sys.argv[2])/"qi_variant_results.json", "w"), indent=1)
