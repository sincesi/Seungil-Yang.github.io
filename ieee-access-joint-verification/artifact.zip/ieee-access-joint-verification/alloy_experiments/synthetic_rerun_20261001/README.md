# Rerun of the synthetic configurations (2026-10-01)

The Small, Medium and Large models were run unchanged from `../synthetic_small_medium_large/`. The orchestrator is `run_adult_sweep.py` from the Adult rerun kit, extended with the configs `small`, `medium` and `large`. Every Alloy call is logged with its result, solving time and any solver warning.

- **Host and solver:** cloud Linux VM (2 cores), Alloy 6.1.0, `java -Xmx2g`, MiniSat JNI. `sat4j_fallback_calls` = 0 for all three.
- **Small:** all 60 per-policy verdicts equal `../record_scale_probe/policy_classification_small.csv`. Counts are 14/1/42/3, F=15, A=14, with 120/31 calls.
- **Medium and Large:** F=1, |Max|=1, |B|=3, with 120/5 calls, matching the archived table3b and tab:calls.
- **Pruned vs. exhaustive:** in all three configurations the pruned search returns the same F, Max(F) and A as exhaustive.
- **Timings:** solving times are from this host and are not comparable to the archived macOS timings.
