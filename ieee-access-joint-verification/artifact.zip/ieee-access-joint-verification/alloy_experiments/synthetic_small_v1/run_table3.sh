#!/usr/bin/env bash
set -euo pipefail

# Usage:
#   ./run_table3.sh /path/to/alloy.jar
#
# Required files in the current directory:
#   - jisa_joint_experiment_v1.als
#   - python_evaluator_small.py
#   - AlloyRunDriver.java

ALLOY_JAR="${1:-alloy.jar}"

if [[ ! -f "$ALLOY_JAR" ]]; then
  echo "Alloy jar not found: $ALLOY_JAR" >&2
  echo "Pass the jar path, e.g.: ./run_table3.sh /Applications/Alloy/org.alloytools.alloy.dist.jar" >&2
  exit 1
fi

if [[ ! -f "AlloyRunDriver.java" ]]; then
  echo "AlloyRunDriver.java not found in current directory." >&2
  exit 1
fi

if [[ ! -f "jisa_joint_experiment_v1.als" ]]; then
  echo "jisa_joint_experiment_v1.als not found in current directory." >&2
  exit 1
fi

if [[ ! -f "python_evaluator_small.py" ]]; then
  echo "python_evaluator_small.py not found in current directory." >&2
  exit 1
fi

javac -cp "$ALLOY_JAR" AlloyRunDriver.java
export ALLOY_CMD="java -cp $ALLOY_JAR:. AlloyRunDriver {als} {cmd}"
python3 python_evaluator_small.py
