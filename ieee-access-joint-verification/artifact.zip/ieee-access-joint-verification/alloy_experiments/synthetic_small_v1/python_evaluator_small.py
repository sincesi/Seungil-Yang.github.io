"""
python_evaluator_small.py

Table 3 (Exhaustive vs. Monotonic Pruning) orchestration for the Small
configuration of jisa_joint_experiment_v1.als.

Canonical file rule: the canonical Alloy source is identified by (1) its
`module` declaration name and (2) the filename used in this working
directory -- both must read "jisa_joint_experiment_v1". Incidental
suffixes appended by an OS/browser to avoid overwriting a duplicate
download (e.g. "_2", " (1)") are NOT new versions and should simply be
renamed back before use; they do not require an Amendment.

Executable Semantics Rule ES-1 compliance
------------------------------------------------------------------------
This script does NOT reimplement PrivacyPropertyHolds / UtilityPropertyHolds
/ Safe / Useful / WPriv / WUtil in Python. Every Safe/Useful verdict comes
exclusively from an Alloy SAT/UNSAT result (see run_alloy()).

The ONLY thing replicated here in Python is the generalization order
preceqG (Def.4), a closed combinatorial structure (product of three
fixed total orders) independent of privacy/utility semantics -- see the
header note in jisa_joint_experiment_v1.als.

"Alloy calls" accounting
------------------------------------------------------------------------
Each policy requires up to two Alloy invocations: CheckTargetUseful and
CheckTargetSafe. Under monotonic pruning, once a policy is known
UtilityViolating (directly, or inferred via Theorem 3 propagation from a
finer-or-equal previously-checked policy that already failed utility),
BOTH calls are skipped for every strictly coarser descendant, since
Accept requires Useful regardless of Safe. This is the source of the
Table 3A reduction.

Before running:
  1. Place this script in the same directory as jisa_joint_experiment_v1.als.
  2. Set ALLOY_CMD to a local headless Alloy command, e.g.:
       export ALLOY_CMD='java -cp alloy.jar YourAlloyCliDriver {als} {cmd}'
     (Alloy Analyzer 6.1.0 has no built-in CLI; {als}/{cmd} are filled in
     per invocation. A small Java driver using the CompUtil/A4Solution
     API is typically required -- see Alloy4 API docs.)
  3. Verify against a RAW (not chat-pasted) local terminal capture that
     the SAT/UNSAT parsing in run_alloy() actually matches your local
     Alloy build's textual output before trusting the aggregated tables.

Output: prints Table 3A/3B to stdout AND writes table3a.csv / table3b.csv
in the current working directory (paper-ready, importable into LaTeX via
e.g. csvsimple or pgfplotstable).
"""

from __future__ import annotations

import csv
import itertools
import os
import re
import shlex
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path

CANONICAL_ALS = Path("jisa_joint_experiment_v1.als")
WORKDIR = Path("alloy_batch_runs")
WORKDIR.mkdir(exist_ok=True)

AGE_LEVELS = ["AgeExact", "Age5yr", "Age10yr", "AgeAdult", "AgeSuppressed"]
REGION_LEVELS = ["RegExact", "RegPrefectureLvl", "RegCountryLvl", "RegSuppressedLvl"]
DISEASE_LEVELS = ["DisExact", "DisCategory", "DisSuppressed"]


@dataclass(frozen=True)
class PolicyCoord:
    age: str
    region: str
    disease: str

    def preceq(self, other: "PolicyCoord") -> bool:
        """self preceq_G other iff other is coarser-or-equal on every axis."""
        return (
            AGE_LEVELS.index(self.age) <= AGE_LEVELS.index(other.age)
            and REGION_LEVELS.index(self.region) <= REGION_LEVELS.index(other.region)
            and DISEASE_LEVELS.index(self.disease) <= DISEASE_LEVELS.index(other.disease)
        )

    def stem(self) -> str:
        return f"{self.age}_{self.region}_{self.disease}"


@dataclass
class AlloyResult:
    sat: bool
    elapsed_ms: float
    stdout: str


@dataclass
class PolicyVerdict:
    coord: PolicyCoord
    safe: bool | None
    useful: bool
    accept: bool
    alloy_calls: int


def all_policies() -> list[PolicyCoord]:
    return [
        PolicyCoord(a, r, d)
        for a, r, d in itertools.product(AGE_LEVELS, REGION_LEVELS, DISEASE_LEVELS)
    ]


def generate_pinned_copy(coord: PolicyCoord, command: str) -> Path:
    if command not in {"CheckTargetSafe", "CheckTargetUseful"}:
        raise ValueError(f"unknown command: {command}")

    predicate = "Safe" if command == "CheckTargetSafe" else "Useful"
    base = CANONICAL_ALS.read_text()

    pin = f"""

-- ----------------------------------------------------------------------
-- Python-generated target-policy pinning for Table 3.
-- ----------------------------------------------------------------------
fact PinTargetPolicy {{
  TargetPolicy.ageLevel = {coord.age}
  TargetPolicy.regionLevel = {coord.region}
  TargetPolicy.diseaseLevel = {coord.disease}
}}

run {command} {{
  {predicate}[TargetPolicy]
}} for exactly 4 Record, exactly 60 Policy, exactly 1 ExternalRecord
"""
    out = WORKDIR / f"{coord.stem()}_{command}.als"
    out.write_text(base + pin)
    return out


def alloy_command(als_path: Path, command: str) -> list[str]:
    template = os.environ.get("ALLOY_CMD")
    if not template:
        raise RuntimeError(
            "Set ALLOY_CMD first, e.g. "
            "ALLOY_CMD='java -cp alloy.jar YourAlloyCliDriver {als} {cmd}'"
        )
    return shlex.split(template.format(als=str(als_path), cmd=command))


def run_alloy(coord: PolicyCoord, command: str) -> AlloyResult:
    """Invoke Alloy on a `run` command only (CheckTargetSafe/CheckTargetUseful
    are both `run`, not `check` -- see canonical .als Part 10). `run`
    output uses "Instance found"/"No instance found" plus "Predicate is
    consistent"/"Predicate (is|may be) inconsistent"; this is DIFFERENT
    wording from `check` commands ("No counterexample found"/"Counterexample
    found"), so this function must not be reused for check-style commands
    without adjusting the regex below.

    elapsed_ms reports the driver's OWN "Elapsed(ms): N" line (pure SAT
    solving time, excluding JVM startup and file parsing), NOT Python's
    wall-clock subprocess time. The latter would be dominated by
    per-process JVM startup overhead across up to 120 invocations and
    would not be comparable to the "Solving time" figures already
    recorded from GUI-based Table 1/2 runs. If the driver's Elapsed(ms)
    line cannot be found (e.g. a different driver implementation is
    used), this falls back silently to wall-clock time for that single
    call; if that fallback is ever taken, Solving time and Wall-clock
    time in Table 3A will be closer together than expected -- treat
    that as a signal to check the driver's stdout format."""
    als_path = generate_pinned_copy(coord, command)
    cmd = alloy_command(als_path, command)
    t0 = time.time()
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    wall_elapsed_ms = (time.time() - t0) * 1000
    stdout = proc.stdout + "\n" + proc.stderr

    elapsed_match = re.search(r"Elapsed\(ms\):\s*(\d+)", stdout)
    elapsed_ms = float(elapsed_match.group(1)) if elapsed_match else wall_elapsed_ms

    # IMPORTANT: check the UNSAT/False pattern FIRST. "No instance found"
    # contains "instance found" as a literal substring, so a naive
    # case-insensitive search for "Instance found" would match INSIDE
    # "No instance found" and incorrectly report sat=True for a UNSAT
    # result. Checking the more specific "No instance found" /
    # "inconsistent" pattern first avoids this false positive. (Verified:
    # the reverse collision does not occur -- "Predicate is consistent."
    # does not contain "inconsistent" as a substring.)
    if re.search(
        r"No instance found|Predicate (is|may be) inconsistent", stdout, flags=re.I
    ):
        return AlloyResult(False, elapsed_ms, stdout)
    if re.search(r"(?<!No )Instance found|Predicate is consistent", stdout, flags=re.I):
        return AlloyResult(True, elapsed_ms, stdout)

    raise RuntimeError(f"Could not parse Alloy output for {coord} {command}:\n{stdout}")


def evaluate_exhaustive(policies: list[PolicyCoord]) -> tuple[list[PolicyVerdict], int, float, float]:
    """Returns (results, alloy_calls, wall_clock_seconds, total_solving_seconds)."""
    results: list[PolicyVerdict] = []
    calls = 0
    solving_ms = 0.0
    t0 = time.time()

    for coord in policies:
        useful_res = run_alloy(coord, "CheckTargetUseful")
        safe_res = run_alloy(coord, "CheckTargetSafe")
        calls += 2
        solving_ms += useful_res.elapsed_ms + safe_res.elapsed_ms
        results.append(PolicyVerdict(coord, safe=safe_res.sat, useful=useful_res.sat,
                                      accept=safe_res.sat and useful_res.sat, alloy_calls=2))

    return results, calls, time.time() - t0, solving_ms / 1000


def evaluate_pruned(policies: list[PolicyCoord]) -> tuple[list[PolicyVerdict], int, float, float]:
    """Returns (results, alloy_calls, wall_clock_seconds, total_solving_seconds)."""
    ordered = sorted(
        policies,
        key=lambda c: (
            AGE_LEVELS.index(c.age),
            REGION_LEVELS.index(c.region),
            DISEASE_LEVELS.index(c.disease),
        ),
    )
    known_utility_violating: list[PolicyCoord] = []
    results: list[PolicyVerdict] = []
    calls = 0
    solving_ms = 0.0
    t0 = time.time()

    for coord in ordered:
        if any(ancestor.preceq(coord) for ancestor in known_utility_violating):
            results.append(PolicyVerdict(coord, safe=None, useful=False, accept=False, alloy_calls=0))
            continue

        useful_res = run_alloy(coord, "CheckTargetUseful")
        calls += 1
        solving_ms += useful_res.elapsed_ms
        if not useful_res.sat:
            known_utility_violating.append(coord)
            results.append(PolicyVerdict(coord, safe=None, useful=False, accept=False, alloy_calls=1))
            continue

        safe_res = run_alloy(coord, "CheckTargetSafe")
        calls += 1
        solving_ms += safe_res.elapsed_ms
        results.append(PolicyVerdict(coord, safe=safe_res.sat, useful=True, accept=safe_res.sat, alloy_calls=2))

    return results, calls, time.time() - t0, solving_ms / 1000


def feasible_set(results: list[PolicyVerdict]) -> set[PolicyCoord]:
    return {r.coord for r in results if r.useful}


def max_frontier(feasible: set[PolicyCoord]) -> set[PolicyCoord]:
    return {
        p for p in feasible
        if not any(p != q and p.preceq(q) for q in feasible)
    }


def main() -> None:
    policies = all_policies()
    assert len(policies) == 60

    exhaustive, ex_calls, ex_time, ex_solving = evaluate_exhaustive(policies)
    pruned, pr_calls, pr_time, pr_solving = evaluate_pruned(policies)

    ex_f = feasible_set(exhaustive)
    pr_f = feasible_set(pruned)
    ex_max = max_frontier(ex_f)
    pr_max = max_frontier(pr_f)

    print("\n=== Table 3A: Search Cost Reduction ===")
    print("Method,Policies checked,Alloy calls,Solving time(s),Wall-clock time(s),Reduction")
    print(f"Exhaustive,60,{ex_calls},{ex_solving:.3f},{ex_time:.3f},baseline")
    pr_checked = sum(1 for r in pruned if r.alloy_calls > 0)
    reduction = 1 - (pr_calls / ex_calls)
    print(f"Pruning,{pr_checked},{pr_calls},{pr_solving:.3f},{pr_time:.3f},{reduction:.1%}")
    print(
        "\nNote: 'Solving time' sums each invocation's own reported pure SAT-solving\n"
        "time (parsed from the driver's 'Elapsed(ms)' line), comparable to the\n"
        "per-command 'Solving time' figures reported for Table 1/2. 'Wall-clock\n"
        "time' additionally includes per-process JVM startup and file-parsing\n"
        "overhead across all invocations; pruning reduces both, since fewer\n"
        "invocations are launched at all."
    )

    with open("table3a.csv", "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["Method", "Policies checked", "Alloy calls",
                          "Solving time(s)", "Wall-clock time(s)", "Reduction"])
        writer.writerow(["Exhaustive", 60, ex_calls, f"{ex_solving:.3f}", f"{ex_time:.3f}", "baseline"])
        writer.writerow(["Pruning", pr_checked, pr_calls, f"{pr_solving:.3f}", f"{pr_time:.3f}", f"{reduction:.1%}"])

    print("\n=== Table 3B: Frontier Preservation ===")
    print("Method,|F_Q|,|Max(F_Q)|,Same frontier as exhaustive?")
    print(f"Exhaustive,{len(ex_f)},{len(ex_max)},baseline")
    same_frontier = ex_max == pr_max
    print(f"Pruning,{len(pr_f)},{len(pr_max)},{'Yes' if same_frontier else 'No'}")

    with open("table3b.csv", "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["Method", "|F_Q|", "|Max(F_Q)|", "Same frontier as exhaustive?"])
        writer.writerow(["Exhaustive", len(ex_f), len(ex_max), "baseline"])
        writer.writerow(["Pruning", len(pr_f), len(pr_max), "Yes" if same_frontier else "No"])

    print("\nWrote table3a.csv and table3b.csv.")

    if not same_frontier:
        print("\nWARNING: pruned frontier differs from exhaustive frontier. Investigate before reporting.")


if __name__ == "__main__":
    main()
