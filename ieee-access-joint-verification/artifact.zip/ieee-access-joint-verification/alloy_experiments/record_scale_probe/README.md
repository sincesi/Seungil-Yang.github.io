# Scalability Probe — Setup and Run Instructions

This folder contains exactly the 4 files needed for the scalability
stress test (measuring how Alloy solving time grows as record count N
increases), nothing else from prior experiments.

## Files in this folder

- `AlloyRunDriver.java` — headless Alloy runner (source only; you compile it below)
- `jisa_joint_experiment_v1.als` — canonical Small-configuration base file
  (used by generate_instance.py to build each scale point)
- `generate_instance.py` — generates jisa_joint_experiment_scaleN.als for any N
- `scale_probe.py` — measures Alloy solving time for ONE fixed policy at scale N

You will also need `alloy.jar` (your local Alloy Analyzer distribution
jar) — point to it wherever it already lives on your machine; you do
not need to copy it into this folder.

## Step 1 — Compile the driver (once)

```bash
cd /path/to/this/folder
javac -cp /path/to/alloy.jar AlloyRunDriver.java
```

This produces `AlloyRunDriver.class` (and `AlloyRunDriver$1.class`) in
this same folder.

## Step 2 — Set ALLOY_CMD (once per terminal session)

```bash
export ALLOY_CMD='java -cp /path/to/alloy.jar:. AlloyRunDriver {als} {cmd}'
```

Replace `/path/to/alloy.jar` with the real path both times (Step 1 and
Step 2 must use the same jar). Leave `{als}` and `{cmd}` exactly as
they are — the scripts fill them in automatically.

## Step 3 — Run the first scale point (N=128)

```bash
python3 generate_instance.py scale128 128
python3 scale_probe.py scale128 128
```

The first command writes `jisa_joint_experiment_scale128.als`. The
second command runs exactly 2 Alloy calls (CheckTargetSafe,
CheckTargetUseful) against a single fixed policy
(AgeExact, RegExact, DisExact) and appends the result to
`scale_probe_results.csv`.

## Step 4 — Repeat for larger N, one at a time

```bash
python3 generate_instance.py scale256 256
python3 scale_probe.py scale256 256

python3 generate_instance.py scale512 512
python3 scale_probe.py scale512 512
```

Wait for each step to finish before starting the next — if 128 is
already slow, 256/512 will likely be much slower.

## Notes

- Default per-call timeout is 1800s (30 minutes). If a call times out,
  it is recorded as `timeout` in the CSV rather than hanging forever —
  that is itself a valid result (it marks the operational boundary).
  To allow more time: `python3 scale_probe.py scale128 128 --timeout 3600`
- All results accumulate in a single `scale_probe_results.csv` in this
  folder across every run, so you can run 128/256/512 in separate
  sessions and still end up with one combined file.
- When you are done (or when a timeout occurs), share
  `scale_probe_results.csv` back for review.
