#!/bin/sh
# 512-record finest-policy utility check: capture full stderr and exit status per heap setting
cd /root/synrerun
python3 - <<'P'
from pathlib import Path
base=Path('jisa_joint_experiment_scale512.als').read_text()
pin='''
fact PinTargetPolicy {
  TargetPolicy.ageLevel = AgeExact
  TargetPolicy.regionLevel = RegExact
  TargetPolicy.diseaseLevel = DisExact
}
run CheckTargetUseful {
  Useful[TargetPolicy]
} for exactly 512 Record, exactly 60 Policy, exactly 1 ExternalRecord
'''
Path('probe512_useful.als').write_text(base+pin)
P
for heap in default 5g; do
  [ "$heap" = 5g ] && while [ ! -f SWEEPS_DONE ]; do sleep 30; done
  opt=""; [ "$heap" != default ] && opt="-Xmx$heap"
  start=$(date +%s)
  java $opt -XX:+PrintCommandLineFlags -cp /root/kit/alloy.jar:/root/synrerun AlloyRunDriver probe512_useful.als CheckTargetUseful > probe512_$heap.out 2> probe512_$heap.err
  rc=$?; end=$(date +%s)
  echo "heap=$heap rc=$rc seconds=$((end-start))" >> probe512_summary.txt
done
echo done >> probe512_summary.txt
