# Adult 재실행 v2 (2026-09-30)

## 왜 다시 돌리나
원래 Adult 모델(`../jisa_joint_experiment_adult{128,256}.als`)에는 두 가지 문제가 있었다.
1. **income이 privacy 판정에 쓰이지 않았다.** generator는 `r.sensitive`에 income을 넣었지만 WPriv가 읽는 `Catt.sensitiveOf`는 여전히 occupation 그룹에서 나온 값이었다.
2. **E1이 19개(128) / 23개(256) 레코드와 동시에 매칭되는 자리에 있었다.** 일반화하면 매칭은 늘어나기만 하므로 singleton이 불가능 → 60개 정책 모두 Safe가 구성상 정해져 있었다.

## 바뀐 점 (Marcus 결정, 2026-09-30)
- 민감 속성 = income, income은 일반화하지 않는 공개 열 → singleton 연결이면 income 노출
- E1 = (age, workclass)가 데이터에서 유일한 첫 레코드 (128: R25 A40/Komatsu, 256: R32 A25/Toyama)
- 나머지(레코드, 변환, 정책 순서, ReqGQ, 명령)는 원본 그대로. 원본 파일은 수정하지 않았다.
- `make_models_v2.py`가 원본에서 v2 모델을 만든다. Marcus 컴퓨터에서 다시 생성해 커밋본과 바이트 일치 확인함.

## 실행 방법 (macOS 터미널)
```bash
cd ~/alloy_jisa4/adult_rerun_v2_20260930
bash run_on_mac.sh                  # adult128_v2 → adult256_v2 순서
# 또는 하나만: bash run_on_mac.sh adult128_v2
```
- `caffeinate`로 실행 중 잠자기를 막는다. 중단되면 **같은 명령을 다시 실행**하면 끝난 호출은 건너뛰고 이어서 한다.
- 예상 시간(M2, 원 probe 기준): adult128 약 1.5–2시간, adult256 약 8시간.
- 옵션: `HEAP=12g`, `TIMEOUT=7200`, `ALLOY_JAR=/path/to/jar`.
- timeout·OOM·파싱 실패는 판정으로 기록하지 않고 멈춘다 (`calls_<cfg>.csv`의 tail 확인).

## 결과 파일
| 파일 | 내용 |
|---|---|
| `calls_<cfg>.csv` | Alloy 호출마다 결과, 풀이 시간, wall 시간, SAT4J fallback 여부, 출력 끝부분 |
| `verdicts_<cfg>.csv` | 60개 정책 판정 (Accept / Privacy-Reject / Utility-Reject / Both-Reject) |
| `summary_<cfg>.json` | 호출 수, 시간, F/A/Max/B, pruning 보존 여부, **direct evaluator와 일치 여부** |
| `expected_<cfg>.json` | Python direct evaluator의 예상 판정 (교차검증·직접평가 기준선) |

## 예상 결과 (direct evaluator)
| | adult128_v2 | adult256_v2 |
|---|---|---|
| Safe·Useful / Unsafe·Useful / Safe·Violating / Unsafe·Violating | 9 / 6 / 45 / 0 | 12 / 3 / 45 / 0 |
| \|F\|, \|A\|, \|B\|, \|Max(F)\| | 15, 9, 1, 1 | 15, 12, 1, 1 |
| 호출 수 exhaustive / short-circuit / pruned | 120 / 75 / 31 | 120 / 75 / 31 |
| direct evaluator 시간 (60개 정책 전체) | 약 0.006 s | 약 0.013 s |

## 사전 점검 (Beta, 클라우드, Alloy 6.1 jar = Marcus의 Alloy.app 것, SAT4J)
adult128_v2에서 Alloy 결과가 direct evaluator와 일치:
- `AgeExact_RegExact_DisExact` Safe → UNSAT (**Unsafe**, 29.6 s) · Useful → SAT (98.3 s)
- `Age10yr_RegExact_DisExact` Safe → SAT (**Safe**, 29.7 s)
- `FindPrivacyReject` → SAT (30.3 s)
클라우드 시간은 M2와 다르므로 원고에는 쓰지 않는다.
