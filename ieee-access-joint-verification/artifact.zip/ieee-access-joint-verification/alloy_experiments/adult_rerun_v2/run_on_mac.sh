#!/bin/bash
# Adult rerun v2 -- run from macOS Terminal:
#   cd ~/alloy_jisa4/adult_rerun_v2_20260930 && bash run_on_mac.sh          # adult128 then adult256
#   bash run_on_mac.sh adult128_v2                                             # one configuration only
# Resumable: if interrupted (sleep, Ctrl-C, reboot), run the same command again.
set -euo pipefail
cd "$(dirname "$0")"
JAR="${ALLOY_JAR:-/Applications/Alloy.app/Contents/Resources/org.alloytools.alloy.dist.jar}"
[ -f "$JAR" ] || { echo "Alloy jar not found: $JAR  (set ALLOY_JAR=/path/to/jar)"; exit 1; }
if command -v javac >/dev/null 2>&1; then javac -cp "$JAR" AlloyRunDriver.java; fi
java -version 2>&1 | head -1
python3 direct_evaluator.py 128 >/dev/null
python3 direct_evaluator.py 256 >/dev/null
export ALLOY_CMD="java -Xmx${HEAP:-8g} -cp $JAR:. AlloyRunDriver {als} {cmd}"
CONFIGS=("${@:-adult128_v2 adult256_v2}")
for cfg in ${CONFIGS[@]}; do
  echo "=== $cfg started $(date) ==="
  caffeinate -i python3 run_adult_sweep.py "$cfg" --timeout "${TIMEOUT:-3600}" 2>&1 | tee -a "run_${cfg}.log"
done
