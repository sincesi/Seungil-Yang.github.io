"""
run_adult_sweep.py  --  60-policy Alloy sweep for the Adult v2 models

Same procedure as ../../alloy_jisa2/python_evaluator.py (exhaustive, then
utility-first order pruning), with four changes needed for Adult scale:
  * per-call timeout is configurable (default 3600 s; the old evaluator's
    fixed 180 s could never finish an Adult-256 utility call, ~254 s);
  * every Alloy call is logged to calls_<cfg>.csv with SAT/UNSAT, driver
    solving time, wall time, solver warnings and the stdout/stderr tail;
  * the run is RESUMABLE: rerun the same command after an interruption and
    finished calls are read back from the log instead of re-executed
    (the phase is part of the key, so pruning never reuses exhaustive calls);
  * results are compared with expected_<cfg>.json from direct_evaluator.py.
A timeout or unparseable output is recorded as INCONCLUSIVE, never as a
verdict, and the sweep stops so the problem can be inspected.

Usage (from this folder):
  export ALLOY_CMD='java -Xmx6g -cp "/path/to/org.alloytools.alloy.dist.jar:." AlloyRunDriver {als} {cmd}'
  python3 run_adult_sweep.py adult128_v2
  python3 run_adult_sweep.py adult256_v2 --timeout 7200
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import itertools
import json
import os
import platform
import re
import shlex
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
CONFIGS = {
    "adult128_v2": {"als": "jisa_joint_experiment_adult128_v2.als", "records": 128},
    "adult256_v2": {"als": "jisa_joint_experiment_adult256_v2.als", "records": 256},
}
AGE_LEVELS = ["AgeExact", "Age5yr", "Age10yr", "AgeAdult", "AgeSuppressed"]
REGION_LEVELS = ["RegExact", "RegPrefectureLvl", "RegCountryLvl", "RegSuppressedLvl"]
DISEASE_LEVELS = ["DisExact", "DisCategory", "DisSuppressed"]
LOG_FIELDS = ["phase", "policy", "command", "result", "solve_ms", "wall_ms",
              "solver_warning", "finished_at", "tail"]


class Inconclusive(Exception):
    pass


def policies():
    return list(itertools.product(AGE_LEVELS, REGION_LEVELS, DISEASE_LEVELS))


def stem(p):
    return "_".join(p)


def preceq(p, q):
    return (AGE_LEVELS.index(p[0]) <= AGE_LEVELS.index(q[0]) and
            REGION_LEVELS.index(p[1]) <= REGION_LEVELS.index(q[1]) and
            DISEASE_LEVELS.index(p[2]) <= DISEASE_LEVELS.index(q[2]))


def pinned_copy(base: str, p, command, n, workdir: Path) -> Path:
    pred = "Safe" if command == "CheckTargetSafe" else "Useful"
    text = base + f"""

-- run_adult_sweep.py: pin one policy per invocation.
fact PinTargetPolicy {{
  TargetPolicy.ageLevel = {p[0]}
  TargetPolicy.regionLevel = {p[1]}
  TargetPolicy.diseaseLevel = {p[2]}
}}

run {command} {{
  {pred}[TargetPolicy]
}} for exactly {n} Record, exactly 60 Policy, exactly 1 ExternalRecord
"""
    out = workdir / f"{stem(p)}_{command}.als"
    out.write_text(text)
    return out


class Runner:
    def __init__(self, cfg, timeout):
        self.cfg = cfg
        c = CONFIGS[cfg]
        self.n = c["records"]
        self.base = (HERE / c["als"]).read_text()
        self.workdir = HERE / f"batch_{cfg}"
        self.workdir.mkdir(exist_ok=True)
        self.log_path = HERE / f"calls_{cfg}.csv"
        self.timeout = timeout
        self.template = os.environ.get("ALLOY_CMD")
        if not self.template:
            sys.exit("Set ALLOY_CMD first (see README_KO.md).")
        self.done = {}
        if self.log_path.exists():
            for row in csv.DictReader(open(self.log_path)):
                if row["result"] in ("SAT", "UNSAT"):
                    self.done[(row["phase"], row["policy"], row["command"])] = row

    def log(self, row):
        new = not self.log_path.exists()
        with open(self.log_path, "a", newline="") as f:
            w = csv.DictWriter(f, fieldnames=LOG_FIELDS)
            if new:
                w.writeheader()
            w.writerow(row)

    def call(self, phase, p, command):
        key = (phase, stem(p), command)
        if key in self.done:
            r = self.done[key]
            return r["result"] == "SAT", float(r["solve_ms"] or 0), float(r["wall_ms"] or 0)
        als = pinned_copy(self.base, p, command, self.n, self.workdir)
        cmd = shlex.split(self.template.format(als=str(als), cmd=command))
        t0 = time.time()
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=self.timeout, cwd=HERE)
            out = proc.stdout + "\n" + proc.stderr
        except subprocess.TimeoutExpired:
            out = f"TIMEOUT after {self.timeout} s"
        wall = (time.time() - t0) * 1000
        m = re.search(r"Elapsed\(ms\):\s*(\d+)", out)
        solve = float(m.group(1)) if m else None
        if re.search(r"No instance found|Predicate (is|may be) inconsistent", out, re.I):
            result = "UNSAT"
        elif re.search(r"(?<!No )Instance found|Predicate is consistent", out, re.I):
            result = "SAT"
        elif out.startswith("TIMEOUT"):
            result = "TIMEOUT"
        elif "OutOfMemoryError" in out:
            result = "OOM"
        else:
            result = "UNPARSEABLE"
        row = {"phase": phase, "policy": stem(p), "command": command, "result": result,
               "solve_ms": "" if solve is None else f"{solve:.0f}", "wall_ms": f"{wall:.0f}",
               "solver_warning": "SAT4J-fallback" if "Falling back to SAT4J" in out else "",
               "finished_at": dt.datetime.now().isoformat(timespec="seconds"),
               "tail": out.strip()[-300:].replace("\n", " | ")}
        self.log(row)
        print(f"  [{phase}] {stem(p)} {command}: {result} solve={row['solve_ms']}ms wall={wall/1000:.1f}s",
              flush=True)
        if result not in ("SAT", "UNSAT"):
            raise Inconclusive(f"{stem(p)} {command}: {result}. See {self.log_path.name}.")
        return result == "SAT", solve or wall, wall

    def exhaustive(self):
        res, calls, solve, wall = {}, 0, 0.0, 0.0
        for p in policies():
            u, s1, w1 = self.call("exhaustive", p, "CheckTargetUseful")
            s, s2, w2 = self.call("exhaustive", p, "CheckTargetSafe")
            res[stem(p)] = {"useful": u, "safe": s}
            calls += 2; solve += s1 + s2; wall += w1 + w2
        return res, calls, solve / 1000, wall / 1000

    def pruned(self):
        order = sorted(policies(), key=lambda p: (AGE_LEVELS.index(p[0]),
                                                  REGION_LEVELS.index(p[1]),
                                                  DISEASE_LEVELS.index(p[2])))
        basis, res, calls, solve, wall, checked = [], {}, 0, 0.0, 0.0, 0
        for p in order:
            if any(preceq(b, p) for b in basis):
                res[stem(p)] = {"useful": False, "safe": None}
                continue
            checked += 1
            u, s1, w1 = self.call("pruned", p, "CheckTargetUseful")
            calls += 1; solve += s1; wall += w1
            if not u:
                basis.append(p)
                res[stem(p)] = {"useful": False, "safe": None}
                continue
            s, s2, w2 = self.call("pruned", p, "CheckTargetSafe")
            calls += 1; solve += s2; wall += w2
            res[stem(p)] = {"useful": True, "safe": s}
        return res, calls, checked, solve / 1000, wall / 1000, [stem(b) for b in basis]


def sets(res):
    F = {k for k, v in res.items() if v["useful"]}
    A = {k for k in F if res[k]["safe"]}
    tup = {k: tuple(k.split("_", 2)) for k in res}
    Max = {k for k in F if not any(q != k and preceq(tup[k], tup[q]) for q in F)}
    return F, A, Max


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("config", choices=CONFIGS)
    ap.add_argument("--timeout", type=int, default=3600, help="seconds per Alloy call")
    args = ap.parse_args()
    r = Runner(args.config, args.timeout)
    print(f"=== {args.config}: {CONFIGS[args.config]['als']} ===", flush=True)
    try:
        ex, ex_calls, ex_solve, ex_wall = r.exhaustive()
        pr, pr_calls, pr_checked, pr_solve, pr_wall, basis = r.pruned()
    except Inconclusive as e:
        print("\nSTOPPED (inconclusive call, no verdict recorded):", e)
        sys.exit(1)

    exF, exA, exMax = sets(ex)
    prF, prA, prMax = sets(pr)
    cats = {"safe_useful": 0, "unsafe_useful": 0, "safe_violating": 0, "unsafe_violating": 0}
    for v in ex.values():
        cats[("safe" if v["safe"] else "unsafe") + "_" + ("useful" if v["useful"] else "violating")] += 1
    short_calls = 60 + len(exF)

    expected_path = HERE / f"expected_{args.config.replace('_v2', '')}_v2.json"
    mismatches = []
    if expected_path.exists():
        exp = json.load(open(expected_path))["per_policy"]
        for k, v in ex.items():
            if (v["safe"], v["useful"]) != (exp[k]["safe"], exp[k]["useful"]):
                mismatches.append(k)

    summary = {
        "config": args.config, "model": CONFIGS[args.config]["als"],
        "host": platform.platform(), "python": platform.python_version(),
        "alloy_cmd": r.template, "timeout_s": args.timeout,
        "finished_at": dt.datetime.now().isoformat(timespec="seconds"),
        "verdict_categories_exhaustive": cats,
        "exhaustive": {"calls": ex_calls, "solve_s": round(ex_solve, 3), "wall_s": round(ex_wall, 3)},
        "short_circuit_calls_derived": short_calls,
        "pruned": {"calls": pr_calls, "policies_checked": pr_checked, "solve_s": round(pr_solve, 3),
                   "wall_s": round(pr_wall, 3), "failure_basis": basis},
        "|F|": len(exF), "|A|": len(exA), "|Max(F)|": len(exMax), "Max(F)": sorted(exMax),
        "pruned_preserves_F_Max_A": (exF, exMax, exA) == (prF, prMax, prA),
        "matches_direct_evaluator": None if not expected_path.exists() else not mismatches,
        "mismatching_policies": mismatches,
        "sat4j_fallback_calls": sum(1 for row in csv.DictReader(open(r.log_path))
                                    if row["solver_warning"]),
    }
    (HERE / f"summary_{args.config}.json").write_text(json.dumps(summary, indent=1))
    with open(HERE / f"verdicts_{args.config}.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["policy", "safe", "useful", "category"])
        for k, v in ex.items():
            w.writerow([k, v["safe"], v["useful"],
                        ("Accept" if v["safe"] and v["useful"] else
                         "Privacy-Reject" if v["useful"] else
                         "Utility-Reject" if v["safe"] else "Both-Reject")])
    print(json.dumps(summary, indent=1))
    if mismatches or not summary["pruned_preserves_F_Max_A"]:
        print("\nWARNING: mismatch found -- do not report before inspecting.")


if __name__ == "__main__":
    main()
