/*
 * AlloyRunDriver.java
 *
 * Minimal headless runner for Alloy Analyzer models.
 *
 * Usage:
 *   java -cp "alloy.jar:." AlloyRunDriver model.als CommandName
 *
 * Example:
 *   java -cp "org.alloytools.alloy.dist.jar:." AlloyRunDriver \
 *        alloy_batch_runs/AgeExact_RegExact_DisExact_CheckTargetSafe.als \
 *        CheckTargetSafe
 *
 * Output contract for python_evaluator_small.py:
 *   - prints "Instance found. Predicate is consistent." when the named
 *     run command is SAT
 *   - prints "No instance found. Predicate may be inconsistent." when UNSAT
 *   - prints "Elapsed(ms): N" with the PURE SAT-solving time only
 *     (excludes JVM startup and file parsing), which python_evaluator_small.py
 *     parses separately from wall-clock time.
 *
 * Notes:
 *   This driver executes Alloy commands only. It does not redefine any
 *   verification semantics. It simply loads the .als file, finds the named
 *   command, runs it with a SAT solver, and prints a parseable result.
 *
 * ----------------------------------------------------------------------
 * IMPORT PATH NOTE (unverified against your local jar -- read this first)
 * ----------------------------------------------------------------------
 * The imports below use the modern org.alloytools.alloy package layout
 * (post-Alloy4 refactor, applicable to Alloy 5.x/6.x). If `javac` fails
 * with "package does not exist" errors, run this first to find the
 * actual paths in YOUR jar:
 *
 *   jar tf "$ALLOY_JAR" | grep -E "CompUtil\.class|A4Solution\.class|TranslateAlloyToKodkod\.class|/Command\.class"
 *
 * Then replace the failing import line(s) with whatever package the grep
 * output shows. The most common alternative (older Alloy 4.2-style jars)
 * uses this prefix instead:
 *   edu.mit.csail.sdg.alloy4compiler.ast.Command
 *   edu.mit.csail.sdg.alloy4compiler.ast.Module
 *   edu.mit.csail.sdg.alloy4compiler.parser.CompUtil
 *   edu.mit.csail.sdg.alloy4compiler.translator.A4Options
 *   edu.mit.csail.sdg.alloy4compiler.translator.A4Solution
 *   edu.mit.csail.sdg.alloy4compiler.translator.TranslateAlloyToKodkod
 * (i.e. insert "alloy4compiler." after "edu.mit.csail.sdg." in the four
 * lines below that currently read ast/parser/translator).
 * edu.mit.csail.sdg.alloy4.{A4Reporter,Err,ErrorWarning} is believed to
 * be stable across both layouts and should not need changing.
 */

import edu.mit.csail.sdg.alloy4.A4Reporter;
import edu.mit.csail.sdg.alloy4.Err;
import edu.mit.csail.sdg.alloy4.ErrorWarning;
import edu.mit.csail.sdg.ast.Command;
import edu.mit.csail.sdg.parser.CompUtil;
import edu.mit.csail.sdg.parser.CompModule;
import edu.mit.csail.sdg.translator.A4Options;
import edu.mit.csail.sdg.translator.A4Solution;
import edu.mit.csail.sdg.translator.TranslateAlloyToKodkod;

import java.io.File;

public final class AlloyRunDriver {
    private AlloyRunDriver() {}

    public static void main(String[] args) {
        if (args.length != 2) {
            System.err.println("Usage: java -cp \"alloy.jar:.\" AlloyRunDriver <model.als> <commandName>");
            System.exit(2);
        }

        String modelPath = args[0];
        String commandName = args[1];

        try {
            File modelFile = new File(modelPath);
            if (!modelFile.exists()) {
                System.err.println("Model file not found: " + modelPath);
                System.exit(2);
            }

            A4Reporter reporter = new A4Reporter() {
                @Override
                public void warning(ErrorWarning msg) {
                    System.err.println("Alloy warning: " + msg.toString().trim());
                }
            };

            CompModule world = CompUtil.parseEverything_fromFile(reporter, null, modelPath);
            Command target = null;

            for (Command command : world.getAllCommands()) {
                if (command.label != null && command.label.equals(commandName)) {
                    target = command;
                    break;
                }
            }

            if (target == null) {
                System.err.println("Command not found: " + commandName);
                System.err.println("Available commands:");
                for (Command command : world.getAllCommands()) {
                    System.err.println("  " + command.label);
                }
                System.exit(2);
            }

            A4Options options = new A4Options();
            options.solver = A4Options.SatSolver.MiniSatJNI;
            options.skolemDepth = 1;
            options.symmetry = 20;

            long start = System.currentTimeMillis();
            A4Solution solution;
            try {
                solution = TranslateAlloyToKodkod.execute_command(
                        reporter,
                        world.getAllReachableSigs(),
                        target,
                        options
                );
            } catch (UnsatisfiedLinkError | NoClassDefFoundError nativeLibError) {
                // MiniSatJNI's native library did not load in this process
                // (common cause: java.library.path not set the same way the
                // GUI sets it internally). Fall back to SAT4J so the batch
                // run still completes, but warn loudly since solving times
                // will then differ from Table 1/2's minisat(jni) figures.
                System.err.println(
                    "WARNING: MiniSatJNI native library failed to load ("
                    + nativeLibError.getClass().getSimpleName()
                    + "). Falling back to SAT4J for this call. Solving time "
                    + "will NOT be comparable to Table 1/2's minisat(jni) figures."
                );
                options.solver = A4Options.SatSolver.SAT4J;
                start = System.currentTimeMillis();
                solution = TranslateAlloyToKodkod.execute_command(
                        reporter,
                        world.getAllReachableSigs(),
                        target,
                        options
                );
            }
            long elapsed = System.currentTimeMillis() - start;

            System.out.println("Executing command: " + commandName);
            System.out.println("Model: " + modelPath);
            System.out.println("Elapsed(ms): " + elapsed);

            if (solution.satisfiable()) {
                System.out.println("Instance found. Predicate is consistent.");
                System.exit(0);
            } else {
                System.out.println("No instance found. Predicate may be inconsistent.");
                System.exit(0);
            }
        } catch (Err err) {
            System.err.println("Alloy error: " + err.toString());
            System.exit(1);
        } catch (Throwable t) {
            t.printStackTrace(System.err);
            System.exit(1);
        }
    }
}
