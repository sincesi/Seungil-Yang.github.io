"""
make_models_v2.py  --  Adult rerun v2 (2026-09-30)

Builds jisa_joint_experiment_adult{128,256}_v2.als from the ORIGINAL
adult models in the parent folder (../jisa_joint_experiment_adult{N}.als).
The originals are read only and never modified.

Exactly three semantic edits are applied; everything else (records,
transforms, policy order, task requirement ReqGQ, commands) is unchanged.

  1. Sensitive value = income.
     Original: Catt.sensitiveOf = sensOfDisease[r.disease] (occupation
     group), so the per-record income fact (r.sensitive) was never read by
     WPriv -- contrary to generate_adult_instance.py's stated intent.
     v2:       Catt.sensitiveOf = { r, s | s = r.sensitive }  (income).

  2. Exposure = income is a released (non-generalised) column.
     Original: exposure only when diseaseLevel = DisExact and s is the
     disease-derived value.
     v2:       ExposesSensitive[pi, d, s] iff s = d.sensitive, for every
     policy. A singleton linkage therefore discloses income. The third
     (occupation) axis now affects utility only.

  3. External record E1 = a record whose (age, workclass) quasi-identifier
     is UNIQUE in the dataset (first such record in R-order).
     Original: pick_linkage_pair() placed E1 on the first *colliding*
     QI cell (19 matches in adult128, 23 in adult256 at the finest
     policy). Because coarsening only enlarges match sets, Singleton could
     never hold, so every policy was Safe by construction.

Usage:  python3 make_models_v2.py        (writes both v2 models + E1 log)
"""
from __future__ import annotations

import collections
import csv
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent

OLD_CATT = (
    "fact CattSensitivityGroundedInDisease {\n"
    "  Catt.sensitiveOf = { r: Record, s: SensitiveValue |\n"
    "    s = sensOfDisease[r.disease]\n"
    "  }\n"
    "}"
)
NEW_CATT = (
    "-- v2 (2026-09-30): the sensitive attribute is income, taken directly\n"
    "-- from the per-record fact Adult256SensitiveFromIncome (r.sensitive).\n"
    "fact CattSensitivityFromIncome {\n"
    "  Catt.sensitiveOf = { r: Record, s: SensitiveValue |\n"
    "    s = r.sensitive\n"
    "  }\n"
    "}"
)
OLD_EXPOSE = (
    "pred ExposesSensitive[pi: Policy, d: Record, s: SensitiveValue] {\n"
    "  pi.diseaseLevel = DisExact\n"
    "  s = sensOfDisease[d.disease]\n"
    "}"
)
NEW_EXPOSE = (
    "-- v2 (2026-09-30): income is released as a non-generalised column, so\n"
    "-- a singleton linkage exposes it under every policy.\n"
    "pred ExposesSensitive[pi: Policy, d: Record, s: SensitiveValue] {\n"
    "  s = d.sensitive\n"
    "}"
)
EXT_RE = re.compile(
    r"fact Adult256ExternalInstance \{\n"
    r"  E1\.extAge = (\w+)\n"
    r"  E1\.extRegion = (\w+)\n"
    r"  E1\.linkedTo = (\w+)\n"
    r"\}"
)


def unique_qi_record(log_rows):
    counts = collections.Counter((r["age_atom"], r["region_atom"]) for r in log_rows)
    for r in log_rows:  # R-order
        if counts[(r["age_atom"], r["region_atom"])] == 1:
            return r, counts
    raise SystemExit("no record with a unique (age, workclass) QI")


def build(n: int) -> dict:
    src = PARENT / f"jisa_joint_experiment_adult{n}.als"
    log_path = PARENT / f"adult{n}_mapping_log.csv"
    text = src.read_text()
    rows = list(csv.DictReader(open(log_path)))
    assert len(rows) == n, (log_path, len(rows))

    assert text.count(OLD_CATT) == 1, "Catt block not found exactly once"
    text = text.replace(OLD_CATT, NEW_CATT, 1)
    assert text.count(OLD_EXPOSE) == 1, "ExposesSensitive block not found exactly once"
    text = text.replace(OLD_EXPOSE, NEW_EXPOSE, 1)

    m = EXT_RE.search(text)
    assert m, "external instance fact not found"
    old_e1 = {"extAge": m.group(1), "extRegion": m.group(2), "linkedTo": m.group(3)}
    target, counts = unique_qi_record(rows)
    new_ext = (
        "-- v2 (2026-09-30): E1 is the first record whose (age, workclass) QI\n"
        "-- is unique in the dataset (see make_models_v2.py).\n"
        "fact Adult256ExternalInstance {\n"
        f"  E1.extAge = {target['age_atom']}\n"
        f"  E1.extRegion = {target['region_atom']}\n"
        f"  E1.linkedTo = {target['record']}\n"
        "}"
    )
    text = text[: m.start()] + new_ext + text[m.end():]

    # guard: record scope must match n
    scopes = set(re.findall(r"exactly (\d+) Record", text))
    assert scopes == {str(n)}, f"unexpected Record scopes {scopes}"

    header = (
        f"-- ADULT RERUN v2 (2026-09-30), derived from {src.name}.\n"
        "-- Edits: (1) sensitive = income, (2) income released verbatim,\n"
        "-- (3) E1 on a unique-QI record. See make_models_v2.py.\n"
    )
    out = HERE / f"jisa_joint_experiment_adult{n}_v2.als"
    out.write_text(header + text)

    old_matches = sum(1 for r in rows if (r["age_atom"], r["region_atom"]) ==
                      (old_e1["extAge"], old_e1["extRegion"]))
    return {
        "n": n,
        "model": out.name,
        "old_E1": old_e1,
        "old_E1_matches_at_finest_policy": old_matches,
        "new_E1": {"extAge": target["age_atom"], "extRegion": target["region_atom"],
                   "linkedTo": target["record"],
                   "real_age": target["real_age"], "real_workclass": target["real_workclass"],
                   "real_income": target["real_income"]},
        "unique_qi_records": [r["record"] for r in rows
                              if counts[(r["age_atom"], r["region_atom"])] == 1],
    }


def main():
    info = [build(128), build(256)]
    (HERE / "E1_selection.json").write_text(json.dumps(info, indent=2))
    for i in info:
        print(f"adult{i['n']}: old E1 {i['old_E1']} matched {i['old_E1_matches_at_finest_policy']} records;"
              f" new E1 -> {i['new_E1']['linkedTo']} ({i['new_E1']['extAge']}, {i['new_E1']['extRegion']})")
    print("wrote", ", ".join(i["model"] for i in info), "and E1_selection.json")


if __name__ == "__main__":
    main()
