"""
direct_evaluator.py  --  independent Python reference for the Adult v2 models

Re-implements, for fixed concrete data, exactly the predicates of
jisa_joint_experiment_adult{N}_v2.als:
  T_pi(d)   = (TransformAge, TransformRegion, TransformDisease)
  L_pi      = {(d,e) | TQI_pi(d) = ExtQI_pi(e)}          (QI = age, region)
  WPriv(pi) = {(d,e,s) | (d,e) in L, L_pi(e) = {d}, s = d.sensitive}
  WUtil(pi) = ReqGQ & K_pi
Records, E1 and ReqGQ are read from the v2 .als file itself, so the
evaluator cannot silently drift from the model.

This is NOT a substitute for the Alloy run. It gives (a) the expected
verdicts to compare against Alloy, and (b) a direct-evaluation baseline
(ICFEM reviewer R2-1) with its own timing.

Usage:  python3 direct_evaluator.py 128     (or 256)
Writes: expected_adult{N}_v2.json
"""
from __future__ import annotations

import itertools
import json
import re
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent

AGE_LEVELS = ["AgeExact", "Age5yr", "Age10yr", "AgeAdult", "AgeSuppressed"]
REGION_LEVELS = ["RegExact", "RegPrefectureLvl", "RegCountryLvl", "RegSuppressedLvl"]
DISEASE_LEVELS = ["DisExact", "DisCategory", "DisSuppressed"]


def t_age(a, l):
    if l == "AgeExact":
        return a
    if l == "Age5yr":
        return {"A25": "25-29", "A27": "25-29", "A30": "30-34", "A35": "35-39",
                "A40": "40-44", "A45": "45-49"}.get(a, "50-54")
    if l == "Age10yr":
        return {"A25": "20s", "A27": "20s", "A30": "30s", "A35": "30s",
                "A40": "40s", "A45": "40s"}.get(a, "50s")
    if l == "AgeAdult":
        return "Adult"
    return "AgeSup"


def t_region(r, l):
    return {"RegExact": r, "RegPrefectureLvl": "Pref",
            "RegCountryLvl": "Country"}.get(l, "RegSup")


def t_disease(d, l):
    return {"DisExact": d, "DisCategory": "Chronic"}.get(l, "DisSup")


def load(n):
    text = (HERE / f"jisa_joint_experiment_adult{n}_v2.als").read_text()
    recs = {}
    for m in re.finditer(r"(R\d+)\.age = (\w+) and \1\.region = (\w+) and \1\.disease = (\w+)", text):
        recs[m.group(1)] = {"age": m.group(2), "region": m.group(3), "disease": m.group(4)}
    for m in re.finditer(r"(R\d+)\.sensitive = (\w+)", text):
        recs[m.group(1)]["sensitive"] = m.group(2)
    assert len(recs) == n and all("sensitive" in r for r in recs.values())
    e1 = dict(zip(("age", "region", "linkedTo"), re.search(
        r"E1\.extAge = (\w+)\n  E1\.extRegion = (\w+)\n  E1\.linkedTo = (\w+)", text).groups()))
    req = re.search(r"ReqGQ\.pairs = (\w+)->(\w+) \+ (\w+)->(\w+)", text).groups()
    pairs = {(req[0], req[1]), (req[2], req[3])}
    return recs, e1, pairs


def verdicts(recs, e1, pairs):
    out = {}
    for a, r, d in itertools.product(AGE_LEVELS, REGION_LEVELS, DISEASE_LEVELS):
        qi_e = (t_age(e1["age"], a), t_region(e1["region"], r))
        lset = [k for k, v in recs.items() if (t_age(v["age"], a), t_region(v["region"], r)) == qi_e]
        wpriv = [(lset[0], "E1", recs[lset[0]]["sensitive"])] if len(lset) == 1 else []
        T = {k: (t_age(v["age"], a), t_region(v["region"], r), t_disease(v["disease"], d))
             for k, v in recs.items()}
        wutil = sorted(p for p in pairs if T[p[0]] == T[p[1]])
        out[(a, r, d)] = {"safe": not wpriv, "useful": not wutil, "L_size": len(lset),
                          "WPriv": wpriv, "WUtil": wutil}
    return out


def preceq(p, q):
    return (AGE_LEVELS.index(p[0]) <= AGE_LEVELS.index(q[0]) and
            REGION_LEVELS.index(p[1]) <= REGION_LEVELS.index(q[1]) and
            DISEASE_LEVELS.index(p[2]) <= DISEASE_LEVELS.index(q[2]))


def summarize(v):
    P = list(v)
    F = [p for p in P if v[p]["useful"]]
    A = [p for p in F if v[p]["safe"]]
    fail = [p for p in P if not v[p]["useful"]]
    B = [p for p in fail if not any(q != p and preceq(q, p) for q in fail)]
    Max = [p for p in F if not any(q != p and preceq(p, q) for q in F)]
    cats = {"safe_useful": 0, "unsafe_useful": 0, "safe_violating": 0, "unsafe_violating": 0}
    for p in P:
        cats[("safe" if v[p]["safe"] else "unsafe") + "_" +
             ("useful" if v[p]["useful"] else "violating")] += 1
    return {
        "categories": cats,
        "|F|": len(F), "|A|": len(A), "|B|": len(B), "|Max(F)|": len(Max),
        "Max(F)": ["_".join(p) for p in Max], "B": ["_".join(p) for p in B],
        "A": ["_".join(p) for p in A],
        "calls": {"exhaustive": 2 * len(P), "short_circuit": len(P) + len(F),
                  "pruned": 2 * len(F) + len(B)},
    }


def main():
    n = int(sys.argv[1])
    recs, e1, pairs = load(n)
    t0 = time.perf_counter()
    v = verdicts(recs, e1, pairs)
    elapsed = time.perf_counter() - t0
    s = summarize(v)
    s["direct_eval_seconds_all_60_policies"] = round(elapsed, 4)
    s["E1"] = e1
    s["ReqGQ"] = sorted(pairs)
    s["per_policy"] = {"_".join(k): val for k, val in v.items()}
    out = HERE / f"expected_adult{n}_v2.json"
    out.write_text(json.dumps(s, indent=1))
    print(json.dumps({k: s[k] for k in ("categories", "|F|", "|A|", "|B|", "|Max(F)|",
                                          "Max(F)", "B", "calls",
                                          "direct_eval_seconds_all_60_policies")}, indent=1))
    print("wrote", out.name)


if __name__ == "__main__":
    main()
