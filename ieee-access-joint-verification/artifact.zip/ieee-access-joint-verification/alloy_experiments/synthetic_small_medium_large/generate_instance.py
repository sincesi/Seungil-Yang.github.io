"""
generate_instance.py

Deterministic generator for Medium/Large scale instances of
jisa_joint_experiment_v1.als. Reuses the exact same core ontology
(Def.1-17, all Parts) that was already validated for the Small
configuration; only the Small-specific instance facts (record data,
external record, task requirement, "admit everything" governance fact,
and the record/external-record `one sig` declarations) are replaced.
Everything else in the file -- including PolicyDistinctness, which is
NOT scale-specific and must stay exactly as validated -- is left
untouched.

Design principle (documented for the paper's reproducibility section):
Unlike the Small configuration -- where R3/R4 collapse only on the
REGION axis -- Medium/Large use THREE violation types, cycled
deterministically across generated record pairs, so the frontier
structure is not a trivial scale-up of Small's single-axis pattern:

  type 0 (region-collapse):  same age, same disease, different region.
    Collapses once regionLevel != RegExact (TransformRegion maps every
    region to the same RPrefecture value from RegPrefectureLvl up).
  type 1 (age-collapse):     same region, same disease, ages A25 vs A27.
    Collapses once ageLevel = Age5yr or coarser (TransformAge maps both
    A25 and A27 to RAge25to29 at Age5yr).
  type 2 (disease-collapse): same age, same region, different disease.
    Collapses once diseaseLevel = DisCategory or coarser (TransformDisease
    maps every disease to RChronic at DisCategory).

This means Medium/Large are expected to have MULTIPLE incomparable
minimal violating policies (one per violation type actually present),
unlike Small's single dominating violator.

Usage:
    python3 generate_instance.py
    (writes jisa_joint_experiment_medium.als and _large.als directly)
"""

from pathlib import Path

CORE_FILE = Path("jisa_joint_experiment_v1.als")

AGES = ["A25", "A27", "A30", "A35", "A40", "A45", "A50"]
REGIONS = ["Kanazawa", "Komatsu", "Toyama"]
DISEASES = ["Diabetes", "Hypertension", "Cancer"]

# Verbatim blocks from the canonical Small file (Part 2 and Part 4),
# used as exact-match anchors for replacement. Keeping these as named
# constants (rather than fuzzy markers) means a failed match raises a
# clear "substring not found" error instead of silently mis-splicing.

SMALL_RECORD_DECL = "one sig R1, R2, R3, R4 extends Record {}"

SMALL_RECORD_COMMENT = (
    "-- Small configuration records.\n"
    "-- R1/R2 share region; R3/R4 share age and disease but differ in region,\n"
    "-- so Req(G,Q) below requires them to remain distinguishable on a\n"
    "-- region-driven collapse -- independent of the disease axis that drives\n"
    "-- privacy exposure (ExposesSensitive, Part 5).\n"
)

SMALL_RECORD_INSTANCE_FACT = (
    "fact SmallRecordInstance {\n"
    "  R1.age = A25 and R1.region = Kanazawa and R1.disease = Diabetes\n"
    "  R2.age = A27 and R2.region = Kanazawa and R2.disease = Hypertension\n"
    "  R3.age = A40 and R3.region = Komatsu  and R3.disease = Diabetes\n"
    "  R4.age = A40 and R4.region = Toyama   and R4.disease = Diabetes\n"
    "}"
)

SMALL_GOV_BLOCK = (
    "sig GovAdmissible in Policy {}\n"
    "fact SmallGovernanceAllPoliciesAdmissible {\n"
    "  GovAdmissible = Policy\n"
    "}"
)

SMALL_EXTERNAL_DECL_AND_FACT = (
    "one sig E1 extends ExternalRecord {}\n\n"
    "fact SmallExternalInstance {\n"
    "  E1.extAge = A25\n"
    "  E1.extRegion = Kanazawa\n"
    "  E1.linkedTo = R1\n"
    "}"
)

SMALL_TASK_COMMENT_AND_FACT = (
    "-- The Small task requires R3 and R4 to remain distinguishable.\n"
    "fact SmallTaskRequirement {\n"
    "  ReqGQ.pairs = R3->R4 + R4->R3\n"
    "}"
)


def gen_pairs(n_records: int):
    """Generate twin-pair records R3..R{n_records}. R1/R2 stay as the
    fixed filler pair used for the ExternalRecord E1 linkage, exactly
    as in Small. Returns (record_facts: list[str], req_terms: list[str],
    record_names: list[str] including R1,R2)."""
    assert n_records >= 4 and n_records % 2 == 0, "need an even N >= 4"
    n_pairs = (n_records - 2) // 2
    facts = []
    req_terms = []
    names = ["R1", "R2"]

    for k in range(1, n_pairs + 1):
        vtype = (k - 1) % 3
        name_a = f"R{2*k+1}"
        name_b = f"R{2*k+2}"
        names += [name_a, name_b]

        if vtype == 0:  # region-collapse: same age/disease, diff region
            age = AGES[k % len(AGES)]
            dis = DISEASES[k % len(DISEASES)]
            reg_a = REGIONS[k % 3]
            reg_b = REGIONS[(k + 1) % 3]
            facts.append(f"  {name_a}.age = {age} and {name_a}.region = {reg_a} and {name_a}.disease = {dis}")
            facts.append(f"  {name_b}.age = {age} and {name_b}.region = {reg_b} and {name_b}.disease = {dis}")
        elif vtype == 1:  # age-collapse: same region/disease, A25 vs A27
            reg = REGIONS[k % 3]
            dis = DISEASES[k % len(DISEASES)]
            facts.append(f"  {name_a}.age = A25 and {name_a}.region = {reg} and {name_a}.disease = {dis}")
            facts.append(f"  {name_b}.age = A27 and {name_b}.region = {reg} and {name_b}.disease = {dis}")
        else:  # disease-collapse: same age/region, different disease
            age = AGES[k % len(AGES)]
            reg = REGIONS[k % 3]
            dis_a = DISEASES[k % 3]
            dis_b = DISEASES[(k + 1) % 3]
            facts.append(f"  {name_a}.age = {age} and {name_a}.region = {reg} and {name_a}.disease = {dis_a}")
            facts.append(f"  {name_b}.age = {age} and {name_b}.region = {reg} and {name_b}.disease = {dis_b}")

        req_terms.append(f"{name_a}->{name_b}")
        req_terms.append(f"{name_b}->{name_a}")

    return facts, req_terms, names


SMALL_VALIDATION_NOTE = (
    "Validated locally (Alloy Analyzer, minisat(jni)) on 2026-07-03:\n"
    "  FindAcceptablePolicy_Final, FindPrivacyReject_Final,\n"
    "  FindUtilityReject_Final, FindBothReject_Final: all \"Instance found\".\n"
    "  KernelInclusionSanity_Final, UtilityWitnessInclusionSanity_Final:\n"
    "  \"No counterexample found\" (bounded evidence only, not a proof).\n"
    "  FindPrivacyNonMonotoneExample_Final: \"Instance found\".\n"
    "  Small instance: R3/R4 differ by REGION (not disease), so privacy\n"
    "  rejection (disease-axis) and utility rejection (region-axis) can\n"
    "  co-occur -- this is what makes FindBothReject_Final satisfiable."
)


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise ValueError(f"Expected exactly 1 occurrence of {label}, found {count}")
    return text.replace(old, new, 1)


def build_file(scale_name: str, n_records: int) -> str:
    text = CORE_FILE.read_text()
    record_facts, req_terms, all_names = gen_pairs(n_records)
    n_pairs = (n_records - 2) // 2
    types_used = sorted({(k - 1) % 3 for k in range(1, n_pairs + 1)})

    # 0. Stale "Validated locally" note (Small-specific results that do
    #    not apply here, and even misdescribe R3/R4 for this scale) ->
    #    an honest "not yet validated" placeholder.
    new_validation_note = (
        f"Validated locally: NOT YET RUN for this {scale_name} configuration.\n"
        f"  This file was generated by generate_instance.py from the validated\n"
        f"  Small configuration's core ontology; only the instance data below\n"
        f"  (records, external record, task requirement) is new and has not\n"
        f"  been executed. Replace this note with actual local Alloy Analyzer\n"
        f"  results (command names, SAT/UNSAT, solving time) once run."
    )
    text = replace_once(text, SMALL_VALIDATION_NOTE, new_validation_note, "validated-locally header note")

    # 1. Module name
    text = replace_once(
        text, "module jisa_joint_experiment_v1",
        f"module jisa_joint_experiment_{scale_name}", "module declaration"
    )

    # 2. Record declaration comment
    new_comment = (
        f"-- {scale_name.capitalize()} configuration records.\n"
        f"-- Generated by generate_instance.py: R1/R2 are the fixed filler\n"
        f"-- pair used for the ExternalRecord E1 linkage (as in Small).\n"
        f"-- R3..R{n_records} form {n_pairs} twin pairs cycling through violation\n"
        f"-- types {types_used} (0=region-collapse, 1=age-collapse,\n"
        f"-- 2=disease-collapse); see generate_instance.py docstring.\n"
    )
    text = replace_once(text, SMALL_RECORD_COMMENT, new_comment, "record declaration comment")

    # 3. one sig R1..RN declaration
    record_sig_decl = ", ".join(all_names)
    text = replace_once(
        text, SMALL_RECORD_DECL,
        f"one sig {record_sig_decl} extends Record {{}}", "record sig declaration"
    )

    # 4. SmallRecordInstance fact -> scale-specific fact
    record_union = " + ".join(all_names)
    new_fact = (
        f"fact {scale_name.capitalize()}RecordInstance {{\n"
        "  R1.age = A25 and R1.region = Kanazawa and R1.disease = Diabetes\n"
        "  R2.age = A27 and R2.region = Kanazawa and R2.disease = Hypertension\n"
        + "\n".join(record_facts) + "\n"
        f"  Record = {record_union}\n"
        "}"
    )
    text = replace_once(text, SMALL_RECORD_INSTANCE_FACT, new_fact, "SmallRecordInstance fact")

    # 5. Governance block (sig + fact) -> renamed fact, same semantics
    new_gov = (
        "sig GovAdmissible in Policy {}\n"
        f"fact {scale_name.capitalize()}GovernanceAllPoliciesAdmissible {{\n"
        "  GovAdmissible = Policy\n"
        "}"
    )
    text = replace_once(text, SMALL_GOV_BLOCK, new_gov, "governance block")

    # 6. ExternalRecord declaration + SmallExternalInstance fact (kept
    #    identical in content -- only E1/R1 linkage, same for all scales)
    new_ext = (
        "one sig E1 extends ExternalRecord {}\n\n"
        f"fact {scale_name.capitalize()}ExternalInstance {{\n"
        "  E1.extAge = A25\n"
        "  E1.extRegion = Kanazawa\n"
        "  E1.linkedTo = R1\n"
        "}"
    )
    text = replace_once(text, SMALL_EXTERNAL_DECL_AND_FACT, new_ext, "external record block")

    # 7. Task requirement fact -> all generated pairs
    req_pairs_expr = " +\n    ".join(req_terms)
    new_task = (
        f"-- The {scale_name.capitalize()} task requires each twin pair to remain\n"
        f"-- distinguishable ({n_pairs} pairs, types {types_used}).\n"
        f"fact {scale_name.capitalize()}TaskRequirement {{\n"
        f"  ReqGQ.pairs =\n    {req_pairs_expr}\n"
        "}"
    )
    text = replace_once(text, SMALL_TASK_COMMENT_AND_FACT, new_task, "task requirement fact")

    # 8. Scale the Record/ExternalRecord scope in every `for exactly ...`
    #    command clause (ExternalRecord stays 1 across all scales).
    text = text.replace("exactly 4 Record", f"exactly {n_records} Record")

    # 9. Two remaining generic prose references to "Small" (not tied to
    #    specific fact names, so not worth a dedicated constant above).
    text = text.replace(
        "-- private helper: exposed sensitive value. In this Small model, exact",
        f"-- private helper: exposed sensitive value. In this {scale_name} model, exact",
    )
    text = text.replace(
        "-- the Small Configuration Instance facts above, Safe[TargetPolicy] and",
        f"-- the {scale_name.capitalize()} Configuration Instance facts above, Safe[TargetPolicy] and",
    )
    text = text.replace(
        "-- In the Small configuration, governance admits all product policies.",
        f"-- In this {scale_name} configuration, governance admits all product policies.",
    )

    return text


def main():
    for scale_name, n in [("medium", 16), ("large", 64)]:
        content = build_file(scale_name, n)
        out_path = Path(f"jisa_joint_experiment_{scale_name}.als")
        out_path.write_text(content)
        print(f"wrote {out_path} ({len(content)} bytes, {n} records)")


if __name__ == "__main__":
    main()
