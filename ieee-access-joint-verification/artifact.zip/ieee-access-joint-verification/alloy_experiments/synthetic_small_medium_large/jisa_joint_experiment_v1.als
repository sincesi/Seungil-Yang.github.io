module jisa_joint_experiment_v1

/*
======================================================================
JISA Executable Reference Semantics
----------------------------------------------------------------------
This Alloy model is the executable reference semantics corresponding
to Definitions 1-17 (Definition Blueprint v1.0). Its purpose is not
implementation convenience but faithful execution of the formal
definitions: Paper Definition N -> Alloy code -> Python reads output.
Python scripts consume the outputs of this model; they never redefine
its privacy/utility semantics (Executable Semantics Rule ES-1). The
generalization order over Pi (Def.4, preceqG below) is a closed
combinatorial structure independent of privacy/utility semantics and
MAY be replicated in Python for pruning control-flow; this is not a
semantics redefinition.

Governance context (G), threat specification (C_att), and task
specification (Req(G,Q)) are FIXED EXOGENOUS INPUTS. Only privacy and
utility are verified. There is no Governance verdict, no
Contract-Satisfying(pi) / Contract-Violating(pi) in this model
(deprecated for JISA; candidate owner: FM2027).

Naming: "jisa_joint_experiment_v1" is canonical and edited in place.
Do not create "_final", "_v2", etc. suffixes; archive superseded
snapshots under archive/ instead. This file is a distinct lineage from
"journal_joint_v3.als" (dissertation-track, governance-inclusive
model); do not treat it as a version successor of that file.

Validated locally (Alloy Analyzer, minisat(jni)) on 2026-07-03:
  FindAcceptablePolicy_Final, FindPrivacyReject_Final,
  FindUtilityReject_Final, FindBothReject_Final: all "Instance found".
  KernelInclusionSanity_Final, UtilityWitnessInclusionSanity_Final:
  "No counterexample found" (bounded evidence only, not a proof).
  FindPrivacyNonMonotoneExample_Final: "Instance found".
  Small instance: R3/R4 differ by REGION (not disease), so privacy
  rejection (disease-axis) and utility rejection (region-axis) can
  co-occur -- this is what makes FindBothReject_Final satisfiable.

----------------------------------------------------------------------
Def <-> Alloy correspondence table  (Executable Semantics Rule ES-2)
----------------------------------------------------------------------
 Def   | Alloy symbol                         | Public? | Depends on
-------|--------------------------------------|---------|-------------------
 Def.1 | sig Record                           | Yes     | -
 Def.2 | one sig G                            | Yes     | -
 Def.3 | one sig Q                            | Yes     | -
 Def.4 | sig Policy                           | Yes     | -
 Def.5 | sig GovAdmissible in Policy          | Yes     | Policy, G
 Def.6 | fun CandidatePolicies                | Yes     | GovAdmissible
 Def.7 | fun T                                | Yes     | Policy, Record
 Def.8 | fun DRel                             | Yes     | T
 Def.9 | one sig Catt                         | Yes     | -
 Def.10| one sig ReqGQ                        | Yes     | G, Q
 Def.11| pred PrivacyPropertyHolds            | Yes     | L (private), Catt
 Def.12| pred UtilityPropertyHolds            | Yes     | K (private), ReqGQ
 Def.13| fun WPriv                            | Yes     | L
 Def.14| fun WUtil                            | Yes     | K, ReqGQ
 Def.15| pred Safe / pred Unsafe              | Yes     | PrivacyPropertyHolds
 Def.16| pred Useful / pred UtilityViolating  | Yes     | UtilityPropertyHolds
 Def.17| pred Accept                          | Yes     | Safe, Useful
-------|--------------------------------------|---------|-------------------
 (private) fun K   -- released-tuple kernel, used inside Def.12
 (private) fun L   -- attacker link relation, used inside Def.11
 (private) fun TQI / ExtQI / TransformAge / TransformRegion /
           TransformDisease / ExposesSensitive
           -- helpers; not independent Definition objects.
 (batch)   one sig TargetPolicy in Policy {}
           -- pinned per Python-driven invocation; see Part 10.

Executable Semantics Rules (locked):
  ES-1  This model is the reference semantics; Python never redefines
        privacy/utility semantics (it may replicate the structural
        order preceqG for pruning control-flow only).
  ES-2  Public API = names in the table above only. Everything else is a
        private helper and MUST NOT be treated as a Definition.
  ES-3  Dependency direction mirrors the Blueprint's dependency graphs:
        Transformation -> Relation -> Property -> Evidence -> Verdict ->
        Joint Satisfiability. A lower layer never calls an upper layer.
  ES-4  Witness sets (WPriv, WUtil) are computed results of a Relation;
        Verdicts call the Property predicate, never the Witness or the
        Relation directly (Rule V1).
======================================================================
*/

-- ======================================================================
-- Part 1. Domain Vocabulary
-- Experimental domain values for the illustrative medical dataset.
-- These are NOT ontology objects defined in Blueprint Def.1-17; they
-- instantiate Record, Policy, and released-value vocabularies.
-- ======================================================================

abstract sig Age {}
one sig A25, A27, A30, A35, A40, A45, A50 extends Age {}

abstract sig Region {}
one sig Kanazawa, Komatsu, Toyama extends Region {}

abstract sig Disease {}
one sig Diabetes, Hypertension, Cancer extends Disease {}

abstract sig SensitiveValue {}
one sig SDiabetes, SHypertension, SCancer extends SensitiveValue {}

-- Ground-truth mapping from disease to sensitive value (domain fact,
-- not part of Catt). Used to ground Catt.sensitiveOf below, so that
-- Def.9's Sens_Catt(d) is not disconnected from the disease field.
fun sensOfDisease[d: Disease]: one SensitiveValue {
  d = Diabetes          => SDiabetes
  else d = Hypertension => SHypertension
  else                     SCancer
}

-- ======================================================================
-- Part 2. Structural Objects  (Def.1-6)
-- ======================================================================

-- Def.1 Original Dataset D
abstract sig Record {
  age       : one Age,
  region    : one Region,
  disease   : one Disease,
  sensitive : one SensitiveValue
}

-- Small configuration records.
-- R1/R2 share region; R3/R4 share age and disease but differ in region,
-- so Req(G,Q) below requires them to remain distinguishable on a
-- region-driven collapse -- independent of the disease axis that drives
-- privacy exposure (ExposesSensitive, Part 5).
one sig R1, R2, R3, R4 extends Record {}

fact SmallRecordInstance {
  R1.age = A25 and R1.region = Kanazawa and R1.disease = Diabetes
  R2.age = A27 and R2.region = Kanazawa and R2.disease = Hypertension
  R3.age = A40 and R3.region = Komatsu  and R3.disease = Diabetes
  R4.age = A40 and R4.region = Toyama   and R4.disease = Diabetes
}
fact SensitiveMatchesDisease {
  all r: Record | r.sensitive = sensOfDisease[r.disease]
}

-- Def.2 Governance Context G (fixed, exogenous; never verified here)
one sig G {}

-- Def.3 Task Context Q (fixed)
one sig Q {}

-- Released vocabulary: the codomain components of T_pi.
abstract sig ReleasedAge {}
one sig RAge25, RAge27, RAge30, RAge35, RAge40, RAge45, RAge50,
        RAge25to29, RAge30to34, RAge35to39, RAge40to44,
        RAge45to49, RAge50to54,
        RAge20s, RAge30s, RAge40s, RAge50s,
        RAdult, RAgeSuppressed extends ReleasedAge {}

abstract sig ReleasedRegion {}
one sig RKanazawa, RKomatsu, RToyama,
        RPrefecture, RCountry, RRegionSuppressed extends ReleasedRegion {}

abstract sig ReleasedDisease {}
one sig RDiabetes, RHypertension, RCancer,
        RChronic, RDiseaseSuppressed extends ReleasedDisease {}

-- Policy generalization axes (each a total order; see facts below)
abstract sig AgeLevel     { agePreceq: set AgeLevel }
abstract sig RegionLevel  { regPreceq: set RegionLevel }
abstract sig DiseaseLevel { disPreceq: set DiseaseLevel }

one sig AgeExact, Age5yr, Age10yr, AgeAdult, AgeSuppressed extends AgeLevel {}
one sig RegExact, RegPrefectureLvl, RegCountryLvl, RegSuppressedLvl extends RegionLevel {}
one sig DisExact, DisCategory, DisSuppressed extends DiseaseLevel {}

fact AgeOrder {
  agePreceq =
    AgeExact -> Age5yr +
    Age5yr   -> Age10yr +
    Age10yr  -> AgeAdult +
    AgeAdult -> AgeSuppressed
}

fact RegionOrder {
  regPreceq =
    RegExact          -> RegPrefectureLvl +
    RegPrefectureLvl  -> RegCountryLvl +
    RegCountryLvl     -> RegSuppressedLvl
}

fact DiseaseOrder {
  disPreceq =
    DisExact    -> DisCategory +
    DisCategory -> DisSuppressed
}

-- Def.4 Policy Space Pi (product lattice over generalization axes)
sig Policy {
  ageLevel     : one AgeLevel,
  regionLevel  : one RegionLevel,
  diseaseLevel : one DiseaseLevel
}

-- Ensure exactly one policy per product-lattice coordinate when the
-- command scope uses exactly 60 Policy.
fact PolicyDistinctness {
  all disj p1, p2: Policy |
    p1.ageLevel != p2.ageLevel or
    p1.regionLevel != p2.regionLevel or
    p1.diseaseLevel != p2.diseaseLevel
}

-- Generalization order over Pi: pi_a preceq_G pi_b iff pi_b is at least
-- as coarse as pi_a on every axis. (Structural; see header note on
-- Python replication for pruning control-flow.)
pred preceqG[pa, pb: Policy] {
  pa.ageLevel     in pb.ageLevel.*(~agePreceq)
  pa.regionLevel  in pb.regionLevel.*(~regPreceq)
  pa.diseaseLevel in pb.diseaseLevel.*(~disPreceq)
}

-- Def.5 Governance-Restricted Policy Space Pi_gov(G) subseteq Pi
-- In the Small configuration, governance admits all product policies.
-- Later registry experiments may replace this fact with a strict subset.
sig GovAdmissible in Policy {}
fact SmallGovernanceAllPoliciesAdmissible {
  GovAdmissible = Policy
}

-- Def.6 Candidate Policy: pi in Pi_gov(G)
fun CandidatePolicies : set Policy { GovAdmissible }

-- ======================================================================
-- Part 3. Transformation  (Def.7-8)
-- Public API: fun T and fun DRel. Other functions in this part are
-- private helpers and do not correspond to independent Definitions.
-- ======================================================================

-- private helper
fun TransformAge[a: Age, l: AgeLevel]: one ReleasedAge {
  l = AgeExact => (
    a = A25 => RAge25
    else a = A27 => RAge27
    else a = A30 => RAge30
    else a = A35 => RAge35
    else a = A40 => RAge40
    else a = A45 => RAge45
    else RAge50
  )
  else l = Age5yr => (
    a in A25 + A27 => RAge25to29
    else a = A30 => RAge30to34
    else a = A35 => RAge35to39
    else a = A40 => RAge40to44
    else a = A45 => RAge45to49
    else RAge50to54
  )
  else l = Age10yr => (
    a in A25 + A27 => RAge20s
    else a in A30 + A35 => RAge30s
    else a in A40 + A45 => RAge40s
    else RAge50s
  )
  else l = AgeAdult => RAdult
  else RAgeSuppressed
}

-- private helper
fun TransformRegion[r: Region, l: RegionLevel]: one ReleasedRegion {
  l = RegExact => (
    r = Kanazawa => RKanazawa
    else r = Komatsu => RKomatsu
    else RToyama
  )
  -- All sample cities collapse to a single prefecture-level bucket in
  -- this illustrative 3-city domain.
  else l = RegPrefectureLvl => RPrefecture
  else l = RegCountryLvl    => RCountry
  else RRegionSuppressed
}

-- private helper
fun TransformDisease[d: Disease, l: DiseaseLevel]: one ReleasedDisease {
  l = DisExact => (
    d = Diabetes => RDiabetes
    else d = Hypertension => RHypertension
    else RCancer
  )
  else l = DisCategory => RChronic
  else RDiseaseSuppressed
}

-- Def.7 Transformation T_pi : D -> D_rel  (PUBLIC)
-- Implemented directly as a released tuple relation. No ReleasedTuple atom
-- is used, avoiding a separate existence/uniqueness obligation.
fun T[pi: Policy, r: Record] : ReleasedAge -> ReleasedRegion -> ReleasedDisease {
  TransformAge[r.age, pi.ageLevel]
  -> TransformRegion[r.region, pi.regionLevel]
  -> TransformDisease[r.disease, pi.diseaseLevel]
}

-- Def.8 Released Dataset D_rel = T_pi(D)  (PUBLIC)
fun DRel[pi: Policy] : ReleasedAge -> ReleasedRegion -> ReleasedDisease {
  { a: ReleasedAge, rg: ReleasedRegion, dis: ReleasedDisease |
      some r: Record | a->rg->dis = T[pi, r]
  }
}

-- ======================================================================
-- Part 4. Specifications  (Def.9-10)
-- ======================================================================

-- ExternalRecord implements D_ext(Catt): the external-information
-- component encoded inside the fixed threat specification Catt. It is
-- not an additional Structural Object in the JISA ontology.
abstract sig ExternalRecord {
  extAge    : one Age,
  extRegion : one Region,
  linkedTo  : one Record       -- ground truth for diagnostics; not used by L
}
one sig E1 extends ExternalRecord {}

fact SmallExternalInstance {
  E1.extAge = A25
  E1.extRegion = Kanazawa
  E1.linkedTo = R1
}

-- Def.9 Threat Specification C_att
one sig Catt {
  sensitiveOf : Record -> SensitiveValue
}

fact CattSensitivityGroundedInDisease {
  Catt.sensitiveOf = { r: Record, s: SensitiveValue |
    s = sensOfDisease[r.disease]
  }
}

-- Def.10 Task Specification Req(G,Q) subseteq D x D
one sig ReqGQ {
  pairs: Record -> Record
}

-- The Small task requires R3 and R4 to remain distinguishable.
fact SmallTaskRequirement {
  ReqGQ.pairs = R3->R4 + R4->R3
}

-- ======================================================================
-- Part 5. Properties / Relation Layer  (Def.11-12)
-- ======================================================================

-- private helper: released quasi-identifier of a record under policy pi
-- Privacy linkage uses only age and region as QI. Disease is sensitive
-- and is intentionally NOT part of the matching key.
fun TQI[pi: Policy, r: Record] : ReleasedAge -> ReleasedRegion {
  TransformAge[r.age, pi.ageLevel]
  -> TransformRegion[r.region, pi.regionLevel]
}

-- private helper: external quasi-identifier abstracted at the same policy level
fun ExtQI[pi: Policy, e: ExternalRecord] : ReleasedAge -> ReleasedRegion {
  TransformAge[e.extAge, pi.ageLevel]
  -> TransformRegion[e.extRegion, pi.regionLevel]
}

-- private notation inside Def.12: released-tuple kernel K_pi
fun K[pi: Policy] : Record -> Record {
  { d1, d2: Record | T[pi, d1] = T[pi, d2] }
}

-- private notation inside Def.11: link relation L_pi^Catt
fun L[pi: Policy] : Record -> ExternalRecord {
  { d: Record, e: ExternalRecord | TQI[pi, d] = ExtQI[pi, e] }
}

-- L_pi(e) = { d | (d,e) in L_pi }
fun Lset[pi: Policy, e: ExternalRecord] : set Record {
  L[pi].e
}

-- Singleton_pi^Catt(d,e) iff L_pi(e) = {d}
pred Singleton[pi: Policy, d: Record, e: ExternalRecord] {
  Lset[pi, e] = d
}

-- private helper: exposed sensitive value. In this Small model, exact
-- disease release exposes the corresponding sensitive disease value;
-- category/suppressed disease release does not expose the exact value.
pred ExposesSensitive[pi: Policy, d: Record, s: SensitiveValue] {
  pi.diseaseLevel = DisExact
  s = sensOfDisease[d.disease]
}

-- Def.11 Privacy Property: holds iff WPriv is empty (defined below)
pred PrivacyPropertyHolds[pi: Policy] {
  no WPriv[pi]
}

-- Def.12 Utility Property: holds iff WUtil is empty (defined below)
pred UtilityPropertyHolds[pi: Policy] {
  no WUtil[pi]
}

-- ======================================================================
-- Part 6. Evidence / Witness Sets  (Def.13-14)
-- ======================================================================

-- Def.13 Privacy-Violating Witness
fun WPriv[pi: Policy] : Record -> ExternalRecord -> SensitiveValue {
  { d: Record, e: ExternalRecord, s: SensitiveValue |
      d->e in L[pi]
      and Singleton[pi, d, e]
      and s in d.(Catt.sensitiveOf)
      and ExposesSensitive[pi, d, s]
  }
}

-- Def.14 Utility-Violating Witness
fun WUtil[pi: Policy] : Record -> Record {
  ReqGQ.pairs & K[pi]
}

-- ======================================================================
-- Part 7. Verdicts / Joint Satisfiability  (Def.15-17)
-- Verdicts call Property predicates only (Rule V1).
-- ======================================================================

-- Def.15 Privacy Verdict
pred Safe[pi: Policy]   { PrivacyPropertyHolds[pi] }
pred Unsafe[pi: Policy] { not PrivacyPropertyHolds[pi] }

-- Def.16 Utility Verdict
pred Useful[pi: Policy]           { UtilityPropertyHolds[pi] }
pred UtilityViolating[pi: Policy] { not UtilityPropertyHolds[pi] }

-- Def.17 Joint Satisfiability
pred Accept[pi: Policy] { Safe[pi] and Useful[pi] }

-- ======================================================================
-- Part 8. Theoretical Sanity Checks (bounded evidence only, NOT theorem
-- proofs). Uncomment to re-run individually.
-- ======================================================================

check KernelInclusionSanity {
  all pa, pb: CandidatePolicies |
    preceqG[pa, pb] implies K[pa] in K[pb]
} for exactly 4 Record, exactly 60 Policy, exactly 1 ExternalRecord

check UtilityWitnessInclusionSanity {
  all pa, pb: CandidatePolicies |
    preceqG[pa, pb] implies WUtil[pa] in WUtil[pb]
} for exactly 4 Record, exactly 60 Policy, exactly 1 ExternalRecord

-- Privacy is intentionally not asserted as monotone.
run FindPrivacyNonMonotoneExample {
  some pa, pb: CandidatePolicies |
    preceqG[pa, pb]
    and some WPriv[pa]
    and no WPriv[pb]
} for exactly 4 Record, exactly 60 Policy, exactly 1 ExternalRecord

-- ======================================================================
-- Part 9. Example Runs for Table 1A/1B Diagnostics
-- ======================================================================

run FindAcceptablePolicy {
  some pi: CandidatePolicies | Accept[pi]
} for exactly 4 Record, exactly 60 Policy, exactly 1 ExternalRecord

run FindPrivacyReject {
  some pi: CandidatePolicies | Unsafe[pi]
} for exactly 4 Record, exactly 60 Policy, exactly 1 ExternalRecord

run FindUtilityReject {
  some pi: CandidatePolicies | UtilityViolating[pi]
} for exactly 4 Record, exactly 60 Policy, exactly 1 ExternalRecord

run FindBothReject {
  some pi: CandidatePolicies | Unsafe[pi] and UtilityViolating[pi]
} for exactly 4 Record, exactly 60 Policy, exactly 1 ExternalRecord

-- ======================================================================
-- Part 10. Batch Invocation Support (Table 3: Exhaustive vs. Pruning)
-- ----------------------------------------------------------------------
-- TargetPolicy is pinned to ONE of the existing 60 Policy atoms per
-- external invocation, via a generated fact identifying it by its
-- (ageLevel,regionLevel,diseaseLevel) coordinate. It is declared "in
-- Policy" (a subset/alias), NOT "extends Policy" -- extends would add a
-- 61st atom, which (combined with PolicyDistinctness) would make every
-- CheckTargetSafe/CheckTargetUseful run vacuously inconsistent, since no
-- 61st atom can share a coordinate with one of the 60 without violating
-- PolicyDistinctness. As a subset of the existing 60, TargetPolicy simply
-- designates which already-pinned atom is under test.
--
-- Because Record, ExternalRecord, Catt, and ReqGQ are already pinned by
-- the Small Configuration Instance facts above, Safe[TargetPolicy] and
-- Useful[TargetPolicy] become GROUND (variable-free) formulas once
-- TargetPolicy is pinned -- so the SAT/UNSAT verdict of each `run` below
-- IS the truth value of that formula, not an existential search.
--
-- Python generates one fact block (see python_evaluator_small.py) of
-- the form:
--   fact PinTargetPolicy {
--     TargetPolicy.ageLevel = <AgeLevelAtom>
--     TargetPolicy.regionLevel = <RegionLevelAtom>
--     TargetPolicy.diseaseLevel = <DiseaseLevelAtom>
--   }
-- and appends it (plus exactly one of the two `run` commands below) to a
-- copy of this file before invoking Alloy headlessly.
-- ======================================================================

one sig TargetPolicy in Policy {}

-- These two commands are only meaningful in a Python-generated COPY of
-- this file that also includes a PinTargetPolicy fact (see above).
-- Left commented out here so that running this canonical file top-to-
-- bottom does not silently execute an unpinned (existential) query.
--run CheckTargetSafe   { Safe[TargetPolicy]   } for exactly 4 Record, exactly 60 Policy, exactly 1 ExternalRecord
--run CheckTargetUseful { Useful[TargetPolicy] } for exactly 4 Record, exactly 60 Policy, exactly 1 ExternalRecord
