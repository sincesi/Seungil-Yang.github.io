#!/usr/bin/env bash
set -euo pipefail

# Usage:
#   ./run_table3.sh /path/to/alloy.jar [small|medium|large|all]
#
# Default scale is "all" (runs small, then medium, then large in sequence).
#
# Required files in the current directory:
#   - jisa_joint_experiment_v1.als       (Small, 4 records)
#   - jisa_joint_experiment_medium.als   (Medium, 16 records; via generate_instance.py)
#   - jisa_joint_experiment_large.als    (Large, 64 records; via generate_instance.py)
#   - python_evaluator.py
#   - AlloyRunDriver.java

ALLOY_JAR="${1:-alloy.jar}"
SCALE="${2:-all}"

if [[ ! -f "$ALLOY_JAR" ]]; then
  echo "Alloy jar not found: $ALLOY_JAR" >&2
  echo "Pass the jar path, e.g.: ./run_table3.sh /Applications/Alloy/org.alloytools.alloy.dist.jar all" >&2
  exit 1
fi

if [[ ! -f "AlloyRunDriver.java" ]]; then
  echo "AlloyRunDriver.java not found in current directory." >&2
  exit 1
fi

if [[ ! -f "python_evaluator.py" ]]; then
  echo "python_evaluator.py not found in current directory." >&2
  exit 1
fi

javac -cp "$ALLOY_JAR" AlloyRunDriver.java
export ALLOY_CMD="java -cp $ALLOY_JAR:. AlloyRunDriver {als} {cmd}"

run_scale() {
  local scale="$1"
  local als_file="$2"
  if [[ ! -f "$als_file" ]]; then
    echo "Skipping $scale: $als_file not found (run generate_instance.py first if this is medium/large)." >&2
    return 0
  fi
  echo "=============================================="
  echo "Running Table 3 for scale: $scale ($als_file)"
  echo "=============================================="
  python3 python_evaluator.py "$scale"
}

case "$SCALE" in
  small)  run_scale small  jisa_joint_experiment_v1.als ;;
  medium) run_scale medium jisa_joint_experiment_medium.als ;;
  large)  run_scale large  jisa_joint_experiment_large.als ;;
  all)
    run_scale small  jisa_joint_experiment_v1.als
    run_scale medium jisa_joint_experiment_medium.als
    run_scale large  jisa_joint_experiment_large.als
    ;;
  *)
    echo "Unknown scale: $SCALE (expected small|medium|large|all)" >&2
    exit 2
    ;;
esac
