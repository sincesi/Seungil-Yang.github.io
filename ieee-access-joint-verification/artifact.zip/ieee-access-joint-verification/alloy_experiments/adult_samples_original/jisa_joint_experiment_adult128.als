module jisa_joint_experiment_v1

/*
======================================================================
JISA Executable Reference Semantics
----------------------------------------------------------------------
This Alloy model is the executable reference semantics corresponding
to Definitions 1-17 (Definition Blueprint v1.0). Its purpose is not
implementation convenience but faithful execution of the formal
definitions: Paper Definition N -> Alloy code -> Python reads output.
Python scripts consume the outputs of this model; they never redefine
its privacy/utility semantics (Executable Semantics Rule ES-1). The
generalization order over Pi (Def.4, preceqG below) is a closed
combinatorial structure independent of privacy/utility semantics and
MAY be replicated in Python for pruning control-flow; this is not a
semantics redefinition.

Governance context (G), threat specification (C_att), and task
specification (Req(G,Q)) are FIXED EXOGENOUS INPUTS. Only privacy and
utility are verified. There is no Governance verdict, no
Contract-Satisfying(pi) / Contract-Violating(pi) in this model
(deprecated for JISA; candidate owner: FM2027).

Naming: "jisa_joint_experiment_v1" is canonical and edited in place.
Do not create "_final", "_v2", etc. suffixes; archive superseded
snapshots under archive/ instead. This file is a distinct lineage from
"journal_joint_v3.als" (dissertation-track, governance-inclusive
model); do not treat it as a version successor of that file.

Validated locally (Alloy Analyzer, minisat(jni)) on 2026-07-03:
  FindAcceptablePolicy_Final, FindPrivacyReject_Final,
  FindUtilityReject_Final, FindBothReject_Final: all "Instance found".
  KernelInclusionSanity_Final, UtilityWitnessInclusionSanity_Final:
  "No counterexample found" (bounded evidence only, not a proof).
  FindPrivacyNonMonotoneExample_Final: "Instance found".
  Small instance: R3/R4 differ by REGION (not disease), so privacy
  rejection (disease-axis) and utility rejection (region-axis) can
  co-occur -- this is what makes FindBothReject_Final satisfiable.

----------------------------------------------------------------------
Def <-> Alloy correspondence table  (Executable Semantics Rule ES-2)
----------------------------------------------------------------------
 Def   | Alloy symbol                         | Public? | Depends on
-------|--------------------------------------|---------|-------------------
 Def.1 | sig Record                           | Yes     | -
 Def.2 | one sig G                            | Yes     | -
 Def.3 | one sig Q                            | Yes     | -
 Def.4 | sig Policy                           | Yes     | -
 Def.5 | sig GovAdmissible in Policy          | Yes     | Policy, G
 Def.6 | fun CandidatePolicies                | Yes     | GovAdmissible
 Def.7 | fun T                                | Yes     | Policy, Record
 Def.8 | fun DRel                             | Yes     | T
 Def.9 | one sig Catt                         | Yes     | -
 Def.10| one sig ReqGQ                        | Yes     | G, Q
 Def.11| pred PrivacyPropertyHolds            | Yes     | L (private), Catt
 Def.12| pred UtilityPropertyHolds            | Yes     | K (private), ReqGQ
 Def.13| fun WPriv                            | Yes     | L
 Def.14| fun WUtil                            | Yes     | K, ReqGQ
 Def.15| pred Safe / pred Unsafe              | Yes     | PrivacyPropertyHolds
 Def.16| pred Useful / pred UtilityViolating  | Yes     | UtilityPropertyHolds
 Def.17| pred Accept                          | Yes     | Safe, Useful
-------|--------------------------------------|---------|-------------------
 (private) fun K   -- released-tuple kernel, used inside Def.12
 (private) fun L   -- attacker link relation, used inside Def.11
 (private) fun TQI / ExtQI / TransformAge / TransformRegion /
           TransformDisease / ExposesSensitive
           -- helpers; not independent Definition objects.
 (batch)   one sig TargetPolicy in Policy {}
           -- pinned per Python-driven invocation; see Part 10.

Executable Semantics Rules (locked):
  ES-1  This model is the reference semantics; Python never redefines
        privacy/utility semantics (it may replicate the structural
        order preceqG for pruning control-flow only).
  ES-2  Public API = names in the table above only. Everything else is a
        private helper and MUST NOT be treated as a Definition.
  ES-3  Dependency direction mirrors the Blueprint's dependency graphs:
        Transformation -> Relation -> Property -> Evidence -> Verdict ->
        Joint Satisfiability. A lower layer never calls an upper layer.
  ES-4  Witness sets (WPriv, WUtil) are computed results of a Relation;
        Verdicts call the Property predicate, never the Witness or the
        Relation directly (Rule V1).
======================================================================
*/

-- ======================================================================
-- Part 1. Domain Vocabulary
-- Experimental domain values for the illustrative medical dataset.
-- These are NOT ontology objects defined in Blueprint Def.1-17; they
-- instantiate Record, Policy, and released-value vocabularies.
-- ======================================================================

abstract sig Age {}
one sig A25, A27, A30, A35, A40, A45, A50 extends Age {}

abstract sig Region {}
one sig Kanazawa, Komatsu, Toyama extends Region {}

abstract sig Disease {}
one sig Diabetes, Hypertension, Cancer extends Disease {}

abstract sig SensitiveValue {}
one sig SDiabetes, SHypertension, SCancer extends SensitiveValue {}

-- Ground-truth mapping from disease to sensitive value (domain fact,
-- not part of Catt). Used to ground Catt.sensitiveOf below, so that
-- Def.9's Sens_Catt(d) is not disconnected from the disease field.
fun sensOfDisease[d: Disease]: one SensitiveValue {
  d = Diabetes          => SDiabetes
  else d = Hypertension => SHypertension
  else                     SCancer
}

-- ======================================================================
-- Part 2. Structural Objects  (Def.1-6)
-- ======================================================================

-- Def.1 Original Dataset D
abstract sig Record {
  age       : one Age,
  region    : one Region,
  disease   : one Disease,
  sensitive : one SensitiveValue
}

-- Adult-256 applicability probe: 256 real UCI Adult records
-- (seed=42 sample, missing-value rows excluded), mapped onto the
-- SAME validated raw-value vocabulary as the Small configuration.
-- Age = nearest of {25,27,30,35,40,45,50} to real age.
-- Region slot = workclass group (Kanazawa=Private, Komatsu=Government,
-- Toyama=Self-employed). Disease slot = occupation group
-- (Diabetes=White-collar, Hypertension=Blue-collar, Cancer=Service).
-- See generate_adult_instance.py for the exact per-record mapping log.
one sig R1, R2, R3, R4, R5, R6, R7, R8, R9, R10, R11, R12, R13, R14, R15, R16, R17, R18, R19, R20, R21, R22, R23, R24, R25, R26, R27, R28, R29, R30, R31, R32, R33, R34, R35, R36, R37, R38, R39, R40, R41, R42, R43, R44, R45, R46, R47, R48, R49, R50, R51, R52, R53, R54, R55, R56, R57, R58, R59, R60, R61, R62, R63, R64, R65, R66, R67, R68, R69, R70, R71, R72, R73, R74, R75, R76, R77, R78, R79, R80, R81, R82, R83, R84, R85, R86, R87, R88, R89, R90, R91, R92, R93, R94, R95, R96, R97, R98, R99, R100, R101, R102, R103, R104, R105, R106, R107, R108, R109, R110, R111, R112, R113, R114, R115, R116, R117, R118, R119, R120, R121, R122, R123, R124, R125, R126, R127, R128 extends Record {}

fact Adult256RecordInstance {
  R1.age = A50 and R1.region = Toyama and R1.disease = Hypertension
  R2.age = A50 and R2.region = Kanazawa and R2.disease = Cancer
  R3.age = A45 and R3.region = Toyama and R3.disease = Diabetes
  R4.age = A30 and R4.region = Kanazawa and R4.disease = Diabetes
  R5.age = A25 and R5.region = Kanazawa and R5.disease = Hypertension
  R6.age = A40 and R6.region = Toyama and R6.disease = Hypertension
  R7.age = A50 and R7.region = Kanazawa and R7.disease = Hypertension
  R8.age = A50 and R8.region = Kanazawa and R8.disease = Diabetes
  R9.age = A25 and R9.region = Kanazawa and R9.disease = Hypertension
  R10.age = A50 and R10.region = Kanazawa and R10.disease = Hypertension
  R11.age = A45 and R11.region = Toyama and R11.disease = Diabetes
  R12.age = A50 and R12.region = Komatsu and R12.disease = Diabetes
  R13.age = A45 and R13.region = Kanazawa and R13.disease = Diabetes
  R14.age = A45 and R14.region = Kanazawa and R14.disease = Diabetes
  R15.age = A25 and R15.region = Kanazawa and R15.disease = Diabetes
  R16.age = A25 and R16.region = Kanazawa and R16.disease = Hypertension
  R17.age = A35 and R17.region = Toyama and R17.disease = Cancer
  R18.age = A25 and R18.region = Kanazawa and R18.disease = Diabetes
  R19.age = A35 and R19.region = Kanazawa and R19.disease = Hypertension
  R20.age = A45 and R20.region = Komatsu and R20.disease = Diabetes
  R21.age = A50 and R21.region = Kanazawa and R21.disease = Hypertension
  R22.age = A25 and R22.region = Kanazawa and R22.disease = Cancer
  R23.age = A40 and R23.region = Kanazawa and R23.disease = Hypertension
  R24.age = A35 and R24.region = Komatsu and R24.disease = Diabetes
  R25.age = A40 and R25.region = Komatsu and R25.disease = Diabetes
  R26.age = A45 and R26.region = Kanazawa and R26.disease = Hypertension
  R27.age = A50 and R27.region = Kanazawa and R27.disease = Diabetes
  R28.age = A25 and R28.region = Kanazawa and R28.disease = Cancer
  R29.age = A25 and R29.region = Kanazawa and R29.disease = Cancer
  R30.age = A25 and R30.region = Kanazawa and R30.disease = Hypertension
  R31.age = A25 and R31.region = Toyama and R31.disease = Cancer
  R32.age = A25 and R32.region = Komatsu and R32.disease = Diabetes
  R33.age = A27 and R33.region = Kanazawa and R33.disease = Diabetes
  R34.age = A27 and R34.region = Kanazawa and R34.disease = Diabetes
  R35.age = A50 and R35.region = Kanazawa and R35.disease = Cancer
  R36.age = A45 and R36.region = Komatsu and R36.disease = Diabetes
  R37.age = A35 and R37.region = Komatsu and R37.disease = Diabetes
  R38.age = A35 and R38.region = Kanazawa and R38.disease = Cancer
  R39.age = A35 and R39.region = Kanazawa and R39.disease = Hypertension
  R40.age = A30 and R40.region = Kanazawa and R40.disease = Diabetes
  R41.age = A50 and R41.region = Kanazawa and R41.disease = Diabetes
  R42.age = A35 and R42.region = Kanazawa and R42.disease = Hypertension
  R43.age = A40 and R43.region = Kanazawa and R43.disease = Diabetes
  R44.age = A30 and R44.region = Kanazawa and R44.disease = Hypertension
  R45.age = A25 and R45.region = Kanazawa and R45.disease = Hypertension
  R46.age = A40 and R46.region = Kanazawa and R46.disease = Hypertension
  R47.age = A50 and R47.region = Komatsu and R47.disease = Diabetes
  R48.age = A25 and R48.region = Kanazawa and R48.disease = Hypertension
  R49.age = A40 and R49.region = Kanazawa and R49.disease = Cancer
  R50.age = A50 and R50.region = Kanazawa and R50.disease = Hypertension
  R51.age = A50 and R51.region = Kanazawa and R51.disease = Hypertension
  R52.age = A30 and R52.region = Kanazawa and R52.disease = Hypertension
  R53.age = A30 and R53.region = Kanazawa and R53.disease = Diabetes
  R54.age = A30 and R54.region = Kanazawa and R54.disease = Diabetes
  R55.age = A35 and R55.region = Kanazawa and R55.disease = Hypertension
  R56.age = A45 and R56.region = Komatsu and R56.disease = Hypertension
  R57.age = A25 and R57.region = Kanazawa and R57.disease = Diabetes
  R58.age = A25 and R58.region = Kanazawa and R58.disease = Hypertension
  R59.age = A50 and R59.region = Komatsu and R59.disease = Diabetes
  R60.age = A25 and R60.region = Kanazawa and R60.disease = Hypertension
  R61.age = A45 and R61.region = Toyama and R61.disease = Hypertension
  R62.age = A35 and R62.region = Kanazawa and R62.disease = Diabetes
  R63.age = A35 and R63.region = Kanazawa and R63.disease = Hypertension
  R64.age = A50 and R64.region = Kanazawa and R64.disease = Cancer
  R65.age = A30 and R65.region = Kanazawa and R65.disease = Cancer
  R66.age = A27 and R66.region = Kanazawa and R66.disease = Diabetes
  R67.age = A40 and R67.region = Kanazawa and R67.disease = Diabetes
  R68.age = A45 and R68.region = Kanazawa and R68.disease = Hypertension
  R69.age = A40 and R69.region = Kanazawa and R69.disease = Hypertension
  R70.age = A25 and R70.region = Kanazawa and R70.disease = Cancer
  R71.age = A40 and R71.region = Kanazawa and R71.disease = Diabetes
  R72.age = A25 and R72.region = Kanazawa and R72.disease = Hypertension
  R73.age = A50 and R73.region = Toyama and R73.disease = Diabetes
  R74.age = A30 and R74.region = Kanazawa and R74.disease = Diabetes
  R75.age = A25 and R75.region = Toyama and R75.disease = Diabetes
  R76.age = A35 and R76.region = Kanazawa and R76.disease = Diabetes
  R77.age = A50 and R77.region = Toyama and R77.disease = Diabetes
  R78.age = A30 and R78.region = Kanazawa and R78.disease = Diabetes
  R79.age = A50 and R79.region = Kanazawa and R79.disease = Cancer
  R80.age = A40 and R80.region = Kanazawa and R80.disease = Diabetes
  R81.age = A50 and R81.region = Kanazawa and R81.disease = Diabetes
  R82.age = A45 and R82.region = Kanazawa and R82.disease = Diabetes
  R83.age = A30 and R83.region = Komatsu and R83.disease = Diabetes
  R84.age = A40 and R84.region = Kanazawa and R84.disease = Diabetes
  R85.age = A50 and R85.region = Kanazawa and R85.disease = Diabetes
  R86.age = A45 and R86.region = Toyama and R86.disease = Hypertension
  R87.age = A50 and R87.region = Kanazawa and R87.disease = Diabetes
  R88.age = A40 and R88.region = Kanazawa and R88.disease = Cancer
  R89.age = A45 and R89.region = Kanazawa and R89.disease = Diabetes
  R90.age = A30 and R90.region = Kanazawa and R90.disease = Cancer
  R91.age = A30 and R91.region = Kanazawa and R91.disease = Hypertension
  R92.age = A25 and R92.region = Kanazawa and R92.disease = Cancer
  R93.age = A40 and R93.region = Toyama and R93.disease = Diabetes
  R94.age = A50 and R94.region = Kanazawa and R94.disease = Cancer
  R95.age = A25 and R95.region = Kanazawa and R95.disease = Hypertension
  R96.age = A50 and R96.region = Kanazawa and R96.disease = Cancer
  R97.age = A50 and R97.region = Toyama and R97.disease = Diabetes
  R98.age = A50 and R98.region = Toyama and R98.disease = Diabetes
  R99.age = A27 and R99.region = Toyama and R99.disease = Diabetes
  R100.age = A30 and R100.region = Kanazawa and R100.disease = Diabetes
  R101.age = A35 and R101.region = Kanazawa and R101.disease = Diabetes
  R102.age = A35 and R102.region = Kanazawa and R102.disease = Diabetes
  R103.age = A40 and R103.region = Kanazawa and R103.disease = Diabetes
  R104.age = A50 and R104.region = Kanazawa and R104.disease = Diabetes
  R105.age = A25 and R105.region = Kanazawa and R105.disease = Cancer
  R106.age = A45 and R106.region = Komatsu and R106.disease = Diabetes
  R107.age = A40 and R107.region = Toyama and R107.disease = Hypertension
  R108.age = A30 and R108.region = Kanazawa and R108.disease = Hypertension
  R109.age = A50 and R109.region = Toyama and R109.disease = Hypertension
  R110.age = A50 and R110.region = Komatsu and R110.disease = Diabetes
  R111.age = A50 and R111.region = Kanazawa and R111.disease = Hypertension
  R112.age = A30 and R112.region = Kanazawa and R112.disease = Hypertension
  R113.age = A25 and R113.region = Kanazawa and R113.disease = Diabetes
  R114.age = A27 and R114.region = Kanazawa and R114.disease = Hypertension
  R115.age = A35 and R115.region = Kanazawa and R115.disease = Hypertension
  R116.age = A50 and R116.region = Komatsu and R116.disease = Hypertension
  R117.age = A45 and R117.region = Kanazawa and R117.disease = Hypertension
  R118.age = A45 and R118.region = Kanazawa and R118.disease = Diabetes
  R119.age = A25 and R119.region = Kanazawa and R119.disease = Hypertension
  R120.age = A35 and R120.region = Toyama and R120.disease = Hypertension
  R121.age = A40 and R121.region = Toyama and R121.disease = Hypertension
  R122.age = A45 and R122.region = Komatsu and R122.disease = Diabetes
  R123.age = A35 and R123.region = Kanazawa and R123.disease = Diabetes
  R124.age = A27 and R124.region = Kanazawa and R124.disease = Diabetes
  R125.age = A45 and R125.region = Kanazawa and R125.disease = Diabetes
  R126.age = A27 and R126.region = Kanazawa and R126.disease = Diabetes
  R127.age = A25 and R127.region = Kanazawa and R127.disease = Diabetes
  R128.age = A30 and R128.region = Kanazawa and R128.disease = Diabetes
}
fact Adult256SensitiveFromIncome {
  R1.sensitive = SHypertension
  R2.sensitive = SHypertension
  R3.sensitive = SHypertension
  R4.sensitive = SHypertension
  R5.sensitive = SHypertension
  R6.sensitive = SHypertension
  R7.sensitive = SHypertension
  R8.sensitive = SHypertension
  R9.sensitive = SHypertension
  R10.sensitive = SHypertension
  R11.sensitive = SDiabetes
  R12.sensitive = SHypertension
  R13.sensitive = SHypertension
  R14.sensitive = SDiabetes
  R15.sensitive = SHypertension
  R16.sensitive = SHypertension
  R17.sensitive = SHypertension
  R18.sensitive = SHypertension
  R19.sensitive = SHypertension
  R20.sensitive = SDiabetes
  R21.sensitive = SDiabetes
  R22.sensitive = SHypertension
  R23.sensitive = SHypertension
  R24.sensitive = SHypertension
  R25.sensitive = SDiabetes
  R26.sensitive = SHypertension
  R27.sensitive = SHypertension
  R28.sensitive = SHypertension
  R29.sensitive = SHypertension
  R30.sensitive = SHypertension
  R31.sensitive = SHypertension
  R32.sensitive = SHypertension
  R33.sensitive = SHypertension
  R34.sensitive = SHypertension
  R35.sensitive = SHypertension
  R36.sensitive = SDiabetes
  R37.sensitive = SDiabetes
  R38.sensitive = SHypertension
  R39.sensitive = SDiabetes
  R40.sensitive = SHypertension
  R41.sensitive = SHypertension
  R42.sensitive = SHypertension
  R43.sensitive = SDiabetes
  R44.sensitive = SHypertension
  R45.sensitive = SHypertension
  R46.sensitive = SHypertension
  R47.sensitive = SDiabetes
  R48.sensitive = SDiabetes
  R49.sensitive = SDiabetes
  R50.sensitive = SHypertension
  R51.sensitive = SHypertension
  R52.sensitive = SHypertension
  R53.sensitive = SDiabetes
  R54.sensitive = SDiabetes
  R55.sensitive = SHypertension
  R56.sensitive = SHypertension
  R57.sensitive = SHypertension
  R58.sensitive = SHypertension
  R59.sensitive = SHypertension
  R60.sensitive = SHypertension
  R61.sensitive = SHypertension
  R62.sensitive = SHypertension
  R63.sensitive = SDiabetes
  R64.sensitive = SHypertension
  R65.sensitive = SHypertension
  R66.sensitive = SHypertension
  R67.sensitive = SHypertension
  R68.sensitive = SDiabetes
  R69.sensitive = SHypertension
  R70.sensitive = SHypertension
  R71.sensitive = SHypertension
  R72.sensitive = SHypertension
  R73.sensitive = SHypertension
  R74.sensitive = SHypertension
  R75.sensitive = SHypertension
  R76.sensitive = SDiabetes
  R77.sensitive = SDiabetes
  R78.sensitive = SDiabetes
  R79.sensitive = SHypertension
  R80.sensitive = SHypertension
  R81.sensitive = SHypertension
  R82.sensitive = SHypertension
  R83.sensitive = SHypertension
  R84.sensitive = SDiabetes
  R85.sensitive = SHypertension
  R86.sensitive = SHypertension
  R87.sensitive = SDiabetes
  R88.sensitive = SHypertension
  R89.sensitive = SDiabetes
  R90.sensitive = SHypertension
  R91.sensitive = SDiabetes
  R92.sensitive = SHypertension
  R93.sensitive = SDiabetes
  R94.sensitive = SDiabetes
  R95.sensitive = SHypertension
  R96.sensitive = SHypertension
  R97.sensitive = SDiabetes
  R98.sensitive = SHypertension
  R99.sensitive = SDiabetes
  R100.sensitive = SHypertension
  R101.sensitive = SDiabetes
  R102.sensitive = SHypertension
  R103.sensitive = SDiabetes
  R104.sensitive = SHypertension
  R105.sensitive = SHypertension
  R106.sensitive = SDiabetes
  R107.sensitive = SHypertension
  R108.sensitive = SHypertension
  R109.sensitive = SDiabetes
  R110.sensitive = SDiabetes
  R111.sensitive = SHypertension
  R112.sensitive = SHypertension
  R113.sensitive = SHypertension
  R114.sensitive = SDiabetes
  R115.sensitive = SHypertension
  R116.sensitive = SHypertension
  R117.sensitive = SHypertension
  R118.sensitive = SDiabetes
  R119.sensitive = SHypertension
  R120.sensitive = SHypertension
  R121.sensitive = SHypertension
  R122.sensitive = SDiabetes
  R123.sensitive = SHypertension
  R124.sensitive = SHypertension
  R125.sensitive = SHypertension
  R126.sensitive = SHypertension
  R127.sensitive = SHypertension
  R128.sensitive = SHypertension
}

-- Def.2 Governance Context G (fixed, exogenous; never verified here)
one sig G {}

-- Def.3 Task Context Q (fixed)
one sig Q {}

-- Released vocabulary: the codomain components of T_pi.
abstract sig ReleasedAge {}
one sig RAge25, RAge27, RAge30, RAge35, RAge40, RAge45, RAge50,
        RAge25to29, RAge30to34, RAge35to39, RAge40to44,
        RAge45to49, RAge50to54,
        RAge20s, RAge30s, RAge40s, RAge50s,
        RAdult, RAgeSuppressed extends ReleasedAge {}

abstract sig ReleasedRegion {}
one sig RKanazawa, RKomatsu, RToyama,
        RPrefecture, RCountry, RRegionSuppressed extends ReleasedRegion {}

abstract sig ReleasedDisease {}
one sig RDiabetes, RHypertension, RCancer,
        RChronic, RDiseaseSuppressed extends ReleasedDisease {}

-- Policy generalization axes (each a total order; see facts below)
abstract sig AgeLevel     { agePreceq: set AgeLevel }
abstract sig RegionLevel  { regPreceq: set RegionLevel }
abstract sig DiseaseLevel { disPreceq: set DiseaseLevel }

one sig AgeExact, Age5yr, Age10yr, AgeAdult, AgeSuppressed extends AgeLevel {}
one sig RegExact, RegPrefectureLvl, RegCountryLvl, RegSuppressedLvl extends RegionLevel {}
one sig DisExact, DisCategory, DisSuppressed extends DiseaseLevel {}

fact AgeOrder {
  agePreceq =
    AgeExact -> Age5yr +
    Age5yr   -> Age10yr +
    Age10yr  -> AgeAdult +
    AgeAdult -> AgeSuppressed
}

fact RegionOrder {
  regPreceq =
    RegExact          -> RegPrefectureLvl +
    RegPrefectureLvl  -> RegCountryLvl +
    RegCountryLvl     -> RegSuppressedLvl
}

fact DiseaseOrder {
  disPreceq =
    DisExact    -> DisCategory +
    DisCategory -> DisSuppressed
}

-- Def.4 Policy Space Pi (product lattice over generalization axes)
sig Policy {
  ageLevel     : one AgeLevel,
  regionLevel  : one RegionLevel,
  diseaseLevel : one DiseaseLevel
}

-- Ensure exactly one policy per product-lattice coordinate when the
-- command scope uses exactly 60 Policy.
fact PolicyDistinctness {
  all disj p1, p2: Policy |
    p1.ageLevel != p2.ageLevel or
    p1.regionLevel != p2.regionLevel or
    p1.diseaseLevel != p2.diseaseLevel
}

-- Generalization order over Pi: pi_a preceq_G pi_b iff pi_b is at least
-- as coarse as pi_a on every axis. (Structural; see header note on
-- Python replication for pruning control-flow.)
pred preceqG[pa, pb: Policy] {
  pa.ageLevel     in pb.ageLevel.*(~agePreceq)
  pa.regionLevel  in pb.regionLevel.*(~regPreceq)
  pa.diseaseLevel in pb.diseaseLevel.*(~disPreceq)
}

-- Def.5 Governance-Restricted Policy Space Pi_gov(G) subseteq Pi
-- In the Small configuration, governance admits all product policies.
-- Later registry experiments may replace this fact with a strict subset.
sig GovAdmissible in Policy {}
fact SmallGovernanceAllPoliciesAdmissible {
  GovAdmissible = Policy
}

-- Def.6 Candidate Policy: pi in Pi_gov(G)
fun CandidatePolicies : set Policy { GovAdmissible }

-- ======================================================================
-- Part 3. Transformation  (Def.7-8)
-- Public API: fun T and fun DRel. Other functions in this part are
-- private helpers and do not correspond to independent Definitions.
-- ======================================================================

-- private helper
fun TransformAge[a: Age, l: AgeLevel]: one ReleasedAge {
  l = AgeExact => (
    a = A25 => RAge25
    else a = A27 => RAge27
    else a = A30 => RAge30
    else a = A35 => RAge35
    else a = A40 => RAge40
    else a = A45 => RAge45
    else RAge50
  )
  else l = Age5yr => (
    a in A25 + A27 => RAge25to29
    else a = A30 => RAge30to34
    else a = A35 => RAge35to39
    else a = A40 => RAge40to44
    else a = A45 => RAge45to49
    else RAge50to54
  )
  else l = Age10yr => (
    a in A25 + A27 => RAge20s
    else a in A30 + A35 => RAge30s
    else a in A40 + A45 => RAge40s
    else RAge50s
  )
  else l = AgeAdult => RAdult
  else RAgeSuppressed
}

-- private helper
fun TransformRegion[r: Region, l: RegionLevel]: one ReleasedRegion {
  l = RegExact => (
    r = Kanazawa => RKanazawa
    else r = Komatsu => RKomatsu
    else RToyama
  )
  -- All sample cities collapse to a single prefecture-level bucket in
  -- this illustrative 3-city domain.
  else l = RegPrefectureLvl => RPrefecture
  else l = RegCountryLvl    => RCountry
  else RRegionSuppressed
}

-- private helper
fun TransformDisease[d: Disease, l: DiseaseLevel]: one ReleasedDisease {
  l = DisExact => (
    d = Diabetes => RDiabetes
    else d = Hypertension => RHypertension
    else RCancer
  )
  else l = DisCategory => RChronic
  else RDiseaseSuppressed
}

-- Def.7 Transformation T_pi : D -> D_rel  (PUBLIC)
-- Implemented directly as a released tuple relation. No ReleasedTuple atom
-- is used, avoiding a separate existence/uniqueness obligation.
fun T[pi: Policy, r: Record] : ReleasedAge -> ReleasedRegion -> ReleasedDisease {
  TransformAge[r.age, pi.ageLevel]
  -> TransformRegion[r.region, pi.regionLevel]
  -> TransformDisease[r.disease, pi.diseaseLevel]
}

-- Def.8 Released Dataset D_rel = T_pi(D)  (PUBLIC)
fun DRel[pi: Policy] : ReleasedAge -> ReleasedRegion -> ReleasedDisease {
  { a: ReleasedAge, rg: ReleasedRegion, dis: ReleasedDisease |
      some r: Record | a->rg->dis = T[pi, r]
  }
}

-- ======================================================================
-- Part 4. Specifications  (Def.9-10)
-- ======================================================================

-- ExternalRecord implements D_ext(Catt): the external-information
-- component encoded inside the fixed threat specification Catt. It is
-- not an additional Structural Object in the JISA ontology.
abstract sig ExternalRecord {
  extAge    : one Age,
  extRegion : one Region,
  linkedTo  : one Record       -- ground truth for diagnostics; not used by L
}
one sig E1 extends ExternalRecord {}

fact Adult256ExternalInstance {
  E1.extAge = A50
  E1.extRegion = Kanazawa
  E1.linkedTo = R7
}

-- Def.9 Threat Specification C_att
one sig Catt {
  sensitiveOf : Record -> SensitiveValue
}

fact CattSensitivityGroundedInDisease {
  Catt.sensitiveOf = { r: Record, s: SensitiveValue |
    s = sensOfDisease[r.disease]
  }
}

-- Def.10 Task Specification Req(G,Q) subseteq D x D
one sig ReqGQ {
  pairs: Record -> Record
}

-- The Adult-256 task requires this real-data-derived pair to
-- remain distinguishable (same age/occupation group, different
-- workclass group -- a region-slot-driven collapse, analogous to
-- Small's R3/R4 pair).
fact Adult256TaskRequirement {
  ReqGQ.pairs = R1->R7 + R7->R1
}

-- ======================================================================
-- Part 5. Properties / Relation Layer  (Def.11-12)
-- ======================================================================

-- private helper: released quasi-identifier of a record under policy pi
-- Privacy linkage uses only age and region as QI. Disease is sensitive
-- and is intentionally NOT part of the matching key.
fun TQI[pi: Policy, r: Record] : ReleasedAge -> ReleasedRegion {
  TransformAge[r.age, pi.ageLevel]
  -> TransformRegion[r.region, pi.regionLevel]
}

-- private helper: external quasi-identifier abstracted at the same policy level
fun ExtQI[pi: Policy, e: ExternalRecord] : ReleasedAge -> ReleasedRegion {
  TransformAge[e.extAge, pi.ageLevel]
  -> TransformRegion[e.extRegion, pi.regionLevel]
}

-- private notation inside Def.12: released-tuple kernel K_pi
fun K[pi: Policy] : Record -> Record {
  { d1, d2: Record | T[pi, d1] = T[pi, d2] }
}

-- private notation inside Def.11: link relation L_pi^Catt
fun L[pi: Policy] : Record -> ExternalRecord {
  { d: Record, e: ExternalRecord | TQI[pi, d] = ExtQI[pi, e] }
}

-- L_pi(e) = { d | (d,e) in L_pi }
fun Lset[pi: Policy, e: ExternalRecord] : set Record {
  L[pi].e
}

-- Singleton_pi^Catt(d,e) iff L_pi(e) = {d}
pred Singleton[pi: Policy, d: Record, e: ExternalRecord] {
  Lset[pi, e] = d
}

-- private helper: exposed sensitive value. In this Small model, exact
-- disease release exposes the corresponding sensitive disease value;
-- category/suppressed disease release does not expose the exact value.
pred ExposesSensitive[pi: Policy, d: Record, s: SensitiveValue] {
  pi.diseaseLevel = DisExact
  s = sensOfDisease[d.disease]
}

-- Def.11 Privacy Property: holds iff WPriv is empty (defined below)
pred PrivacyPropertyHolds[pi: Policy] {
  no WPriv[pi]
}

-- Def.12 Utility Property: holds iff WUtil is empty (defined below)
pred UtilityPropertyHolds[pi: Policy] {
  no WUtil[pi]
}

-- ======================================================================
-- Part 6. Evidence / Witness Sets  (Def.13-14)
-- ======================================================================

-- Def.13 Privacy-Violating Witness
fun WPriv[pi: Policy] : Record -> ExternalRecord -> SensitiveValue {
  { d: Record, e: ExternalRecord, s: SensitiveValue |
      d->e in L[pi]
      and Singleton[pi, d, e]
      and s in d.(Catt.sensitiveOf)
      and ExposesSensitive[pi, d, s]
  }
}

-- Def.14 Utility-Violating Witness
fun WUtil[pi: Policy] : Record -> Record {
  ReqGQ.pairs & K[pi]
}

-- ======================================================================
-- Part 7. Verdicts / Joint Satisfiability  (Def.15-17)
-- Verdicts call Property predicates only (Rule V1).
-- ======================================================================

-- Def.15 Privacy Verdict
pred Safe[pi: Policy]   { PrivacyPropertyHolds[pi] }
pred Unsafe[pi: Policy] { not PrivacyPropertyHolds[pi] }

-- Def.16 Utility Verdict
pred Useful[pi: Policy]           { UtilityPropertyHolds[pi] }
pred UtilityViolating[pi: Policy] { not UtilityPropertyHolds[pi] }

-- Def.17 Joint Satisfiability
pred Accept[pi: Policy] { Safe[pi] and Useful[pi] }

-- ======================================================================
-- Part 8. Theoretical Sanity Checks (bounded evidence only, NOT theorem
-- proofs). Uncomment to re-run individually.
-- ======================================================================

check KernelInclusionSanity {
  all pa, pb: CandidatePolicies |
    preceqG[pa, pb] implies K[pa] in K[pb]
} for exactly 128 Record, exactly 60 Policy, exactly 1 ExternalRecord

check UtilityWitnessInclusionSanity {
  all pa, pb: CandidatePolicies |
    preceqG[pa, pb] implies WUtil[pa] in WUtil[pb]
} for exactly 128 Record, exactly 60 Policy, exactly 1 ExternalRecord

-- Privacy is intentionally not asserted as monotone.
run FindPrivacyNonMonotoneExample {
  some pa, pb: CandidatePolicies |
    preceqG[pa, pb]
    and some WPriv[pa]
    and no WPriv[pb]
} for exactly 128 Record, exactly 60 Policy, exactly 1 ExternalRecord

-- ======================================================================
-- Part 9. Example Runs for Table 1A/1B Diagnostics
-- ======================================================================

run FindAcceptablePolicy {
  some pi: CandidatePolicies | Accept[pi]
} for exactly 128 Record, exactly 60 Policy, exactly 1 ExternalRecord

run FindPrivacyReject {
  some pi: CandidatePolicies | Unsafe[pi]
} for exactly 128 Record, exactly 60 Policy, exactly 1 ExternalRecord

run FindUtilityReject {
  some pi: CandidatePolicies | UtilityViolating[pi]
} for exactly 128 Record, exactly 60 Policy, exactly 1 ExternalRecord

run FindBothReject {
  some pi: CandidatePolicies | Unsafe[pi] and UtilityViolating[pi]
} for exactly 128 Record, exactly 60 Policy, exactly 1 ExternalRecord

-- ======================================================================
-- Part 10. Batch Invocation Support (Table 3: Exhaustive vs. Pruning)
-- ----------------------------------------------------------------------
-- TargetPolicy is pinned to ONE of the existing 60 Policy atoms per
-- external invocation, via a generated fact identifying it by its
-- (ageLevel,regionLevel,diseaseLevel) coordinate. It is declared "in
-- Policy" (a subset/alias), NOT "extends Policy" -- extends would add a
-- 61st atom, which (combined with PolicyDistinctness) would make every
-- CheckTargetSafe/CheckTargetUseful run vacuously inconsistent, since no
-- 61st atom can share a coordinate with one of the 60 without violating
-- PolicyDistinctness. As a subset of the existing 60, TargetPolicy simply
-- designates which already-pinned atom is under test.
--
-- Because Record, ExternalRecord, Catt, and ReqGQ are already pinned by
-- the Small Configuration Instance facts above, Safe[TargetPolicy] and
-- Useful[TargetPolicy] become GROUND (variable-free) formulas once
-- TargetPolicy is pinned -- so the SAT/UNSAT verdict of each `run` below
-- IS the truth value of that formula, not an existential search.
--
-- Python generates one fact block (see python_evaluator_small.py) of
-- the form:
--   fact PinTargetPolicy {
--     TargetPolicy.ageLevel = <AgeLevelAtom>
--     TargetPolicy.regionLevel = <RegionLevelAtom>
--     TargetPolicy.diseaseLevel = <DiseaseLevelAtom>
--   }
-- and appends it (plus exactly one of the two `run` commands below) to a
-- copy of this file before invoking Alloy headlessly.
-- ======================================================================

one sig TargetPolicy in Policy {}

-- These two commands are only meaningful in a Python-generated COPY of
-- this file that also includes a PinTargetPolicy fact (see above).
-- Left commented out here so that running this canonical file top-to-
-- bottom does not silently execute an unpinned (existential) query.
--run CheckTargetSafe   { Safe[TargetPolicy]   } for exactly 128 Record, exactly 60 Policy, exactly 1 ExternalRecord
--run CheckTargetUseful { Useful[TargetPolicy] } for exactly 128 Record, exactly 60 Policy, exactly 1 ExternalRecord
