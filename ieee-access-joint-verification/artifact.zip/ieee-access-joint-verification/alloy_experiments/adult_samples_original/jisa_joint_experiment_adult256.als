module jisa_joint_experiment_v1

/*
======================================================================
JISA Executable Reference Semantics
----------------------------------------------------------------------
This Alloy model is the executable reference semantics corresponding
to Definitions 1-17 (Definition Blueprint v1.0). Its purpose is not
implementation convenience but faithful execution of the formal
definitions: Paper Definition N -> Alloy code -> Python reads output.
Python scripts consume the outputs of this model; they never redefine
its privacy/utility semantics (Executable Semantics Rule ES-1). The
generalization order over Pi (Def.4, preceqG below) is a closed
combinatorial structure independent of privacy/utility semantics and
MAY be replicated in Python for pruning control-flow; this is not a
semantics redefinition.

Governance context (G), threat specification (C_att), and task
specification (Req(G,Q)) are FIXED EXOGENOUS INPUTS. Only privacy and
utility are verified. There is no Governance verdict, no
Contract-Satisfying(pi) / Contract-Violating(pi) in this model
(deprecated for JISA; candidate owner: FM2027).

Naming: "jisa_joint_experiment_v1" is canonical and edited in place.
Do not create "_final", "_v2", etc. suffixes; archive superseded
snapshots under archive/ instead. This file is a distinct lineage from
"journal_joint_v3.als" (dissertation-track, governance-inclusive
model); do not treat it as a version successor of that file.

Validated locally (Alloy Analyzer, minisat(jni)) on 2026-07-03:
  FindAcceptablePolicy_Final, FindPrivacyReject_Final,
  FindUtilityReject_Final, FindBothReject_Final: all "Instance found".
  KernelInclusionSanity_Final, UtilityWitnessInclusionSanity_Final:
  "No counterexample found" (bounded evidence only, not a proof).
  FindPrivacyNonMonotoneExample_Final: "Instance found".
  Small instance: R3/R4 differ by REGION (not disease), so privacy
  rejection (disease-axis) and utility rejection (region-axis) can
  co-occur -- this is what makes FindBothReject_Final satisfiable.

----------------------------------------------------------------------
Def <-> Alloy correspondence table  (Executable Semantics Rule ES-2)
----------------------------------------------------------------------
 Def   | Alloy symbol                         | Public? | Depends on
-------|--------------------------------------|---------|-------------------
 Def.1 | sig Record                           | Yes     | -
 Def.2 | one sig G                            | Yes     | -
 Def.3 | one sig Q                            | Yes     | -
 Def.4 | sig Policy                           | Yes     | -
 Def.5 | sig GovAdmissible in Policy          | Yes     | Policy, G
 Def.6 | fun CandidatePolicies                | Yes     | GovAdmissible
 Def.7 | fun T                                | Yes     | Policy, Record
 Def.8 | fun DRel                             | Yes     | T
 Def.9 | one sig Catt                         | Yes     | -
 Def.10| one sig ReqGQ                        | Yes     | G, Q
 Def.11| pred PrivacyPropertyHolds            | Yes     | L (private), Catt
 Def.12| pred UtilityPropertyHolds            | Yes     | K (private), ReqGQ
 Def.13| fun WPriv                            | Yes     | L
 Def.14| fun WUtil                            | Yes     | K, ReqGQ
 Def.15| pred Safe / pred Unsafe              | Yes     | PrivacyPropertyHolds
 Def.16| pred Useful / pred UtilityViolating  | Yes     | UtilityPropertyHolds
 Def.17| pred Accept                          | Yes     | Safe, Useful
-------|--------------------------------------|---------|-------------------
 (private) fun K   -- released-tuple kernel, used inside Def.12
 (private) fun L   -- attacker link relation, used inside Def.11
 (private) fun TQI / ExtQI / TransformAge / TransformRegion /
           TransformDisease / ExposesSensitive
           -- helpers; not independent Definition objects.
 (batch)   one sig TargetPolicy in Policy {}
           -- pinned per Python-driven invocation; see Part 10.

Executable Semantics Rules (locked):
  ES-1  This model is the reference semantics; Python never redefines
        privacy/utility semantics (it may replicate the structural
        order preceqG for pruning control-flow only).
  ES-2  Public API = names in the table above only. Everything else is a
        private helper and MUST NOT be treated as a Definition.
  ES-3  Dependency direction mirrors the Blueprint's dependency graphs:
        Transformation -> Relation -> Property -> Evidence -> Verdict ->
        Joint Satisfiability. A lower layer never calls an upper layer.
  ES-4  Witness sets (WPriv, WUtil) are computed results of a Relation;
        Verdicts call the Property predicate, never the Witness or the
        Relation directly (Rule V1).
======================================================================
*/

-- ======================================================================
-- Part 1. Domain Vocabulary
-- Experimental domain values for the illustrative medical dataset.
-- These are NOT ontology objects defined in Blueprint Def.1-17; they
-- instantiate Record, Policy, and released-value vocabularies.
-- ======================================================================

abstract sig Age {}
one sig A25, A27, A30, A35, A40, A45, A50 extends Age {}

abstract sig Region {}
one sig Kanazawa, Komatsu, Toyama extends Region {}

abstract sig Disease {}
one sig Diabetes, Hypertension, Cancer extends Disease {}

abstract sig SensitiveValue {}
one sig SDiabetes, SHypertension, SCancer extends SensitiveValue {}

-- Ground-truth mapping from disease to sensitive value (domain fact,
-- not part of Catt). Used to ground Catt.sensitiveOf below, so that
-- Def.9's Sens_Catt(d) is not disconnected from the disease field.
fun sensOfDisease[d: Disease]: one SensitiveValue {
  d = Diabetes          => SDiabetes
  else d = Hypertension => SHypertension
  else                     SCancer
}

-- ======================================================================
-- Part 2. Structural Objects  (Def.1-6)
-- ======================================================================

-- Def.1 Original Dataset D
abstract sig Record {
  age       : one Age,
  region    : one Region,
  disease   : one Disease,
  sensitive : one SensitiveValue
}

-- Adult-256 applicability probe: 256 real UCI Adult records
-- (seed=42 sample, missing-value rows excluded), mapped onto the
-- SAME validated raw-value vocabulary as the Small configuration.
-- Age = nearest of {25,27,30,35,40,45,50} to real age.
-- Region slot = workclass group (Kanazawa=Private, Komatsu=Government,
-- Toyama=Self-employed). Disease slot = occupation group
-- (Diabetes=White-collar, Hypertension=Blue-collar, Cancer=Service).
-- See generate_adult_instance.py for the exact per-record mapping log.
one sig R1, R2, R3, R4, R5, R6, R7, R8, R9, R10, R11, R12, R13, R14, R15, R16, R17, R18, R19, R20, R21, R22, R23, R24, R25, R26, R27, R28, R29, R30, R31, R32, R33, R34, R35, R36, R37, R38, R39, R40, R41, R42, R43, R44, R45, R46, R47, R48, R49, R50, R51, R52, R53, R54, R55, R56, R57, R58, R59, R60, R61, R62, R63, R64, R65, R66, R67, R68, R69, R70, R71, R72, R73, R74, R75, R76, R77, R78, R79, R80, R81, R82, R83, R84, R85, R86, R87, R88, R89, R90, R91, R92, R93, R94, R95, R96, R97, R98, R99, R100, R101, R102, R103, R104, R105, R106, R107, R108, R109, R110, R111, R112, R113, R114, R115, R116, R117, R118, R119, R120, R121, R122, R123, R124, R125, R126, R127, R128, R129, R130, R131, R132, R133, R134, R135, R136, R137, R138, R139, R140, R141, R142, R143, R144, R145, R146, R147, R148, R149, R150, R151, R152, R153, R154, R155, R156, R157, R158, R159, R160, R161, R162, R163, R164, R165, R166, R167, R168, R169, R170, R171, R172, R173, R174, R175, R176, R177, R178, R179, R180, R181, R182, R183, R184, R185, R186, R187, R188, R189, R190, R191, R192, R193, R194, R195, R196, R197, R198, R199, R200, R201, R202, R203, R204, R205, R206, R207, R208, R209, R210, R211, R212, R213, R214, R215, R216, R217, R218, R219, R220, R221, R222, R223, R224, R225, R226, R227, R228, R229, R230, R231, R232, R233, R234, R235, R236, R237, R238, R239, R240, R241, R242, R243, R244, R245, R246, R247, R248, R249, R250, R251, R252, R253, R254, R255, R256 extends Record {}

fact Adult256RecordInstance {
  R1.age = A50 and R1.region = Komatsu and R1.disease = Diabetes
  R2.age = A30 and R2.region = Kanazawa and R2.disease = Diabetes
  R3.age = A40 and R3.region = Komatsu and R3.disease = Diabetes
  R4.age = A50 and R4.region = Komatsu and R4.disease = Diabetes
  R5.age = A50 and R5.region = Komatsu and R5.disease = Diabetes
  R6.age = A50 and R6.region = Toyama and R6.disease = Hypertension
  R7.age = A50 and R7.region = Komatsu and R7.disease = Diabetes
  R8.age = A45 and R8.region = Toyama and R8.disease = Diabetes
  R9.age = A40 and R9.region = Kanazawa and R9.disease = Cancer
  R10.age = A40 and R10.region = Kanazawa and R10.disease = Diabetes
  R11.age = A35 and R11.region = Kanazawa and R11.disease = Cancer
  R12.age = A50 and R12.region = Komatsu and R12.disease = Hypertension
  R13.age = A45 and R13.region = Toyama and R13.disease = Diabetes
  R14.age = A45 and R14.region = Kanazawa and R14.disease = Diabetes
  R15.age = A25 and R15.region = Kanazawa and R15.disease = Diabetes
  R16.age = A40 and R16.region = Kanazawa and R16.disease = Hypertension
  R17.age = A40 and R17.region = Kanazawa and R17.disease = Diabetes
  R18.age = A50 and R18.region = Komatsu and R18.disease = Hypertension
  R19.age = A25 and R19.region = Komatsu and R19.disease = Hypertension
  R20.age = A25 and R20.region = Kanazawa and R20.disease = Diabetes
  R21.age = A50 and R21.region = Kanazawa and R21.disease = Diabetes
  R22.age = A50 and R22.region = Komatsu and R22.disease = Diabetes
  R23.age = A35 and R23.region = Kanazawa and R23.disease = Diabetes
  R24.age = A50 and R24.region = Toyama and R24.disease = Hypertension
  R25.age = A50 and R25.region = Toyama and R25.disease = Hypertension
  R26.age = A35 and R26.region = Kanazawa and R26.disease = Hypertension
  R27.age = A50 and R27.region = Toyama and R27.disease = Diabetes
  R28.age = A35 and R28.region = Kanazawa and R28.disease = Hypertension
  R29.age = A45 and R29.region = Kanazawa and R29.disease = Hypertension
  R30.age = A25 and R30.region = Kanazawa and R30.disease = Hypertension
  R31.age = A45 and R31.region = Kanazawa and R31.disease = Hypertension
  R32.age = A25 and R32.region = Toyama and R32.disease = Diabetes
  R33.age = A25 and R33.region = Kanazawa and R33.disease = Hypertension
  R34.age = A50 and R34.region = Kanazawa and R34.disease = Cancer
  R35.age = A30 and R35.region = Kanazawa and R35.disease = Hypertension
  R36.age = A50 and R36.region = Kanazawa and R36.disease = Diabetes
  R37.age = A50 and R37.region = Kanazawa and R37.disease = Hypertension
  R38.age = A50 and R38.region = Toyama and R38.disease = Diabetes
  R39.age = A45 and R39.region = Kanazawa and R39.disease = Diabetes
  R40.age = A40 and R40.region = Kanazawa and R40.disease = Diabetes
  R41.age = A35 and R41.region = Toyama and R41.disease = Diabetes
  R42.age = A40 and R42.region = Komatsu and R42.disease = Diabetes
  R43.age = A25 and R43.region = Kanazawa and R43.disease = Hypertension
  R44.age = A50 and R44.region = Toyama and R44.disease = Diabetes
  R45.age = A50 and R45.region = Kanazawa and R45.disease = Diabetes
  R46.age = A27 and R46.region = Kanazawa and R46.disease = Diabetes
  R47.age = A40 and R47.region = Kanazawa and R47.disease = Hypertension
  R48.age = A35 and R48.region = Kanazawa and R48.disease = Hypertension
  R49.age = A25 and R49.region = Kanazawa and R49.disease = Cancer
  R50.age = A45 and R50.region = Kanazawa and R50.disease = Diabetes
  R51.age = A35 and R51.region = Kanazawa and R51.disease = Diabetes
  R52.age = A45 and R52.region = Kanazawa and R52.disease = Diabetes
  R53.age = A45 and R53.region = Komatsu and R53.disease = Diabetes
  R54.age = A35 and R54.region = Komatsu and R54.disease = Diabetes
  R55.age = A35 and R55.region = Komatsu and R55.disease = Diabetes
  R56.age = A25 and R56.region = Kanazawa and R56.disease = Diabetes
  R57.age = A45 and R57.region = Kanazawa and R57.disease = Hypertension
  R58.age = A27 and R58.region = Kanazawa and R58.disease = Hypertension
  R59.age = A25 and R59.region = Kanazawa and R59.disease = Diabetes
  R60.age = A45 and R60.region = Toyama and R60.disease = Hypertension
  R61.age = A50 and R61.region = Komatsu and R61.disease = Diabetes
  R62.age = A45 and R62.region = Kanazawa and R62.disease = Hypertension
  R63.age = A50 and R63.region = Kanazawa and R63.disease = Diabetes
  R64.age = A50 and R64.region = Toyama and R64.disease = Diabetes
  R65.age = A40 and R65.region = Kanazawa and R65.disease = Hypertension
  R66.age = A40 and R66.region = Kanazawa and R66.disease = Hypertension
  R67.age = A40 and R67.region = Komatsu and R67.disease = Diabetes
  R68.age = A25 and R68.region = Komatsu and R68.disease = Diabetes
  R69.age = A30 and R69.region = Kanazawa and R69.disease = Diabetes
  R70.age = A50 and R70.region = Komatsu and R70.disease = Diabetes
  R71.age = A40 and R71.region = Kanazawa and R71.disease = Diabetes
  R72.age = A45 and R72.region = Komatsu and R72.disease = Diabetes
  R73.age = A40 and R73.region = Toyama and R73.disease = Hypertension
  R74.age = A25 and R74.region = Kanazawa and R74.disease = Cancer
  R75.age = A50 and R75.region = Komatsu and R75.disease = Diabetes
  R76.age = A50 and R76.region = Kanazawa and R76.disease = Hypertension
  R77.age = A45 and R77.region = Komatsu and R77.disease = Diabetes
  R78.age = A30 and R78.region = Kanazawa and R78.disease = Diabetes
  R79.age = A25 and R79.region = Kanazawa and R79.disease = Diabetes
  R80.age = A50 and R80.region = Komatsu and R80.disease = Hypertension
  R81.age = A50 and R81.region = Kanazawa and R81.disease = Cancer
  R82.age = A40 and R82.region = Kanazawa and R82.disease = Diabetes
  R83.age = A35 and R83.region = Kanazawa and R83.disease = Diabetes
  R84.age = A45 and R84.region = Toyama and R84.disease = Hypertension
  R85.age = A50 and R85.region = Komatsu and R85.disease = Diabetes
  R86.age = A25 and R86.region = Kanazawa and R86.disease = Diabetes
  R87.age = A50 and R87.region = Kanazawa and R87.disease = Hypertension
  R88.age = A45 and R88.region = Toyama and R88.disease = Diabetes
  R89.age = A30 and R89.region = Kanazawa and R89.disease = Hypertension
  R90.age = A25 and R90.region = Kanazawa and R90.disease = Hypertension
  R91.age = A30 and R91.region = Kanazawa and R91.disease = Diabetes
  R92.age = A45 and R92.region = Kanazawa and R92.disease = Diabetes
  R93.age = A50 and R93.region = Toyama and R93.disease = Diabetes
  R94.age = A50 and R94.region = Kanazawa and R94.disease = Diabetes
  R95.age = A30 and R95.region = Kanazawa and R95.disease = Diabetes
  R96.age = A25 and R96.region = Kanazawa and R96.disease = Hypertension
  R97.age = A50 and R97.region = Komatsu and R97.disease = Cancer
  R98.age = A50 and R98.region = Kanazawa and R98.disease = Cancer
  R99.age = A30 and R99.region = Kanazawa and R99.disease = Diabetes
  R100.age = A40 and R100.region = Kanazawa and R100.disease = Diabetes
  R101.age = A40 and R101.region = Kanazawa and R101.disease = Diabetes
  R102.age = A35 and R102.region = Kanazawa and R102.disease = Cancer
  R103.age = A25 and R103.region = Kanazawa and R103.disease = Diabetes
  R104.age = A30 and R104.region = Kanazawa and R104.disease = Diabetes
  R105.age = A50 and R105.region = Kanazawa and R105.disease = Diabetes
  R106.age = A50 and R106.region = Kanazawa and R106.disease = Diabetes
  R107.age = A30 and R107.region = Kanazawa and R107.disease = Diabetes
  R108.age = A30 and R108.region = Kanazawa and R108.disease = Diabetes
  R109.age = A35 and R109.region = Kanazawa and R109.disease = Diabetes
  R110.age = A30 and R110.region = Kanazawa and R110.disease = Hypertension
  R111.age = A50 and R111.region = Toyama and R111.disease = Hypertension
  R112.age = A35 and R112.region = Kanazawa and R112.disease = Diabetes
  R113.age = A50 and R113.region = Kanazawa and R113.disease = Hypertension
  R114.age = A35 and R114.region = Kanazawa and R114.disease = Diabetes
  R115.age = A45 and R115.region = Kanazawa and R115.disease = Diabetes
  R116.age = A50 and R116.region = Kanazawa and R116.disease = Diabetes
  R117.age = A25 and R117.region = Kanazawa and R117.disease = Hypertension
  R118.age = A30 and R118.region = Toyama and R118.disease = Hypertension
  R119.age = A40 and R119.region = Kanazawa and R119.disease = Cancer
  R120.age = A25 and R120.region = Kanazawa and R120.disease = Cancer
  R121.age = A25 and R121.region = Kanazawa and R121.disease = Hypertension
  R122.age = A40 and R122.region = Kanazawa and R122.disease = Hypertension
  R123.age = A35 and R123.region = Komatsu and R123.disease = Diabetes
  R124.age = A27 and R124.region = Kanazawa and R124.disease = Cancer
  R125.age = A40 and R125.region = Komatsu and R125.disease = Hypertension
  R126.age = A25 and R126.region = Kanazawa and R126.disease = Cancer
  R127.age = A50 and R127.region = Komatsu and R127.disease = Diabetes
  R128.age = A25 and R128.region = Kanazawa and R128.disease = Hypertension
  R129.age = A25 and R129.region = Kanazawa and R129.disease = Diabetes
  R130.age = A35 and R130.region = Kanazawa and R130.disease = Diabetes
  R131.age = A40 and R131.region = Kanazawa and R131.disease = Hypertension
  R132.age = A25 and R132.region = Kanazawa and R132.disease = Diabetes
  R133.age = A30 and R133.region = Kanazawa and R133.disease = Diabetes
  R134.age = A25 and R134.region = Kanazawa and R134.disease = Diabetes
  R135.age = A27 and R135.region = Kanazawa and R135.disease = Diabetes
  R136.age = A50 and R136.region = Kanazawa and R136.disease = Cancer
  R137.age = A27 and R137.region = Kanazawa and R137.disease = Diabetes
  R138.age = A35 and R138.region = Kanazawa and R138.disease = Hypertension
  R139.age = A35 and R139.region = Kanazawa and R139.disease = Diabetes
  R140.age = A35 and R140.region = Toyama and R140.disease = Diabetes
  R141.age = A30 and R141.region = Toyama and R141.disease = Hypertension
  R142.age = A30 and R142.region = Komatsu and R142.disease = Hypertension
  R143.age = A27 and R143.region = Kanazawa and R143.disease = Diabetes
  R144.age = A25 and R144.region = Kanazawa and R144.disease = Hypertension
  R145.age = A25 and R145.region = Kanazawa and R145.disease = Diabetes
  R146.age = A45 and R146.region = Kanazawa and R146.disease = Hypertension
  R147.age = A50 and R147.region = Kanazawa and R147.disease = Cancer
  R148.age = A25 and R148.region = Kanazawa and R148.disease = Diabetes
  R149.age = A40 and R149.region = Kanazawa and R149.disease = Diabetes
  R150.age = A50 and R150.region = Kanazawa and R150.disease = Hypertension
  R151.age = A35 and R151.region = Toyama and R151.disease = Hypertension
  R152.age = A30 and R152.region = Kanazawa and R152.disease = Cancer
  R153.age = A27 and R153.region = Kanazawa and R153.disease = Diabetes
  R154.age = A35 and R154.region = Komatsu and R154.disease = Diabetes
  R155.age = A40 and R155.region = Kanazawa and R155.disease = Diabetes
  R156.age = A40 and R156.region = Toyama and R156.disease = Hypertension
  R157.age = A35 and R157.region = Kanazawa and R157.disease = Hypertension
  R158.age = A50 and R158.region = Komatsu and R158.disease = Diabetes
  R159.age = A50 and R159.region = Kanazawa and R159.disease = Diabetes
  R160.age = A50 and R160.region = Kanazawa and R160.disease = Diabetes
  R161.age = A45 and R161.region = Kanazawa and R161.disease = Hypertension
  R162.age = A50 and R162.region = Toyama and R162.disease = Diabetes
  R163.age = A25 and R163.region = Kanazawa and R163.disease = Diabetes
  R164.age = A27 and R164.region = Toyama and R164.disease = Diabetes
  R165.age = A50 and R165.region = Kanazawa and R165.disease = Diabetes
  R166.age = A50 and R166.region = Komatsu and R166.disease = Diabetes
  R167.age = A50 and R167.region = Komatsu and R167.disease = Diabetes
  R168.age = A30 and R168.region = Kanazawa and R168.disease = Diabetes
  R169.age = A45 and R169.region = Kanazawa and R169.disease = Diabetes
  R170.age = A25 and R170.region = Kanazawa and R170.disease = Cancer
  R171.age = A27 and R171.region = Kanazawa and R171.disease = Hypertension
  R172.age = A25 and R172.region = Kanazawa and R172.disease = Diabetes
  R173.age = A25 and R173.region = Komatsu and R173.disease = Diabetes
  R174.age = A50 and R174.region = Kanazawa and R174.disease = Cancer
  R175.age = A30 and R175.region = Kanazawa and R175.disease = Hypertension
  R176.age = A25 and R176.region = Kanazawa and R176.disease = Cancer
  R177.age = A40 and R177.region = Toyama and R177.disease = Diabetes
  R178.age = A50 and R178.region = Komatsu and R178.disease = Diabetes
  R179.age = A27 and R179.region = Kanazawa and R179.disease = Diabetes
  R180.age = A30 and R180.region = Kanazawa and R180.disease = Hypertension
  R181.age = A40 and R181.region = Kanazawa and R181.disease = Hypertension
  R182.age = A50 and R182.region = Toyama and R182.disease = Diabetes
  R183.age = A25 and R183.region = Kanazawa and R183.disease = Diabetes
  R184.age = A45 and R184.region = Kanazawa and R184.disease = Hypertension
  R185.age = A50 and R185.region = Komatsu and R185.disease = Diabetes
  R186.age = A50 and R186.region = Komatsu and R186.disease = Cancer
  R187.age = A35 and R187.region = Komatsu and R187.disease = Diabetes
  R188.age = A40 and R188.region = Kanazawa and R188.disease = Hypertension
  R189.age = A25 and R189.region = Kanazawa and R189.disease = Diabetes
  R190.age = A40 and R190.region = Kanazawa and R190.disease = Diabetes
  R191.age = A45 and R191.region = Kanazawa and R191.disease = Diabetes
  R192.age = A25 and R192.region = Kanazawa and R192.disease = Diabetes
  R193.age = A50 and R193.region = Toyama and R193.disease = Diabetes
  R194.age = A50 and R194.region = Komatsu and R194.disease = Diabetes
  R195.age = A50 and R195.region = Kanazawa and R195.disease = Diabetes
  R196.age = A35 and R196.region = Komatsu and R196.disease = Diabetes
  R197.age = A50 and R197.region = Kanazawa and R197.disease = Diabetes
  R198.age = A30 and R198.region = Kanazawa and R198.disease = Cancer
  R199.age = A35 and R199.region = Kanazawa and R199.disease = Diabetes
  R200.age = A50 and R200.region = Kanazawa and R200.disease = Hypertension
  R201.age = A50 and R201.region = Komatsu and R201.disease = Diabetes
  R202.age = A40 and R202.region = Toyama and R202.disease = Hypertension
  R203.age = A35 and R203.region = Kanazawa and R203.disease = Hypertension
  R204.age = A30 and R204.region = Kanazawa and R204.disease = Hypertension
  R205.age = A40 and R205.region = Kanazawa and R205.disease = Diabetes
  R206.age = A45 and R206.region = Kanazawa and R206.disease = Hypertension
  R207.age = A35 and R207.region = Toyama and R207.disease = Diabetes
  R208.age = A30 and R208.region = Kanazawa and R208.disease = Hypertension
  R209.age = A50 and R209.region = Kanazawa and R209.disease = Diabetes
  R210.age = A30 and R210.region = Kanazawa and R210.disease = Hypertension
  R211.age = A25 and R211.region = Kanazawa and R211.disease = Diabetes
  R212.age = A50 and R212.region = Toyama and R212.disease = Hypertension
  R213.age = A27 and R213.region = Kanazawa and R213.disease = Diabetes
  R214.age = A45 and R214.region = Kanazawa and R214.disease = Hypertension
  R215.age = A25 and R215.region = Kanazawa and R215.disease = Diabetes
  R216.age = A45 and R216.region = Kanazawa and R216.disease = Diabetes
  R217.age = A25 and R217.region = Kanazawa and R217.disease = Cancer
  R218.age = A25 and R218.region = Kanazawa and R218.disease = Diabetes
  R219.age = A25 and R219.region = Kanazawa and R219.disease = Diabetes
  R220.age = A30 and R220.region = Komatsu and R220.disease = Diabetes
  R221.age = A50 and R221.region = Kanazawa and R221.disease = Diabetes
  R222.age = A25 and R222.region = Kanazawa and R222.disease = Cancer
  R223.age = A40 and R223.region = Komatsu and R223.disease = Diabetes
  R224.age = A50 and R224.region = Kanazawa and R224.disease = Hypertension
  R225.age = A45 and R225.region = Kanazawa and R225.disease = Diabetes
  R226.age = A50 and R226.region = Kanazawa and R226.disease = Diabetes
  R227.age = A45 and R227.region = Komatsu and R227.disease = Diabetes
  R228.age = A45 and R228.region = Kanazawa and R228.disease = Hypertension
  R229.age = A30 and R229.region = Kanazawa and R229.disease = Cancer
  R230.age = A35 and R230.region = Kanazawa and R230.disease = Diabetes
  R231.age = A50 and R231.region = Komatsu and R231.disease = Diabetes
  R232.age = A35 and R232.region = Toyama and R232.disease = Hypertension
  R233.age = A25 and R233.region = Kanazawa and R233.disease = Hypertension
  R234.age = A30 and R234.region = Kanazawa and R234.disease = Hypertension
  R235.age = A50 and R235.region = Toyama and R235.disease = Hypertension
  R236.age = A25 and R236.region = Kanazawa and R236.disease = Diabetes
  R237.age = A25 and R237.region = Kanazawa and R237.disease = Hypertension
  R238.age = A40 and R238.region = Kanazawa and R238.disease = Diabetes
  R239.age = A25 and R239.region = Komatsu and R239.disease = Diabetes
  R240.age = A30 and R240.region = Kanazawa and R240.disease = Hypertension
  R241.age = A50 and R241.region = Kanazawa and R241.disease = Diabetes
  R242.age = A50 and R242.region = Toyama and R242.disease = Hypertension
  R243.age = A30 and R243.region = Kanazawa and R243.disease = Diabetes
  R244.age = A30 and R244.region = Kanazawa and R244.disease = Cancer
  R245.age = A35 and R245.region = Kanazawa and R245.disease = Hypertension
  R246.age = A50 and R246.region = Toyama and R246.disease = Hypertension
  R247.age = A30 and R247.region = Kanazawa and R247.disease = Diabetes
  R248.age = A25 and R248.region = Kanazawa and R248.disease = Hypertension
  R249.age = A25 and R249.region = Kanazawa and R249.disease = Cancer
  R250.age = A50 and R250.region = Toyama and R250.disease = Diabetes
  R251.age = A35 and R251.region = Komatsu and R251.disease = Diabetes
  R252.age = A35 and R252.region = Kanazawa and R252.disease = Diabetes
  R253.age = A50 and R253.region = Kanazawa and R253.disease = Diabetes
  R254.age = A50 and R254.region = Toyama and R254.disease = Diabetes
  R255.age = A50 and R255.region = Kanazawa and R255.disease = Diabetes
  R256.age = A50 and R256.region = Kanazawa and R256.disease = Hypertension
}
fact Adult256SensitiveFromIncome {
  R1.sensitive = SDiabetes
  R2.sensitive = SHypertension
  R3.sensitive = SDiabetes
  R4.sensitive = SHypertension
  R5.sensitive = SHypertension
  R6.sensitive = SHypertension
  R7.sensitive = SDiabetes
  R8.sensitive = SDiabetes
  R9.sensitive = SHypertension
  R10.sensitive = SDiabetes
  R11.sensitive = SHypertension
  R12.sensitive = SHypertension
  R13.sensitive = SDiabetes
  R14.sensitive = SHypertension
  R15.sensitive = SHypertension
  R16.sensitive = SHypertension
  R17.sensitive = SDiabetes
  R18.sensitive = SHypertension
  R19.sensitive = SHypertension
  R20.sensitive = SHypertension
  R21.sensitive = SHypertension
  R22.sensitive = SHypertension
  R23.sensitive = SHypertension
  R24.sensitive = SHypertension
  R25.sensitive = SHypertension
  R26.sensitive = SHypertension
  R27.sensitive = SDiabetes
  R28.sensitive = SHypertension
  R29.sensitive = SHypertension
  R30.sensitive = SHypertension
  R31.sensitive = SHypertension
  R32.sensitive = SHypertension
  R33.sensitive = SHypertension
  R34.sensitive = SHypertension
  R35.sensitive = SHypertension
  R36.sensitive = SDiabetes
  R37.sensitive = SDiabetes
  R38.sensitive = SHypertension
  R39.sensitive = SDiabetes
  R40.sensitive = SDiabetes
  R41.sensitive = SHypertension
  R42.sensitive = SDiabetes
  R43.sensitive = SHypertension
  R44.sensitive = SDiabetes
  R45.sensitive = SDiabetes
  R46.sensitive = SHypertension
  R47.sensitive = SHypertension
  R48.sensitive = SHypertension
  R49.sensitive = SHypertension
  R50.sensitive = SDiabetes
  R51.sensitive = SHypertension
  R52.sensitive = SHypertension
  R53.sensitive = SDiabetes
  R54.sensitive = SDiabetes
  R55.sensitive = SDiabetes
  R56.sensitive = SHypertension
  R57.sensitive = SDiabetes
  R58.sensitive = SHypertension
  R59.sensitive = SHypertension
  R60.sensitive = SDiabetes
  R61.sensitive = SDiabetes
  R62.sensitive = SHypertension
  R63.sensitive = SHypertension
  R64.sensitive = SHypertension
  R65.sensitive = SDiabetes
  R66.sensitive = SHypertension
  R67.sensitive = SHypertension
  R68.sensitive = SHypertension
  R69.sensitive = SHypertension
  R70.sensitive = SDiabetes
  R71.sensitive = SHypertension
  R72.sensitive = SDiabetes
  R73.sensitive = SHypertension
  R74.sensitive = SHypertension
  R75.sensitive = SHypertension
  R76.sensitive = SHypertension
  R77.sensitive = SDiabetes
  R78.sensitive = SHypertension
  R79.sensitive = SHypertension
  R80.sensitive = SHypertension
  R81.sensitive = SHypertension
  R82.sensitive = SDiabetes
  R83.sensitive = SHypertension
  R84.sensitive = SHypertension
  R85.sensitive = SDiabetes
  R86.sensitive = SHypertension
  R87.sensitive = SHypertension
  R88.sensitive = SHypertension
  R89.sensitive = SHypertension
  R90.sensitive = SHypertension
  R91.sensitive = SHypertension
  R92.sensitive = SDiabetes
  R93.sensitive = SDiabetes
  R94.sensitive = SHypertension
  R95.sensitive = SHypertension
  R96.sensitive = SHypertension
  R97.sensitive = SHypertension
  R98.sensitive = SHypertension
  R99.sensitive = SHypertension
  R100.sensitive = SHypertension
  R101.sensitive = SHypertension
  R102.sensitive = SDiabetes
  R103.sensitive = SDiabetes
  R104.sensitive = SHypertension
  R105.sensitive = SHypertension
  R106.sensitive = SDiabetes
  R107.sensitive = SHypertension
  R108.sensitive = SHypertension
  R109.sensitive = SHypertension
  R110.sensitive = SDiabetes
  R111.sensitive = SHypertension
  R112.sensitive = SDiabetes
  R113.sensitive = SHypertension
  R114.sensitive = SDiabetes
  R115.sensitive = SDiabetes
  R116.sensitive = SHypertension
  R117.sensitive = SHypertension
  R118.sensitive = SHypertension
  R119.sensitive = SHypertension
  R120.sensitive = SHypertension
  R121.sensitive = SHypertension
  R122.sensitive = SHypertension
  R123.sensitive = SDiabetes
  R124.sensitive = SHypertension
  R125.sensitive = SDiabetes
  R126.sensitive = SHypertension
  R127.sensitive = SDiabetes
  R128.sensitive = SHypertension
  R129.sensitive = SHypertension
  R130.sensitive = SHypertension
  R131.sensitive = SHypertension
  R132.sensitive = SHypertension
  R133.sensitive = SHypertension
  R134.sensitive = SHypertension
  R135.sensitive = SDiabetes
  R136.sensitive = SHypertension
  R137.sensitive = SHypertension
  R138.sensitive = SDiabetes
  R139.sensitive = SDiabetes
  R140.sensitive = SDiabetes
  R141.sensitive = SHypertension
  R142.sensitive = SDiabetes
  R143.sensitive = SHypertension
  R144.sensitive = SHypertension
  R145.sensitive = SHypertension
  R146.sensitive = SDiabetes
  R147.sensitive = SHypertension
  R148.sensitive = SHypertension
  R149.sensitive = SDiabetes
  R150.sensitive = SHypertension
  R151.sensitive = SHypertension
  R152.sensitive = SHypertension
  R153.sensitive = SHypertension
  R154.sensitive = SHypertension
  R155.sensitive = SHypertension
  R156.sensitive = SDiabetes
  R157.sensitive = SHypertension
  R158.sensitive = SDiabetes
  R159.sensitive = SHypertension
  R160.sensitive = SHypertension
  R161.sensitive = SHypertension
  R162.sensitive = SDiabetes
  R163.sensitive = SHypertension
  R164.sensitive = SDiabetes
  R165.sensitive = SHypertension
  R166.sensitive = SDiabetes
  R167.sensitive = SHypertension
  R168.sensitive = SHypertension
  R169.sensitive = SHypertension
  R170.sensitive = SHypertension
  R171.sensitive = SHypertension
  R172.sensitive = SHypertension
  R173.sensitive = SHypertension
  R174.sensitive = SHypertension
  R175.sensitive = SHypertension
  R176.sensitive = SHypertension
  R177.sensitive = SDiabetes
  R178.sensitive = SDiabetes
  R179.sensitive = SHypertension
  R180.sensitive = SHypertension
  R181.sensitive = SHypertension
  R182.sensitive = SDiabetes
  R183.sensitive = SDiabetes
  R184.sensitive = SDiabetes
  R185.sensitive = SHypertension
  R186.sensitive = SHypertension
  R187.sensitive = SHypertension
  R188.sensitive = SHypertension
  R189.sensitive = SHypertension
  R190.sensitive = SDiabetes
  R191.sensitive = SDiabetes
  R192.sensitive = SHypertension
  R193.sensitive = SDiabetes
  R194.sensitive = SHypertension
  R195.sensitive = SHypertension
  R196.sensitive = SHypertension
  R197.sensitive = SHypertension
  R198.sensitive = SHypertension
  R199.sensitive = SHypertension
  R200.sensitive = SHypertension
  R201.sensitive = SHypertension
  R202.sensitive = SHypertension
  R203.sensitive = SHypertension
  R204.sensitive = SHypertension
  R205.sensitive = SHypertension
  R206.sensitive = SDiabetes
  R207.sensitive = SDiabetes
  R208.sensitive = SDiabetes
  R209.sensitive = SHypertension
  R210.sensitive = SHypertension
  R211.sensitive = SHypertension
  R212.sensitive = SHypertension
  R213.sensitive = SHypertension
  R214.sensitive = SHypertension
  R215.sensitive = SHypertension
  R216.sensitive = SHypertension
  R217.sensitive = SHypertension
  R218.sensitive = SHypertension
  R219.sensitive = SHypertension
  R220.sensitive = SHypertension
  R221.sensitive = SDiabetes
  R222.sensitive = SHypertension
  R223.sensitive = SDiabetes
  R224.sensitive = SHypertension
  R225.sensitive = SHypertension
  R226.sensitive = SHypertension
  R227.sensitive = SDiabetes
  R228.sensitive = SHypertension
  R229.sensitive = SHypertension
  R230.sensitive = SHypertension
  R231.sensitive = SDiabetes
  R232.sensitive = SHypertension
  R233.sensitive = SHypertension
  R234.sensitive = SDiabetes
  R235.sensitive = SHypertension
  R236.sensitive = SHypertension
  R237.sensitive = SHypertension
  R238.sensitive = SHypertension
  R239.sensitive = SHypertension
  R240.sensitive = SHypertension
  R241.sensitive = SDiabetes
  R242.sensitive = SHypertension
  R243.sensitive = SHypertension
  R244.sensitive = SHypertension
  R245.sensitive = SDiabetes
  R246.sensitive = SDiabetes
  R247.sensitive = SDiabetes
  R248.sensitive = SHypertension
  R249.sensitive = SHypertension
  R250.sensitive = SDiabetes
  R251.sensitive = SHypertension
  R252.sensitive = SHypertension
  R253.sensitive = SHypertension
  R254.sensitive = SHypertension
  R255.sensitive = SHypertension
  R256.sensitive = SDiabetes
}

-- Def.2 Governance Context G (fixed, exogenous; never verified here)
one sig G {}

-- Def.3 Task Context Q (fixed)
one sig Q {}

-- Released vocabulary: the codomain components of T_pi.
abstract sig ReleasedAge {}
one sig RAge25, RAge27, RAge30, RAge35, RAge40, RAge45, RAge50,
        RAge25to29, RAge30to34, RAge35to39, RAge40to44,
        RAge45to49, RAge50to54,
        RAge20s, RAge30s, RAge40s, RAge50s,
        RAdult, RAgeSuppressed extends ReleasedAge {}

abstract sig ReleasedRegion {}
one sig RKanazawa, RKomatsu, RToyama,
        RPrefecture, RCountry, RRegionSuppressed extends ReleasedRegion {}

abstract sig ReleasedDisease {}
one sig RDiabetes, RHypertension, RCancer,
        RChronic, RDiseaseSuppressed extends ReleasedDisease {}

-- Policy generalization axes (each a total order; see facts below)
abstract sig AgeLevel     { agePreceq: set AgeLevel }
abstract sig RegionLevel  { regPreceq: set RegionLevel }
abstract sig DiseaseLevel { disPreceq: set DiseaseLevel }

one sig AgeExact, Age5yr, Age10yr, AgeAdult, AgeSuppressed extends AgeLevel {}
one sig RegExact, RegPrefectureLvl, RegCountryLvl, RegSuppressedLvl extends RegionLevel {}
one sig DisExact, DisCategory, DisSuppressed extends DiseaseLevel {}

fact AgeOrder {
  agePreceq =
    AgeExact -> Age5yr +
    Age5yr   -> Age10yr +
    Age10yr  -> AgeAdult +
    AgeAdult -> AgeSuppressed
}

fact RegionOrder {
  regPreceq =
    RegExact          -> RegPrefectureLvl +
    RegPrefectureLvl  -> RegCountryLvl +
    RegCountryLvl     -> RegSuppressedLvl
}

fact DiseaseOrder {
  disPreceq =
    DisExact    -> DisCategory +
    DisCategory -> DisSuppressed
}

-- Def.4 Policy Space Pi (product lattice over generalization axes)
sig Policy {
  ageLevel     : one AgeLevel,
  regionLevel  : one RegionLevel,
  diseaseLevel : one DiseaseLevel
}

-- Ensure exactly one policy per product-lattice coordinate when the
-- command scope uses exactly 60 Policy.
fact PolicyDistinctness {
  all disj p1, p2: Policy |
    p1.ageLevel != p2.ageLevel or
    p1.regionLevel != p2.regionLevel or
    p1.diseaseLevel != p2.diseaseLevel
}

-- Generalization order over Pi: pi_a preceq_G pi_b iff pi_b is at least
-- as coarse as pi_a on every axis. (Structural; see header note on
-- Python replication for pruning control-flow.)
pred preceqG[pa, pb: Policy] {
  pa.ageLevel     in pb.ageLevel.*(~agePreceq)
  pa.regionLevel  in pb.regionLevel.*(~regPreceq)
  pa.diseaseLevel in pb.diseaseLevel.*(~disPreceq)
}

-- Def.5 Governance-Restricted Policy Space Pi_gov(G) subseteq Pi
-- In the Small configuration, governance admits all product policies.
-- Later registry experiments may replace this fact with a strict subset.
sig GovAdmissible in Policy {}
fact SmallGovernanceAllPoliciesAdmissible {
  GovAdmissible = Policy
}

-- Def.6 Candidate Policy: pi in Pi_gov(G)
fun CandidatePolicies : set Policy { GovAdmissible }

-- ======================================================================
-- Part 3. Transformation  (Def.7-8)
-- Public API: fun T and fun DRel. Other functions in this part are
-- private helpers and do not correspond to independent Definitions.
-- ======================================================================

-- private helper
fun TransformAge[a: Age, l: AgeLevel]: one ReleasedAge {
  l = AgeExact => (
    a = A25 => RAge25
    else a = A27 => RAge27
    else a = A30 => RAge30
    else a = A35 => RAge35
    else a = A40 => RAge40
    else a = A45 => RAge45
    else RAge50
  )
  else l = Age5yr => (
    a in A25 + A27 => RAge25to29
    else a = A30 => RAge30to34
    else a = A35 => RAge35to39
    else a = A40 => RAge40to44
    else a = A45 => RAge45to49
    else RAge50to54
  )
  else l = Age10yr => (
    a in A25 + A27 => RAge20s
    else a in A30 + A35 => RAge30s
    else a in A40 + A45 => RAge40s
    else RAge50s
  )
  else l = AgeAdult => RAdult
  else RAgeSuppressed
}

-- private helper
fun TransformRegion[r: Region, l: RegionLevel]: one ReleasedRegion {
  l = RegExact => (
    r = Kanazawa => RKanazawa
    else r = Komatsu => RKomatsu
    else RToyama
  )
  -- All sample cities collapse to a single prefecture-level bucket in
  -- this illustrative 3-city domain.
  else l = RegPrefectureLvl => RPrefecture
  else l = RegCountryLvl    => RCountry
  else RRegionSuppressed
}

-- private helper
fun TransformDisease[d: Disease, l: DiseaseLevel]: one ReleasedDisease {
  l = DisExact => (
    d = Diabetes => RDiabetes
    else d = Hypertension => RHypertension
    else RCancer
  )
  else l = DisCategory => RChronic
  else RDiseaseSuppressed
}

-- Def.7 Transformation T_pi : D -> D_rel  (PUBLIC)
-- Implemented directly as a released tuple relation. No ReleasedTuple atom
-- is used, avoiding a separate existence/uniqueness obligation.
fun T[pi: Policy, r: Record] : ReleasedAge -> ReleasedRegion -> ReleasedDisease {
  TransformAge[r.age, pi.ageLevel]
  -> TransformRegion[r.region, pi.regionLevel]
  -> TransformDisease[r.disease, pi.diseaseLevel]
}

-- Def.8 Released Dataset D_rel = T_pi(D)  (PUBLIC)
fun DRel[pi: Policy] : ReleasedAge -> ReleasedRegion -> ReleasedDisease {
  { a: ReleasedAge, rg: ReleasedRegion, dis: ReleasedDisease |
      some r: Record | a->rg->dis = T[pi, r]
  }
}

-- ======================================================================
-- Part 4. Specifications  (Def.9-10)
-- ======================================================================

-- ExternalRecord implements D_ext(Catt): the external-information
-- component encoded inside the fixed threat specification Catt. It is
-- not an additional Structural Object in the JISA ontology.
abstract sig ExternalRecord {
  extAge    : one Age,
  extRegion : one Region,
  linkedTo  : one Record       -- ground truth for diagnostics; not used by L
}
one sig E1 extends ExternalRecord {}

fact Adult256ExternalInstance {
  E1.extAge = A50
  E1.extRegion = Komatsu
  E1.linkedTo = R4
}

-- Def.9 Threat Specification C_att
one sig Catt {
  sensitiveOf : Record -> SensitiveValue
}

fact CattSensitivityGroundedInDisease {
  Catt.sensitiveOf = { r: Record, s: SensitiveValue |
    s = sensOfDisease[r.disease]
  }
}

-- Def.10 Task Specification Req(G,Q) subseteq D x D
one sig ReqGQ {
  pairs: Record -> Record
}

-- The Adult-256 task requires this real-data-derived pair to
-- remain distinguishable (same age/occupation group, different
-- workclass group -- a region-slot-driven collapse, analogous to
-- Small's R3/R4 pair).
fact Adult256TaskRequirement {
  ReqGQ.pairs = R3->R10 + R10->R3
}

-- ======================================================================
-- Part 5. Properties / Relation Layer  (Def.11-12)
-- ======================================================================

-- private helper: released quasi-identifier of a record under policy pi
-- Privacy linkage uses only age and region as QI. Disease is sensitive
-- and is intentionally NOT part of the matching key.
fun TQI[pi: Policy, r: Record] : ReleasedAge -> ReleasedRegion {
  TransformAge[r.age, pi.ageLevel]
  -> TransformRegion[r.region, pi.regionLevel]
}

-- private helper: external quasi-identifier abstracted at the same policy level
fun ExtQI[pi: Policy, e: ExternalRecord] : ReleasedAge -> ReleasedRegion {
  TransformAge[e.extAge, pi.ageLevel]
  -> TransformRegion[e.extRegion, pi.regionLevel]
}

-- private notation inside Def.12: released-tuple kernel K_pi
fun K[pi: Policy] : Record -> Record {
  { d1, d2: Record | T[pi, d1] = T[pi, d2] }
}

-- private notation inside Def.11: link relation L_pi^Catt
fun L[pi: Policy] : Record -> ExternalRecord {
  { d: Record, e: ExternalRecord | TQI[pi, d] = ExtQI[pi, e] }
}

-- L_pi(e) = { d | (d,e) in L_pi }
fun Lset[pi: Policy, e: ExternalRecord] : set Record {
  L[pi].e
}

-- Singleton_pi^Catt(d,e) iff L_pi(e) = {d}
pred Singleton[pi: Policy, d: Record, e: ExternalRecord] {
  Lset[pi, e] = d
}

-- private helper: exposed sensitive value. In this Small model, exact
-- disease release exposes the corresponding sensitive disease value;
-- category/suppressed disease release does not expose the exact value.
pred ExposesSensitive[pi: Policy, d: Record, s: SensitiveValue] {
  pi.diseaseLevel = DisExact
  s = sensOfDisease[d.disease]
}

-- Def.11 Privacy Property: holds iff WPriv is empty (defined below)
pred PrivacyPropertyHolds[pi: Policy] {
  no WPriv[pi]
}

-- Def.12 Utility Property: holds iff WUtil is empty (defined below)
pred UtilityPropertyHolds[pi: Policy] {
  no WUtil[pi]
}

-- ======================================================================
-- Part 6. Evidence / Witness Sets  (Def.13-14)
-- ======================================================================

-- Def.13 Privacy-Violating Witness
fun WPriv[pi: Policy] : Record -> ExternalRecord -> SensitiveValue {
  { d: Record, e: ExternalRecord, s: SensitiveValue |
      d->e in L[pi]
      and Singleton[pi, d, e]
      and s in d.(Catt.sensitiveOf)
      and ExposesSensitive[pi, d, s]
  }
}

-- Def.14 Utility-Violating Witness
fun WUtil[pi: Policy] : Record -> Record {
  ReqGQ.pairs & K[pi]
}

-- ======================================================================
-- Part 7. Verdicts / Joint Satisfiability  (Def.15-17)
-- Verdicts call Property predicates only (Rule V1).
-- ======================================================================

-- Def.15 Privacy Verdict
pred Safe[pi: Policy]   { PrivacyPropertyHolds[pi] }
pred Unsafe[pi: Policy] { not PrivacyPropertyHolds[pi] }

-- Def.16 Utility Verdict
pred Useful[pi: Policy]           { UtilityPropertyHolds[pi] }
pred UtilityViolating[pi: Policy] { not UtilityPropertyHolds[pi] }

-- Def.17 Joint Satisfiability
pred Accept[pi: Policy] { Safe[pi] and Useful[pi] }

-- ======================================================================
-- Part 8. Theoretical Sanity Checks (bounded evidence only, NOT theorem
-- proofs). Uncomment to re-run individually.
-- ======================================================================

check KernelInclusionSanity {
  all pa, pb: CandidatePolicies |
    preceqG[pa, pb] implies K[pa] in K[pb]
} for exactly 256 Record, exactly 60 Policy, exactly 1 ExternalRecord

check UtilityWitnessInclusionSanity {
  all pa, pb: CandidatePolicies |
    preceqG[pa, pb] implies WUtil[pa] in WUtil[pb]
} for exactly 256 Record, exactly 60 Policy, exactly 1 ExternalRecord

-- Privacy is intentionally not asserted as monotone.
run FindPrivacyNonMonotoneExample {
  some pa, pb: CandidatePolicies |
    preceqG[pa, pb]
    and some WPriv[pa]
    and no WPriv[pb]
} for exactly 256 Record, exactly 60 Policy, exactly 1 ExternalRecord

-- ======================================================================
-- Part 9. Example Runs for Table 1A/1B Diagnostics
-- ======================================================================

run FindAcceptablePolicy {
  some pi: CandidatePolicies | Accept[pi]
} for exactly 256 Record, exactly 60 Policy, exactly 1 ExternalRecord

run FindPrivacyReject {
  some pi: CandidatePolicies | Unsafe[pi]
} for exactly 256 Record, exactly 60 Policy, exactly 1 ExternalRecord

run FindUtilityReject {
  some pi: CandidatePolicies | UtilityViolating[pi]
} for exactly 256 Record, exactly 60 Policy, exactly 1 ExternalRecord

run FindBothReject {
  some pi: CandidatePolicies | Unsafe[pi] and UtilityViolating[pi]
} for exactly 256 Record, exactly 60 Policy, exactly 1 ExternalRecord

-- ======================================================================
-- Part 10. Batch Invocation Support (Table 3: Exhaustive vs. Pruning)
-- ----------------------------------------------------------------------
-- TargetPolicy is pinned to ONE of the existing 60 Policy atoms per
-- external invocation, via a generated fact identifying it by its
-- (ageLevel,regionLevel,diseaseLevel) coordinate. It is declared "in
-- Policy" (a subset/alias), NOT "extends Policy" -- extends would add a
-- 61st atom, which (combined with PolicyDistinctness) would make every
-- CheckTargetSafe/CheckTargetUseful run vacuously inconsistent, since no
-- 61st atom can share a coordinate with one of the 60 without violating
-- PolicyDistinctness. As a subset of the existing 60, TargetPolicy simply
-- designates which already-pinned atom is under test.
--
-- Because Record, ExternalRecord, Catt, and ReqGQ are already pinned by
-- the Small Configuration Instance facts above, Safe[TargetPolicy] and
-- Useful[TargetPolicy] become GROUND (variable-free) formulas once
-- TargetPolicy is pinned -- so the SAT/UNSAT verdict of each `run` below
-- IS the truth value of that formula, not an existential search.
--
-- Python generates one fact block (see python_evaluator_small.py) of
-- the form:
--   fact PinTargetPolicy {
--     TargetPolicy.ageLevel = <AgeLevelAtom>
--     TargetPolicy.regionLevel = <RegionLevelAtom>
--     TargetPolicy.diseaseLevel = <DiseaseLevelAtom>
--   }
-- and appends it (plus exactly one of the two `run` commands below) to a
-- copy of this file before invoking Alloy headlessly.
-- ======================================================================

one sig TargetPolicy in Policy {}

-- These two commands are only meaningful in a Python-generated COPY of
-- this file that also includes a PinTargetPolicy fact (see above).
-- Left commented out here so that running this canonical file top-to-
-- bottom does not silently execute an unpinned (existential) query.
--run CheckTargetSafe   { Safe[TargetPolicy]   } for exactly 256 Record, exactly 60 Policy, exactly 1 ExternalRecord
--run CheckTargetUseful { Useful[TargetPolicy] } for exactly 256 Record, exactly 60 Policy, exactly 1 ExternalRecord
