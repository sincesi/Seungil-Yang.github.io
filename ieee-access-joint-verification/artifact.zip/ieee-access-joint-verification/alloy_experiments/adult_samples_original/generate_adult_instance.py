"""
generate_adult_instance.py

Generates a real-data (UCI Adult) instantiation of the validated JISA
Alloy model for the EQ3 scalability probe / applicability probe.

Design principle: this script does NOT modify the validated Transform
functions, generalization level hierarchies, or predicates in
jisa_joint_experiment_v1.als (Parts 2-6). It only changes the
INSTANCE-LEVEL facts (which real person maps to which existing raw
atom), exactly like generate_instance.py already does for the
Medium/Large synthetic configurations. This keeps risk low: the
core model logic that was already validated locally is untouched.

Mapping (three abstraction axes, matching Researcher 1's framing --
NOT relabeled as "Age/Region/Disease" in the paper text, but reusing
those Alloy sig names internally for minimal-risk reuse of the
validated template):

  Age (7 raw atoms A25/A27/A30/A35/A40/A45/A50, unchanged)
      <- real age, nearest-match to one of {25,27,30,35,40,45,50}

  "Region" slot (3 raw atoms Kanazawa/Komatsu/Toyama, unchanged)
      <- workclass, grouped into 3 categories:
           Kanazawa slot = Private
           Komatsu  slot = Government (Federal/State/Local-gov)
           Toyama   slot = Self-employed (Self-emp-not-inc/-inc)

  "Disease" slot (3 raw atoms Diabetes/Hypertension/Cancer, unchanged)
      <- occupation, grouped into 3 categories:
           Diabetes     slot = White-collar
           Hypertension slot = Blue-collar
           Cancer       slot = Service

  SensitiveValue (reusing 2 of the 3 existing atoms SDiabetes/SHypertension)
      <- income, directly per-record (NOT derived from the occupation
         group, unlike the original disease-linked design): >50K ->
         SDiabetes slot, <=50K -> SHypertension slot. This is a
         one-line change to the "SensitiveMatchesDisease"-equivalent
         fact, replacing the derived mapping with a direct per-record
         assignment from real income.

This produces a 256-record .als file with the SAME validated formal
structure as jisa_joint_experiment_v1.als, ready for the EQ3 scale
probe (scale_probe.py) or for a full exhaustive/pruning run
(python_evaluator.py).
"""

from __future__ import annotations

import csv
from pathlib import Path

CORE_FILE = Path("jisa_joint_experiment_v1.als")
SAMPLE_FILE = Path("adult_sample_256.csv")

AGE_ATOMS = [25, 27, 30, 35, 40, 45, 50]  # -> A25..A50
AGE_ATOM_NAMES = {25: "A25", 27: "A27", 30: "A30", 35: "A35", 40: "A40", 45: "A45", 50: "A50"}

WORKCLASS_GROUPS = {
    "Private": "Kanazawa",
    "Federal-gov": "Komatsu", "State-gov": "Komatsu", "Local-gov": "Komatsu",
    "Self-emp-not-inc": "Toyama", "Self-emp-inc": "Toyama",
}

OCCUPATION_GROUPS = {
    # White-collar -> Diabetes slot
    "Exec-managerial": "Diabetes", "Prof-specialty": "Diabetes", "Adm-clerical": "Diabetes",
    "Sales": "Diabetes", "Tech-support": "Diabetes", "Protective-serv": "Diabetes",
    "Armed-Forces": "Diabetes",
    # Blue-collar -> Hypertension slot
    "Craft-repair": "Hypertension", "Machine-op-inspct": "Hypertension",
    "Transport-moving": "Hypertension", "Handlers-cleaners": "Hypertension",
    "Farming-fishing": "Hypertension",
    # Service -> Cancer slot
    "Other-service": "Cancer", "Priv-house-serv": "Cancer",
}

INCOME_SENSITIVE = {">50K": "SDiabetes", "<=50K": "SHypertension"}


def nearest_age_atom(real_age: int) -> str:
    closest = min(AGE_ATOMS, key=lambda a: abs(a - real_age))
    return AGE_ATOM_NAMES[closest]


def load_sample():
    with open(SAMPLE_FILE) as f:
        rows = list(csv.DictReader(f))
    if len(rows) != 256:
        raise ValueError(f"expected 256 rows, got {len(rows)}")
    return rows


def build_record_facts(rows):
    """Map each of the 256 real rows onto R1..R256 using ONLY the
    existing validated atom vocabulary. Returns (facts, mapping_log)."""
    facts = []
    log = []
    for i, row in enumerate(rows, start=1):
        name = f"R{i}"
        age_atom = nearest_age_atom(int(row["age"]))
        region_atom = WORKCLASS_GROUPS.get(row["workclass"])
        disease_atom = OCCUPATION_GROUPS.get(row["occupation"])
        sensitive_atom = INCOME_SENSITIVE[row["income"]]
        if region_atom is None or disease_atom is None:
            raise ValueError(f"row {i}: unmapped category workclass={row['workclass']!r} "
                              f"occupation={row['occupation']!r}")
        facts.append(
            f"  {name}.age = {age_atom} and {name}.region = {region_atom} and "
            f"{name}.disease = {disease_atom}"
        )
        log.append((name, row["age"], age_atom, row["workclass"], region_atom,
                     row["occupation"], disease_atom, row["income"], sensitive_atom))
    return facts, log


def build_sensitive_facts(log):
    """Direct per-record sensitive-value assignment from real income,
    replacing the original disease-derived mapping."""
    return [f"  {name}.sensitive = {sensitive_atom}" for (name, *_rest, sensitive_atom) in log]


def pick_linkage_pair(log):
    """Find two records sharing the same (age_atom, region_atom) --
    i.e., a realistic QI collision -- to use as the ExternalRecord E1 /
    linked-record pair, analogous to Small's E1/R1 setup. Falls back to
    R1 linking to itself's own QI if no natural collision exists (still
    well-typed; only affects witness richness, not the scale-probe
    timing measurement)."""
    seen = {}
    for entry in log:
        name, _ra, age_atom, _rw, region_atom = entry[0], entry[1], entry[2], entry[3], entry[4]
        key = (age_atom, region_atom)
        if key in seen:
            return seen[key], name, age_atom, region_atom
        seen[key] = name
    first = log[0]
    return first[0], first[0], first[2], first[4]


def pick_task_requirement_pair(log):
    """Find two records sharing (age_atom, disease_atom) but differing
    in region_atom -- a region-driven collapse pair, analogous to
    Small's R3/R4 -- to serve as the single required-distinguishable
    pair for Req(G,Q)."""
    seen = {}
    for entry in log:
        name, age_atom, disease_atom, region_atom = entry[0], entry[2], entry[6], entry[4]
        key = (age_atom, disease_atom)
        if key in seen and seen[key][1] != region_atom:
            return seen[key][0], name
        seen[key] = (name, region_atom)
    # fallback: just require R1/R2 distinguishable (always well-typed)
    return log[0][0], log[1][0]


def main():
    rows = load_sample()
    facts, log = build_record_facts(rows)
    sensitive_facts = build_sensitive_facts(log)
    record_names = [entry[0] for entry in log]

    linked_from, linked_to, e1_age, e1_region = pick_linkage_pair(log)
    req_a, req_b = pick_task_requirement_pair(log)

    core = CORE_FILE.read_text()

    # 1. Replace record declaration (R1..R4) -> (R1..R256)
    old_decl = "one sig R1, R2, R3, R4 extends Record {}"
    new_decl = "one sig " + ", ".join(record_names) + " extends Record {}"
    assert core.count(old_decl) == 1
    core = core.replace(old_decl, new_decl, 1)

    # 2. Replace SmallRecordInstance fact block (age/region/disease only)
    old_comment = (
        "-- Small configuration records.\n"
        "-- R1/R2 share region; R3/R4 share age and disease but differ in region,\n"
        "-- so Req(G,Q) below requires them to remain distinguishable on a\n"
        "-- region-driven collapse -- independent of the disease axis that drives\n"
        "-- privacy exposure (ExposesSensitive, Part 5).\n"
    )
    new_comment = (
        "-- Adult-256 applicability probe: 256 real UCI Adult records\n"
        "-- (seed=42 sample, missing-value rows excluded), mapped onto the\n"
        "-- SAME validated raw-value vocabulary as the Small configuration.\n"
        "-- Age = nearest of {25,27,30,35,40,45,50} to real age.\n"
        "-- Region slot = workclass group (Kanazawa=Private, Komatsu=Government,\n"
        "-- Toyama=Self-employed). Disease slot = occupation group\n"
        "-- (Diabetes=White-collar, Hypertension=Blue-collar, Cancer=Service).\n"
        "-- See generate_adult_instance.py for the exact per-record mapping log.\n"
    )
    assert core.count(old_comment) == 1
    core = core.replace(old_comment, new_comment, 1)

    old_fact = (
        "fact SmallRecordInstance {\n"
        "  R1.age = A25 and R1.region = Kanazawa and R1.disease = Diabetes\n"
        "  R2.age = A27 and R2.region = Kanazawa and R2.disease = Hypertension\n"
        "  R3.age = A40 and R3.region = Komatsu  and R3.disease = Diabetes\n"
        "  R4.age = A40 and R4.region = Toyama   and R4.disease = Diabetes\n"
        "}"
    )
    new_fact = "fact Adult256RecordInstance {\n" + "\n".join(facts) + "\n}"
    assert core.count(old_fact) == 1
    core = core.replace(old_fact, new_fact, 1)

    # 3. Replace SensitiveMatchesDisease (derived) with direct per-record
    #    income-based assignment.
    old_sens = (
        "fact SensitiveMatchesDisease {\n"
        "  all r: Record | r.sensitive = sensOfDisease[r.disease]\n"
        "}"
    )
    new_sens = "fact Adult256SensitiveFromIncome {\n" + "\n".join(sensitive_facts) + "\n}"
    assert core.count(old_sens) == 1
    core = core.replace(old_sens, new_sens, 1)

    # 4. Replace ExternalRecord instance fact
    old_ext = (
        "fact SmallExternalInstance {\n"
        "  E1.extAge = A25\n"
        "  E1.extRegion = Kanazawa\n"
        "  E1.linkedTo = R1\n"
        "}"
    )
    new_ext = (
        "fact Adult256ExternalInstance {\n"
        f"  E1.extAge = {e1_age}\n"
        f"  E1.extRegion = {e1_region}\n"
        f"  E1.linkedTo = {linked_to}\n"
        "}"
    )
    assert core.count(old_ext) == 1
    core = core.replace(old_ext, new_ext, 1)

    # 5. Replace task requirement fact
    old_task = (
        "-- The Small task requires R3 and R4 to remain distinguishable.\n"
        "fact SmallTaskRequirement {\n"
        "  ReqGQ.pairs = R3->R4 + R4->R3\n"
        "}"
    )
    new_task = (
        "-- The Adult-256 task requires this real-data-derived pair to\n"
        "-- remain distinguishable (same age/occupation group, different\n"
        "-- workclass group -- a region-slot-driven collapse, analogous to\n"
        "-- Small's R3/R4 pair).\n"
        "fact Adult256TaskRequirement {\n"
        f"  ReqGQ.pairs = {req_a}->{req_b} + {req_b}->{req_a}\n"
        "}"
    )
    assert core.count(old_task) == 1
    core = core.replace(old_task, new_task, 1)

    # 6. Fix run/check command scopes: the base file hardcodes
    #    "exactly 4 Record" (Small's record count). This MUST become
    #    "exactly 256 Record" or Alloy will reject the model as
    #    inconsistent with the 256 one-sig Record atoms declared above.
    n_occurrences = core.count("exactly 4 Record")
    core = core.replace("exactly 4 Record", "exactly 256 Record")
    print(f"[fix] replaced 'exactly 4 Record' -> 'exactly 256 Record' "
          f"in {n_occurrences} command scope(s)")

    out_path = Path("jisa_joint_experiment_adult256.als")
    out_path.write_text(core)
    print(f"wrote {out_path} ({len(core)} bytes, 256 real Adult records)")
    print(f"linkage pair for E1: {linked_from} <-> {linked_to} "
          f"(age={e1_age}, region={e1_region})")
    print(f"task requirement pair: {req_a} <-> {req_b}")

    # Write the mapping log for transparency / reproducibility.
    log_path = Path("adult256_mapping_log.csv")
    with open(log_path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["record", "real_age", "age_atom", "real_workclass", "region_atom",
                     "real_occupation", "disease_atom", "real_income", "sensitive_atom"])
        w.writerows(log)
    print(f"wrote {log_path} (full per-record mapping, for reproducibility)")


if __name__ == "__main__":
    main()
