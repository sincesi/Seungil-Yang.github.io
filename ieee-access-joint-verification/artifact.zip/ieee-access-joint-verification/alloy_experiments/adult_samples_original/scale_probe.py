"""
scale_probe.py

Lightweight scalability probe for the JISA framework. Unlike
python_evaluator.py (which runs the full 60-policy exhaustive/pruning
sweep, up to 120 Alloy calls), this script measures Alloy solving time
for a SINGLE fixed policy at a given record count N, so that scaling
behavior can be measured without requiring the full sweep to complete
at each scale point.

Role boundary (per project role division): this script performs no
Alloy execution itself, and reports no numbers. It only orchestrates
subprocess calls to the user-run Alloy driver and prints/appends
whatever that driver actually returns. All reported solving times
come exclusively from the local Alloy execution; nothing here is
estimated, extrapolated, or fabricated.

Usage:
    1. Generate the scale instance first, e.g.:
         python3 generate_instance.py scale128 128
    2. Set ALLOY_CMD as usual:
         export ALLOY_CMD='java -cp alloy.jar AlloyRunDriver {als} {cmd}'
    3. Run the probe:
         python3 scale_probe.py scale128 128

Each run pins the single finest policy
(AgeExact, RegExact, DisExact) -- the same policy used throughout the
Small/Medium/Large configurations' EQ1 illustration -- and issues
exactly two Alloy calls (CheckTargetSafe, CheckTargetUseful). Results
are appended to scale_probe_results.csv so successive scale points
(128, 256, 512, ...) accumulate into one file across separate runs.

If a run does not complete within --timeout seconds (default 1800 =
30 minutes), it is aborted and recorded as "timeout" rather than left
to hang indefinitely; this is itself a valid, reportable outcome (the
operational boundary the probe is designed to find).
"""

from __future__ import annotations

import argparse
import csv
import os
import re
import shlex
import subprocess
import time
from pathlib import Path

FIXED_POLICY = {"age": "AgeExact", "region": "RegExact", "disease": "DisExact"}
RESULTS_CSV = Path("scale_probe_results.csv")


def generate_pinned_copy(als_path: Path, command: str, workdir: Path, n_records: int) -> Path:
    if command not in {"CheckTargetSafe", "CheckTargetUseful"}:
        raise ValueError(f"unknown command: {command}")
    predicate = "Safe" if command == "CheckTargetSafe" else "Useful"
    base = als_path.read_text()
    pin = f"""

-- ----------------------------------------------------------------------
-- scale_probe.py: single fixed-policy pin for scalability measurement.
-- ----------------------------------------------------------------------
fact PinTargetPolicy {{
  TargetPolicy.ageLevel = {FIXED_POLICY['age']}
  TargetPolicy.regionLevel = {FIXED_POLICY['region']}
  TargetPolicy.diseaseLevel = {FIXED_POLICY['disease']}
}}

run {command} {{
  {predicate}[TargetPolicy]
}} for exactly {n_records} Record, exactly 60 Policy, exactly 1 ExternalRecord
"""
    out = workdir / f"probe_{command}.als"
    out.write_text(base + pin)
    return out


def alloy_command(als_path: Path, command: str) -> list[str]:
    template = os.environ.get("ALLOY_CMD")
    if not template:
        raise RuntimeError(
            "Set ALLOY_CMD first, e.g. "
            "ALLOY_CMD='java -cp alloy.jar AlloyRunDriver {als} {cmd}'"
        )
    return shlex.split(template.format(als=str(als_path), cmd=command))


def run_one(als_path: Path, command: str, workdir: Path, n_records: int, timeout: int):
    pinned = generate_pinned_copy(als_path, command, workdir, n_records)
    cmd = alloy_command(pinned, command)
    t0 = time.time()
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return {"result": "timeout", "elapsed_ms": None, "wall_ms": timeout * 1000}
    wall_ms = (time.time() - t0) * 1000
    stdout = proc.stdout + "\n" + proc.stderr

    elapsed_match = re.search(r"Elapsed\(ms\):\s*(\d+)", stdout)
    elapsed_ms = float(elapsed_match.group(1)) if elapsed_match else None

    if re.search(r"No instance found|Predicate (is|may be) inconsistent", stdout, flags=re.I):
        sat = False
    elif re.search(r"(?<!No )Instance found|Predicate is consistent", stdout, flags=re.I):
        sat = True
    else:
        return {"result": "unparseable", "elapsed_ms": elapsed_ms, "wall_ms": wall_ms,
                 "raw_tail": stdout[-500:]}

    return {"result": "SAT" if sat else "UNSAT", "elapsed_ms": elapsed_ms, "wall_ms": wall_ms}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("config_name", help="e.g. scale128 (must match a generated .als file)")
    parser.add_argument("n_records", type=int, help="record count used in that .als file")
    parser.add_argument("--timeout", type=int, default=1800,
                         help="per-call timeout in seconds (default 1800 = 30 min)")
    args = parser.parse_args()

    als_path = Path(f"jisa_joint_experiment_{args.config_name}.als")
    if not als_path.exists():
        raise SystemExit(
            f"{als_path} not found. Generate it first: "
            f"python3 generate_instance.py {args.config_name} {args.n_records}"
        )

    workdir = Path(f"scale_probe_{args.config_name}")
    workdir.mkdir(exist_ok=True)

    print(f"=== Scale probe: {args.config_name} (N={args.n_records}) ===")
    print("Fixed policy: (AgeExact, RegExact, DisExact)")

    rows = []
    for command in ("CheckTargetSafe", "CheckTargetUseful"):
        print(f"Running {command} ...", flush=True)
        result = run_one(als_path, command, workdir, args.n_records, args.timeout)
        print(f"  -> {result}")
        rows.append({
            "config": args.config_name,
            "n_records": args.n_records,
            "command": command,
            **result,
        })

    write_header = not RESULTS_CSV.exists()
    with open(RESULTS_CSV, "a", newline="") as f:
        fieldnames = ["config", "n_records", "command", "result", "elapsed_ms", "wall_ms"]
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        if write_header:
            writer.writeheader()
        for row in rows:
            writer.writerow(row)

    print(f"\nAppended results to {RESULTS_CSV}.")
    if any(r["result"] == "timeout" for r in rows):
        print(f"\n*** TIMEOUT at N={args.n_records} (limit {args.timeout}s). "
              f"This is a valid, reportable operational boundary -- "
              f"consider this scale the stopping point. ***")


if __name__ == "__main__":
    main()
