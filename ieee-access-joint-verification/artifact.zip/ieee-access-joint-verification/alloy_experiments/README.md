# Alloy experiments (archived originals)

These are the original Alloy experiment materials, copied unchanged from the authors' working folders. Generated per-policy copies (`alloy_batch_runs*`) and compiled `.class` files are left out; the orchestrators regenerate them.

| Folder | Manuscript | Contents |
|---|---|---|
| `synthetic_small_v1/` | Sec. "Joint Verification with Alloy on Synthetic Configurations" (Small) | Model `jisa_joint_experiment_v1.als` (v1_3 = the singleton-exposure version), `python_evaluator_small.py` (orchestrator: exhaustive and pruned runs), `run_table3.sh`, `AlloyRunDriver.java`, result tables |
| `synthetic_small_medium_large/` | same section (Small/Medium/Large) | `generate_instance.py`, models for Medium and Large, `python_evaluator.py`, table3a (timing) and table3b (outputs) for each configuration |
| `record_scale_probe/` | Sec. "Operating Range of the Alloy Encoding" | 128/256/512-record synthetic models, `scale_probe.py`, `scale_probe_results.csv` (the 512-record utility attempts are recorded as unparseable), `policy_classification_small.csv` (Small verdict landscape) |
| `adult_samples_original/` | Sec. "Alloy on Adult Samples" (first version) | Adult-128/256 models, sampling and mapping logs, `generate_adult_instance.py` |
| `adult_rerun_v2/` | Sec. "Alloy on Adult Samples" (reported values) | v2 models, `make_models_v2.py`, `run_adult_sweep.py`, `direct_evaluator.py`, the E1 selection, expected verdicts from the direct evaluator, and the Adult-128 per-call log, verdicts and summary. Per-call logs, verdicts and summaries for both Adult-128 and Adult-256 (both 60/60 in agreement with the direct evaluator, no SAT4J fallback). |
| `sanity_checks/` | Sec. "Joint Verification with Alloy on Synthetic Configurations" | KernelInclusionSanity, UtilityWitnessInclusionSanity and witness-finding runs for Small/Medium/Large, rerun 2026-10-01 on Alloy 6.1.0 with MiniSat JNI (cloud Linux) |
| `archived_timing_runs/` | Table "Alloy solving and wall-clock time" | Every archived Small timing run: R1–R3, the MiniSatJNI GUI run (`table3a_MiniSatJNI1.csv`; `table3a.csv` duplicates R3) and two further runs (`table3a_small.csv`, `table3a_small_2.csv`). The manuscript reports the mean ± sd over all six. Medium/Large tables are included. |

Run: `javac -cp alloy.jar AlloyRunDriver.java`, then the orchestrator in each folder (see comments at the top of each script). The Alloy jar is Alloy 6.1.0 (`org.alloytools.alloy.dist.jar`), not included here.
