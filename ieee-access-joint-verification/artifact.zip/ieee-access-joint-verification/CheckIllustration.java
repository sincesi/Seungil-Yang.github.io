import edu.mit.csail.sdg.alloy4.A4Reporter;
import edu.mit.csail.sdg.ast.Command;
import edu.mit.csail.sdg.parser.CompModule;
import edu.mit.csail.sdg.parser.CompUtil;
import edu.mit.csail.sdg.translator.*;
public class CheckIllustration {
 public static void main(String[] args) throws Exception {
  CompModule m=CompUtil.parseEverything_fromFile(A4Reporter.NOP,null,args[0]);
  A4Options opts=new A4Options(); opts.solver=A4Options.SatSolver.SAT4J;
  for(Command c:m.getAllCommands()) {
   A4Solution s=TranslateAlloyToKodkod.execute_command(A4Reporter.NOP,m.getAllReachableSigs(),c,opts);
   System.out.println(c.label+"\t"+(c.check?"check":"run")+"\t"+(s.satisfiable()?"SAT":"UNSAT"));
   if(s.satisfiable()==c.check) throw new RuntimeException("Unexpected result: "+c.label);
  }
 }
}
