module theory_s4
// V1: bounded checks of the manuscript's structural results over ALL instances
// within scope (records, raw values, released values, policies, requirements,
// labels are symbolic). Two attributes; both are quasi-identifiers; the
// attacker knows every individual's quasi-identifier (E = D).

abstract sig Attr {}
one sig A1, A2 extends Attr {}
sig Val {}
sig Out {}
sig Label {}
sig Tup {}   // released-tuple identifiers, so g can be a first-order function

sig Record { val: Attr -> one Val, label: one Label }

// A policy is one total map Val -> Out per attribute (T_pi applied attribute-wise).
sig Policy { m: Attr -> Val -> one Out, tup: Record -> one Tup }
fact TupIds { all p: Policy, r, s: Record | r.(p.tup) = s.(p.tup) iff rel[p,r] = rel[p,s] }

one sig Q { req, req2: Record -> Record }

// ---------- semantics ----------
fun rel[p: Policy, r: Record]: Attr -> Out { {x: Attr, o: Out | o = p.m[x][r.val[x]]} }
fun K[p: Policy]: Record -> Record { {a, b: Record | rel[p,a] = rel[p,b]} }       // collapse kernel
fun W_U[p: Policy, R: Record -> Record]: Record -> Record { R & K[p] }                // utility counterexamples
pred Useful[p: Policy, R: Record -> Record] { no W_U[p,R] }
fun ReqL: Record -> Record { {a, b: Record | a.label != b.label} }                    // Req_l

// order-compatible coarsening: every map of q factors through the map of p
pred coarser[p, q: Policy] {
  all x: Attr, v, w: Val | p.m[x][v] = p.m[x][w] implies q.m[x][v] = q.m[x][w]
}

// singleton exposure under exact matching (E = D, QI = all attributes)
fun M[p: Policy, e: Record]: set Record { e.(K[p]) }
pred Unsafe[p: Policy] { some e: Record | M[p,e] = e }
pred Safe[p: Policy] { not Unsafe[p] }

// ---------- results ----------
assert Persistence {                     // Diagnostic Persistence: witnesses persist upward
  all p, q: Policy | coarser[p,q] implies W_U[p,Q.req] in W_U[q,Q.req]
}
assert FailureUpwardClosed {             // basis of pruning soundness
  all p, q: Policy | (coarser[p,q] and not Useful[p,Q.req]) implies not Useful[q,Q.req]
}
assert QuestionSensitivity {             // Req1 in Req2  =>  F2 in F1
  Q.req in Q.req2 implies (all p: Policy | Useful[p,Q.req2] implies Useful[p,Q.req])
}
assert LabelFactorization {              // Req_l /\ K = {} iff l = g o T_pi for a function g
  all p: Policy | let g = {t: Tup, l: Label | some r: Record | r.(p.tup) = t and r.label = l} |
    Useful[p, ReqL] iff ((all t: Record.(p.tup) | one g[t]) and (all r: Record | r.label = g[r.(p.tup)]))
}
assert LabelFactorizationPairs {         // pairwise form used by the O(nk) grouping check
  all p: Policy | Useful[p, ReqL] iff (all r, s: Record | rel[p,r] = rel[p,s] implies r.label = s.label)
}
assert SafeUpperSet {                    // generalization property under exact matching
  all p, q: Policy | (coarser[p,q] and Safe[p]) implies Safe[q]
}
assert AcceptedConvex {                  // accepted set is convex in the coarsening preorder
  all p, q, r: Policy | (coarser[p,q] and coarser[q,r] and Useful[p,Q.req] and Safe[p]
     and Useful[r,Q.req] and Safe[r]) implies (Useful[q,Q.req] and Safe[q])
}

// ---------- non-vacuity ----------
pred NonVacuous {
  no (Q.req & iden)
  some p, q: Policy | coarser[p,q] and p != q and Useful[p,Q.req] and not Useful[q,Q.req]
  some p, q: Policy | coarser[p,q] and Unsafe[p] and Safe[q]
}

run NonVacuous for 4 but exactly 2 Attr
check Persistence for 4 but exactly 2 Attr
check FailureUpwardClosed for 4 but exactly 2 Attr
check QuestionSensitivity for 4 but exactly 2 Attr
check LabelFactorization for 4 but exactly 2 Attr
check LabelFactorizationPairs for 4 but exactly 2 Attr
check SafeUpperSet for 4 but exactly 2 Attr
check AcceptedConvex for 4 but exactly 2 Attr
