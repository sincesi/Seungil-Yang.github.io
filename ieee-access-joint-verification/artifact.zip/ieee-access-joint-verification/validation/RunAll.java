import edu.mit.csail.sdg.alloy4.A4Reporter;
import edu.mit.csail.sdg.ast.Command;
import edu.mit.csail.sdg.parser.CompModule;
import edu.mit.csail.sdg.parser.CompUtil;
import edu.mit.csail.sdg.translator.*;
import java.util.*;
/** Runs every command (or those named in args[2..]) of args[0]; solver args[1]; prints label, kind, SAT/UNSAT, ms, and for SAT a compact instance. */
public class RunAll {
 public static void main(String[] a) throws Exception {
  CompModule m=CompUtil.parseEverything_fromFile(A4Reporter.NOP,null,a[0]);
  A4Options o=new A4Options();
  o.solver = a[1].equals("minisat")? A4Options.SatSolver.MiniSatJNI : A4Options.SatSolver.SAT4J;
  o.skolemDepth=1; o.symmetry=20;
  Set<String> only=new HashSet<>(Arrays.asList(a).subList(2,a.length));
  for(Command c:m.getAllCommands()){
   if(!only.isEmpty() && !only.contains(c.label)) continue;
   long t=System.nanoTime();
   A4Solution s=TranslateAlloyToKodkod.execute_command(A4Reporter.NOP,m.getAllReachableSigs(),c,o);
   long ms=(System.nanoTime()-t)/1000000;
   System.out.println("RESULT\t"+c.label+"\t"+(c.check?"check":"run")+"\t"+(s.satisfiable()?"SAT":"UNSAT")+"\t"+ms+"\t"+c.overall);
   if(s.satisfiable() && System.getenv("SHOW")!=null){ for(edu.mit.csail.sdg.ast.ExprVar v: s.getAllSkolems()) System.out.println("SKOLEM\t"+v.label+"\t"+s.eval(v)); }
  }
 }
}
