# Validation supplement

Alloy 6.1.0 (`org.alloytools.alloy.dist.jar`, not included). Set `ALLOY_JAR` to its path and compile once in this folder:

    javac -cp "$ALLOY_JAR" RunAll.java RunEval.java

## Bounded checks of the structural results
Run `java -cp "$ALLOY_JAR:." RunAll theory_s5.als minisat`. `theory.als` is the generic module; `theory_s{3,4,5,6}.als` add the commands for scopes 3–6. Results for scopes 3–5 are in `bounded_checks_s3-5.txt`. A scope-6 run was stopped unfinished after about 2.5 hours; the manuscript reports scopes 3–5 only.

## Seeded specification defects
The evaluator side is `../scale/v2_fault_injection.py`, which writes `fault_injection_results.json` and the exported artifacts `spec_<variant>_{hier,label}.als`. For the Alloy side, run:

    SHOW=1 java -Xss1g -cp "$ALLOY_JAR:." RunAll fault_injection/spec_D1_hier.als minisat

Outputs are in `fault_injection/alloy_*.txt` (RESULT lines, plus SKOLEM witnesses for violated obligations). Raw-value atoms are indexed in string-sorted order: `r_age_1` = 18, `r_age_3` = 20 (D1), `r_age_56` = 73, `r_age_62` = 79 (D2), `r_education_15` = Some-college (D3).

## Differential testing
Run:

    ALLOY_JAR=/path/alloy.jar python3 v3_differential.py 500 differential_out

This gives `differential/differential_results.json`. With `BUG=1`, the evaluator's safety test is off by one; the harness check result is in `differential/harness_mutation_results.json`.

## Metric optima, basis witnesses, pair vs grouping
The script is `../scale/v4_practical.py`; its output is in `practical/practical_results.json`.
