import edu.mit.csail.sdg.alloy4.A4Reporter;
import edu.mit.csail.sdg.ast.*;
import edu.mit.csail.sdg.parser.*;
import edu.mit.csail.sdg.translator.*;
/** For each model file: run its first command (fully pinned instance) and print the values of the
 *  functions UsefulL, UsefulR, SafeS, Coarser as tuples, plus solve time. */
public class RunEval {
 public static void main(String[] a) throws Exception {
  A4Options o=new A4Options(); o.solver=A4Options.SatSolver.MiniSatJNI; o.skolemDepth=1;
  for(String f: a){
   CompModule m=CompUtil.parseEverything_fromFile(A4Reporter.NOP,null,f);
   Command c=m.getAllCommands().get(0);
   long t=System.nanoTime();
   A4Solution s=TranslateAlloyToKodkod.execute_command(A4Reporter.NOP,m.getAllReachableSigs(),c,o);
   long ms=(System.nanoTime()-t)/1000000;
   System.out.println("FILE\t"+f+"\t"+(s.satisfiable()?"SAT":"UNSAT")+"\t"+ms);
   if(!s.satisfiable()) continue;
   for(String fn: new String[]{"UsefulL","UsefulR","SafeS","Coarser"}){
     Expr e=CompUtil.parseOneExpression_fromString(m, fn);
     System.out.println("VAL\t"+fn+"\t"+s.eval(e).toString());
   }
  }
 }
}
