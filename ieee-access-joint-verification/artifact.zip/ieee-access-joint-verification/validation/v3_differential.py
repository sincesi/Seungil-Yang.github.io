"""
v3_differential.py -- randomized differential testing: Alloy (reference semantics) vs the
direct evaluator on random small instances.

Per instance (seeded): n records, k attributes, a random chain of nested partitions per
attribute (finest = identity, last = suppression), a random label, a random irreflexive
symmetric requirement. Every attribute is a quasi-identifier and E = D.
Alloy evaluates, on the pinned instance, the sets
  UsefulL = {p | Req_l /\\ K_p = {}}   (pair-based, label requirement)
  UsefulR = {p | Req   /\\ K_p = {}}   (pair-based, random requirement)
  SafeS   = {p | no singleton match}
  Coarser = order-compatible coarsening relation on policies.
The direct evaluator computes the same sets independently: UsefulL by label grouping
(the O(nk) check licensed by the label-factorization proposition), UsefulR by pairs,
SafeS by group counts, Coarser by level-index product order. We also run Algorithm 1
(pruned search) on the direct verdicts and compare F, B, A with exhaustive and the call
count with 2|F|+|B|.
Usage: ALLOY_JAR=/path/to/alloy.jar python3 v3_differential.py N_INSTANCES out_dir
(compile first: javac -cp $ALLOY_JAR RunEval.java)
"""
import itertools, json, random, subprocess, sys, time
from pathlib import Path

import os
HERE = Path(__file__).resolve().parent            # RunEval.class is compiled here
JAR = os.environ.get("ALLOY_JAR", str(HERE / "alloy.jar"))   # Alloy 6.1.0 dist jar

def gen(seed):
    rnd = random.Random(seed)
    n = rnd.randint(3, 9); k = rnd.randint(1, 3)
    doms = [rnd.randint(2, 5) for _ in range(k)]
    recs = [[rnd.randrange(d) for d in doms] for _ in range(n)]
    hier = []
    for d in doms:
        levels = [list(range(d))]                        # identity
        cur = list(range(d))
        for _ in range(rnd.randint(0, 2)):              # random nested merges
            blocks = sorted(set(cur))
            if len(blocks) <= 2: break
            a, b = rnd.sample(blocks, 2)
            cur = [a if x == b else x for x in cur]
            levels.append(list(cur))
        levels.append([0] * d)                          # suppression
        hier.append(levels)
    nl = rnd.randint(2, 3)
    mode = rnd.random()
    if mode < 0.5:   # label is a function of one attribute's raw value (common case)
        j = rnd.randrange(k); f = [rnd.randrange(nl) for _ in range(doms[j])]
        label = [f[r[j]] for r in recs]
    else:
        label = [rnd.randrange(nl) for _ in range(n)]
    req = set()
    for i in range(n):
        for j2 in range(i + 1, n):
            if rnd.random() < 0.3: req.add((i, j2)); req.add((j2, i))
    return dict(n=n, k=k, doms=doms, recs=recs, hier=hier, label=label, req=sorted(req))

def policies(inst):
    return list(itertools.product(*[range(len(h)) for h in inst["hier"]]))

def to_alloy(inst, path):
    n, k, doms, hier = inst["n"], inst["k"], inst["doms"], inst["hier"]
    P = policies(inst)
    maxd = max(doms); nout = max(len(h) * maxd for h in hier)
    L = []
    L.append("module inst")
    L.append("abstract sig Attr {}\none sig " + ", ".join(f"A{j}" for j in range(k)) + " extends Attr {}")
    L.append("abstract sig Val {}\none sig " + ", ".join(f"v{x}" for x in range(maxd)) + " extends Val {}")
    L.append("abstract sig Out {}\none sig " + ", ".join(f"o{x}" for x in range(nout)) + " extends Out {}")
    L.append("abstract sig Label {}\none sig " + ", ".join(f"lb{x}" for x in range(3)) + " extends Label {}")
    L.append("abstract sig Record { val: Attr -> one Val, label: one Label }\none sig " + ", ".join(f"R{i}" for i in range(n)) + " extends Record {}")
    L.append("abstract sig Policy { m: Attr -> Val -> lone Out }\none sig " + ", ".join(f"P{i}" for i in range(len(P))) + " extends Policy {}")
    L.append("one sig Q { req: Record -> Record }")
    vt = [f"R{i}->A{j}->v{inst['recs'][i][j]}" for i in range(n) for j in range(k)]
    lt = [f"R{i}->lb{inst['label'][i]}" for i in range(n)]
    mt = []
    for pi, p in enumerate(P):
        for j in range(k):
            lev = hier[j][p[j]]
            for x in range(doms[j]):
                mt.append(f"P{pi}->A{j}->v{x}->o{p[j] * maxd + lev[x]}")
    rt = [f"R{a}->R{b}" for a, b in inst["req"]]
    L.append("fact { val = " + " + ".join(vt) + "\n  label = " + " + ".join(lt) + "\n  m = " + " + ".join(mt) +
             "\n  Q.req = " + (" + ".join(rt) if rt else "none->none") + " }")
    L.append("""fun rel[p: Policy, r: Record]: Attr -> Out { {x: Attr, o: Out | o = p.m[x][r.val[x]]} }
fun K[p: Policy]: Record -> Record { {a, b: Record | rel[p,a] = rel[p,b]} }
fun ReqL: Record -> Record { {a, b: Record | a.label != b.label} }
pred coarser[p, q: Policy] { all x: Attr, v, w: Val | (some p.m[x][v] and p.m[x][v] = p.m[x][w]) implies q.m[x][v] = q.m[x][w] }
fun UsefulL: set Policy { {p: Policy | no (ReqL & K[p])} }
fun UsefulR: set Policy { {p: Policy | no (Q.req & K[p])} }
fun SafeS: set Policy { {p: Policy | no e: Record | e.(K[p]) = e} }
fun Coarser: Policy -> Policy { {p, q: Policy | coarser[p,q]} }
run {} for 1""")
    Path(path).write_text("\n".join(L) + "\n")
    return P

def direct(inst):
    P = policies(inst); n = inst["n"]; hier = inst["hier"]; lab = inst["label"]
    def tup(p, i): return tuple(hier[j][p[j]][inst["recs"][i][j]] for j in range(inst["k"]))
    UL, UR, S = set(), set(), set()
    for pi, p in enumerate(P):
        groups = {}
        for i in range(n): groups.setdefault(tup(p, i), []).append(i)
        if all(len({lab[i] for i in g}) == 1 for g in groups.values()): UL.add(pi)       # grouping
        if not any(tup(p, a) == tup(p, b) for a, b in inst["req"]): UR.add(pi)            # pairs
        if all(len(g) >= (1 if __import__("os").environ.get("BUG") else 2) for g in groups.values()): S.add(pi)
    C = {(a, b) for a, p in enumerate(P) for b, q in enumerate(P) if all(x <= y for x, y in zip(p, q))}
    return P, UL, UR, S, C

def pruned(P, U, S):
    basis, Fp, Ap, calls = [], set(), set(), 0
    for i, p in enumerate(P):                          # product order is lexicographic
        if any(all(b[t] <= p[t] for t in range(len(p))) for b in basis): continue
        calls += 1
        if i not in U: basis.append(p); continue
        Fp.add(i); calls += 1
        if i in S: Ap.add(i)
    return Fp, Ap, basis, calls

def parse_set(s):
    s = s.strip("{} ")
    return set() if not s else {int(x.strip().split("$")[0][1:]) for x in s.split(",")}
def parse_rel(s):
    s = s.strip("{} ")
    if not s: return set()
    out = set()
    for t in s.split(","):
        a, b = [x.strip() for x in t.split("->")]
        out.add((int(a.split("$")[0][1:]), int(b.split("$")[0][1:])))
    return out

def main():
    N, out = int(sys.argv[1]), Path(sys.argv[2]); out.mkdir(exist_ok=True)
    insts, files = [], []
    for s in range(N):
        inst = gen(s); f = out / f"inst_{s:04d}.als"; to_alloy(inst, f); insts.append(inst); files.append(str(f))
    t0 = time.time(); alloy = {}
    for c in range(0, N, 50):
        r = subprocess.run(["java", "-Xss512m", "-cp", f"{JAR}{os.pathsep}{HERE}", "RunEval"] + files[c:c+50],
                           capture_output=True, text=True)
        cur = None
        for line in r.stdout.splitlines():
            parts = line.split("\t")
            if parts[0] == "FILE": cur = parts[1]; alloy[cur] = {"sat": parts[2], "ms": int(parts[3])}
            elif parts[0] == "VAL": alloy[cur][parts[1]] = parts[2]
    t_alloy = time.time() - t0
    rows, agree = [], {"UsefulL": 0, "UsefulR": 0, "SafeS": 0, "Coarser": 0, "pruned==exh": 0, "calls==formula": 0}
    mism = []
    for s, (inst, f) in enumerate(zip(insts, files)):
        a = alloy.get(f)
        P, UL, UR, S, C = direct(inst)
        if not a or a["sat"] != "SAT": mism.append((s, "alloy_failed")); continue
        ok = {"UsefulL": parse_set(a["UsefulL"]) == UL, "UsefulR": parse_set(a["UsefulR"]) == UR,
              "SafeS": parse_set(a["SafeS"]) == S, "Coarser": parse_rel(a["Coarser"]) == C}
        for U in (UL, UR):
            Fp, Ap, B, calls = pruned(P, U, S)
            F = U; A = U & S
            Bmin = [P[i] for i in range(len(P)) if i not in U and all(
                j in U for j in range(len(P)) if j != i and all(x <= y for x, y in zip(P[j], P[i])) and P[j] != P[i])]
            ok.setdefault("pruned==exh", True); ok.setdefault("calls==formula", True)
            ok["pruned==exh"] &= (Fp == F and Ap == A and sorted(B) == sorted(Bmin))
            ok["calls==formula"] &= (calls == 2 * len(F) + len(Bmin))
        for key, v in ok.items():
            agree[key] += int(v)
        if not all(ok.values()): mism.append((s, [k2 for k2, v in ok.items() if not v]))
        rows.append({"seed": s, "n": inst["n"], "k": inst["k"], "|P|": len(P), "|UL|": len(UL), "|UR|": len(UR),
                     "|S|": len(S), "alloy_ms": a["ms"], **ok})
    summ = {"instances": N, "agree": agree, "mismatches": mism, "alloy_wall_s": round(t_alloy, 1),
            "records_range": [min(r["n"] for r in rows), max(r["n"] for r in rows)],
            "policies_range": [min(r["|P|"] for r in rows), max(r["|P|"] for r in rows)],
            "policies_total": sum(r["|P|"] for r in rows),
            "useful_L_mixed": sum(1 for r in rows if 0 < r["|UL|"] < r["|P|"]),
            "useful_R_mixed": sum(1 for r in rows if 0 < r["|UR|"] < r["|P|"]),
            "safe_mixed": sum(1 for r in rows if 0 < r["|S|"] < r["|P|"])}
    json.dump({"summary": summ, "rows": rows}, open(out / "differential_results.json", "w"), indent=1)
    print(json.dumps(summ, indent=1))

if __name__ == "__main__":
    main()
