# ICFEM running example and coordinate-space study (recovered)

The originals were recovered from the author's Downloads folder; `SOURCE_MANIFEST.json` gives the source paths and hashes. The rerun outputs date from 2026-10-01 and are not historical logs.

- `exp_case_study.als`: the twelve-record running-example model (63-pair requirement, 8 policies). Rerun with `java -cp alloy.jar:. EvalExprs exp_case_study.als SearchFeasible "#UCE[Pi00]" ...` (Alloy 6.1.0, MiniSat JNI). The output is in `alloy_rerun_case_study_20261001.txt`; the counterexample counts equal Table "Running example: counterexamples per policy".
- `measure_pruning.py`: the evaluator for Table "Utility checks under pruning as the coordinate space grows". The unmodified rerun is in `RERUN_20261001.txt`.
- `STRUCTURAL_AUDIT_20261001.json` and `RECOVERY_FINDINGS_KO.txt`: the added coordinates duplicate the disease attribute, and higher levels map to suppression. The 81–1,296 coordinates therefore realize only 24–32 distinct transformations and 6–8 distinct kernels.
- `exp_scaling_G16.als` and `exp_scaling_G81.als`: Alloy models for 16 and 81 coordinates (not rerun).
