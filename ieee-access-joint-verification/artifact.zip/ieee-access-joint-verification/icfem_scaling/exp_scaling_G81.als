-- ================================================================
-- Experiment A-2: Policy-Space Scaling  |G| = 81  (3×3×3×3)
-- Four quasi-identifiers, each with 3 levels
-- ================================================================

module exp_scaling_G81

abstract sig Disease {}
one sig DM, HT, CP extends Disease {}
abstract sig Decade {}
one sig D40s, D60s, D70s extends Decade {}
abstract sig AgeGroup {}
one sig Adult, Senior extends AgeGroup {}
abstract sig ExactAge {}
one sig Age43, Age45, Age64, Age66, Age71, Age72 extends ExactAge {}

-- 4 attributes × 3 levels each = 81 policies
abstract sig Lv3 {}
one sig L0, L1, L2 extends Lv3 {}

pred LeL[a,b: Lv3] { a=b or (a=L0 and (b=L1 or b=L2)) or (a=L1 and b=L2) }

abstract sig Record {
  disease  : one Disease,
  exactAge : one ExactAge,
  decade   : one Decade,
  agegroup : one AgeGroup
}
one sig DM01,DM02,DM03,DM04,HT01,HT02,HT03,HT04,
        CP01,CP02,CP03,CP04 extends Record {}

fact Dataset {
  DM01.disease=DM DM01.exactAge=Age43 DM01.decade=D40s DM01.agegroup=Adult
  DM02.disease=DM DM02.exactAge=Age45 DM02.decade=D40s DM02.agegroup=Adult
  DM03.disease=DM DM03.exactAge=Age64 DM03.decade=D60s DM03.agegroup=Senior
  DM04.disease=DM DM04.exactAge=Age71 DM04.decade=D70s DM04.agegroup=Senior
  HT01.disease=HT HT01.exactAge=Age43 HT01.decade=D40s HT01.agegroup=Adult
  HT02.disease=HT HT02.exactAge=Age45 HT02.decade=D40s HT02.agegroup=Adult
  HT03.disease=HT HT03.exactAge=Age64 HT03.decade=D60s HT03.agegroup=Senior
  HT04.disease=HT HT04.exactAge=Age72 HT04.decade=D70s HT04.agegroup=Senior
  CP01.disease=CP CP01.exactAge=Age43 CP01.decade=D40s CP01.agegroup=Adult
  CP02.disease=CP CP02.exactAge=Age45 CP02.decade=D40s CP02.agegroup=Adult
  CP03.disease=CP CP03.exactAge=Age66 CP03.decade=D60s CP03.agegroup=Senior
  CP04.disease=CP CP04.exactAge=Age71 CP04.decade=D70s CP04.agegroup=Senior
}

abstract sig Policy {
  a1: one Lv3,  -- age attribute
  a2: one Lv3,  -- disease attribute
  a3: one Lv3,  -- extra QI-1
  a4: one Lv3   -- extra QI-2
}

-- 81 policies: enumerate all 3^4 combinations
one sig
  P0000,P0001,P0002, P0010,P0011,P0012, P0020,P0021,P0022,
  P0100,P0101,P0102, P0110,P0111,P0112, P0120,P0121,P0122,
  P0200,P0201,P0202, P0210,P0211,P0212, P0220,P0221,P0222,
  P1000,P1001,P1002, P1010,P1011,P1012, P1020,P1021,P1022,
  P1100,P1101,P1102, P1110,P1111,P1112, P1120,P1121,P1122,
  P1200,P1201,P1202, P1210,P1211,P1212, P1220,P1221,P1222,
  P2000,P2001,P2002, P2010,P2011,P2012, P2020,P2021,P2022,
  P2100,P2101,P2102, P2110,P2111,P2112, P2120,P2121,P2122,
  P2200,P2201,P2202, P2210,P2211,P2212, P2220,P2221,P2222
  extends Policy {}

fact PolicyFact {
  P0000.a1=L0 P0000.a2=L0 P0000.a3=L0 P0000.a4=L0
  P0001.a1=L0 P0001.a2=L0 P0001.a3=L0 P0001.a4=L1
  P0002.a1=L0 P0002.a2=L0 P0002.a3=L0 P0002.a4=L2
  P0010.a1=L0 P0010.a2=L0 P0010.a3=L1 P0010.a4=L0
  P0011.a1=L0 P0011.a2=L0 P0011.a3=L1 P0011.a4=L1
  P0012.a1=L0 P0012.a2=L0 P0012.a3=L1 P0012.a4=L2
  P0020.a1=L0 P0020.a2=L0 P0020.a3=L2 P0020.a4=L0
  P0021.a1=L0 P0021.a2=L0 P0021.a3=L2 P0021.a4=L1
  P0022.a1=L0 P0022.a2=L0 P0022.a3=L2 P0022.a4=L2
  P0100.a1=L0 P0100.a2=L1 P0100.a3=L0 P0100.a4=L0
  P0101.a1=L0 P0101.a2=L1 P0101.a3=L0 P0101.a4=L1
  P0102.a1=L0 P0102.a2=L1 P0102.a3=L0 P0102.a4=L2
  P0110.a1=L0 P0110.a2=L1 P0110.a3=L1 P0110.a4=L0
  P0111.a1=L0 P0111.a2=L1 P0111.a3=L1 P0111.a4=L1
  P0112.a1=L0 P0112.a2=L1 P0112.a3=L1 P0112.a4=L2
  P0120.a1=L0 P0120.a2=L1 P0120.a3=L2 P0120.a4=L0
  P0121.a1=L0 P0121.a2=L1 P0121.a3=L2 P0121.a4=L1
  P0122.a1=L0 P0122.a2=L1 P0122.a3=L2 P0122.a4=L2
  P0200.a1=L0 P0200.a2=L2 P0200.a3=L0 P0200.a4=L0
  P0201.a1=L0 P0201.a2=L2 P0201.a3=L0 P0201.a4=L1
  P0202.a1=L0 P0202.a2=L2 P0202.a3=L0 P0202.a4=L2
  P0210.a1=L0 P0210.a2=L2 P0210.a3=L1 P0210.a4=L0
  P0211.a1=L0 P0211.a2=L2 P0211.a3=L1 P0211.a4=L1
  P0212.a1=L0 P0212.a2=L2 P0212.a3=L1 P0212.a4=L2
  P0220.a1=L0 P0220.a2=L2 P0220.a3=L2 P0220.a4=L0
  P0221.a1=L0 P0221.a2=L2 P0221.a3=L2 P0221.a4=L1
  P0222.a1=L0 P0222.a2=L2 P0222.a3=L2 P0222.a4=L2
  P1000.a1=L1 P1000.a2=L0 P1000.a3=L0 P1000.a4=L0
  P1001.a1=L1 P1001.a2=L0 P1001.a3=L0 P1001.a4=L1
  P1002.a1=L1 P1002.a2=L0 P1002.a3=L0 P1002.a4=L2
  P1010.a1=L1 P1010.a2=L0 P1010.a3=L1 P1010.a4=L0
  P1011.a1=L1 P1011.a2=L0 P1011.a3=L1 P1011.a4=L1
  P1012.a1=L1 P1012.a2=L0 P1012.a3=L1 P1012.a4=L2
  P1020.a1=L1 P1020.a2=L0 P1020.a3=L2 P1020.a4=L0
  P1021.a1=L1 P1021.a2=L0 P1021.a3=L2 P1021.a4=L1
  P1022.a1=L1 P1022.a2=L0 P1022.a3=L2 P1022.a4=L2
  P1100.a1=L1 P1100.a2=L1 P1100.a3=L0 P1100.a4=L0
  P1101.a1=L1 P1101.a2=L1 P1101.a3=L0 P1101.a4=L1
  P1102.a1=L1 P1102.a2=L1 P1102.a3=L0 P1102.a4=L2
  P1110.a1=L1 P1110.a2=L1 P1110.a3=L1 P1110.a4=L0
  P1111.a1=L1 P1111.a2=L1 P1111.a3=L1 P1111.a4=L1
  P1112.a1=L1 P1112.a2=L1 P1112.a3=L1 P1112.a4=L2
  P1120.a1=L1 P1120.a2=L1 P1120.a3=L2 P1120.a4=L0
  P1121.a1=L1 P1121.a2=L1 P1121.a3=L2 P1121.a4=L1
  P1122.a1=L1 P1122.a2=L1 P1122.a3=L2 P1122.a4=L2
  P1200.a1=L1 P1200.a2=L2 P1200.a3=L0 P1200.a4=L0
  P1201.a1=L1 P1201.a2=L2 P1201.a3=L0 P1201.a4=L1
  P1202.a1=L1 P1202.a2=L2 P1202.a3=L0 P1202.a4=L2
  P1210.a1=L1 P1210.a2=L2 P1210.a3=L1 P1210.a4=L0
  P1211.a1=L1 P1211.a2=L2 P1211.a3=L1 P1211.a4=L1
  P1212.a1=L1 P1212.a2=L2 P1212.a3=L1 P1212.a4=L2
  P1220.a1=L1 P1220.a2=L2 P1220.a3=L2 P1220.a4=L0
  P1221.a1=L1 P1221.a2=L2 P1221.a3=L2 P1221.a4=L1
  P1222.a1=L1 P1222.a2=L2 P1222.a3=L2 P1222.a4=L2
  P2000.a1=L2 P2000.a2=L0 P2000.a3=L0 P2000.a4=L0
  P2001.a1=L2 P2001.a2=L0 P2001.a3=L0 P2001.a4=L1
  P2002.a1=L2 P2002.a2=L0 P2002.a3=L0 P2002.a4=L2
  P2010.a1=L2 P2010.a2=L0 P2010.a3=L1 P2010.a4=L0
  P2011.a1=L2 P2011.a2=L0 P2011.a3=L1 P2011.a4=L1
  P2012.a1=L2 P2012.a2=L0 P2012.a3=L1 P2012.a4=L2
  P2020.a1=L2 P2020.a2=L0 P2020.a3=L2 P2020.a4=L0
  P2021.a1=L2 P2021.a2=L0 P2021.a3=L2 P2021.a4=L1
  P2022.a1=L2 P2022.a2=L0 P2022.a3=L2 P2022.a4=L2
  P2100.a1=L2 P2100.a2=L1 P2100.a3=L0 P2100.a4=L0
  P2101.a1=L2 P2101.a2=L1 P2101.a3=L0 P2101.a4=L1
  P2102.a1=L2 P2102.a2=L1 P2102.a3=L0 P2102.a4=L2
  P2110.a1=L2 P2110.a2=L1 P2110.a3=L1 P2110.a4=L0
  P2111.a1=L2 P2111.a2=L1 P2111.a3=L1 P2111.a4=L1
  P2112.a1=L2 P2112.a2=L1 P2112.a3=L1 P2112.a4=L2
  P2120.a1=L2 P2120.a2=L1 P2120.a3=L2 P2120.a4=L0
  P2121.a1=L2 P2121.a2=L1 P2121.a3=L2 P2121.a4=L1
  P2122.a1=L2 P2122.a2=L1 P2122.a3=L2 P2122.a4=L2
  P2200.a1=L2 P2200.a2=L2 P2200.a3=L0 P2200.a4=L0
  P2201.a1=L2 P2201.a2=L2 P2201.a3=L0 P2201.a4=L1
  P2202.a1=L2 P2202.a2=L2 P2202.a3=L0 P2202.a4=L2
  P2210.a1=L2 P2210.a2=L2 P2210.a3=L1 P2210.a4=L0
  P2211.a1=L2 P2211.a2=L2 P2211.a3=L1 P2211.a4=L1
  P2212.a1=L2 P2212.a2=L2 P2212.a3=L1 P2212.a4=L2
  P2220.a1=L2 P2220.a2=L2 P2220.a3=L2 P2220.a4=L0
  P2221.a1=L2 P2221.a2=L2 P2221.a3=L2 P2221.a4=L1
  P2222.a1=L2 P2222.a2=L2 P2222.a3=L2 P2222.a4=L2
}

pred LeP[pa,pb: Policy] {
  LeL[pa.a1,pb.a1] and LeL[pa.a2,pb.a2]
  and LeL[pa.a3,pb.a3] and LeL[pa.a4,pb.a4]
}

-- Age: L0=exact, L1=decade, L2=agegroup (3 levels, no full suppress)
pred SameAge[p: Policy, d1,d2: Record] {
  (p.a1=L0 and d1.exactAge=d2.exactAge)
  or (p.a1=L1 and d1.decade=d2.decade)
  or (p.a1=L2 and d1.agegroup=d2.agegroup)
}
-- Disease: L0=keep, L1=suppress(→ same), L2=suppress
pred SameDis[p: Policy, d1,d2: Record] {
  (p.a2=L0 and d1.disease=d2.disease) or (p.a2=L1) or (p.a2=L2)
}
pred SameE1[p: Policy, d1,d2: Record] {
  (p.a3=L0 and d1.disease=d2.disease) or (p.a3=L1) or (p.a3=L2)
}
pred SameE2[p: Policy, d1,d2: Record] {
  (p.a4=L0 and d1.disease=d2.disease) or (p.a4=L1) or (p.a4=L2)
}
pred SameReleased[p: Policy, d1,d2: Record] {
  SameAge[p,d1,d2] and SameDis[p,d1,d2] and SameE1[p,d1,d2] and SameE2[p,d1,d2]
}

one sig ReqQ { pairs: Record -> Record }
pred DiseaseOrder[d1,d2: Record] {
  (d1.disease=DM and d2.disease=HT) or (d1.disease=DM and d2.disease=CP)
  or (d1.disease=HT and d2.disease=CP)
}
pred DecadeOrder[d1,d2: Record] {
  (d1.decade=D40s and d2.decade=D60s) or (d1.decade=D40s and d2.decade=D70s)
  or (d1.decade=D60s and d2.decade=D70s)
}
fact ReqQFact {
  ReqQ.pairs = { d1,d2: Record |
    DiseaseOrder[d1,d2] or (d1.disease=d2.disease and DecadeOrder[d1,d2])
  }
}

fun Collapse[p: Policy]: Record->Record { {d1,d2: Record | SameReleased[p,d1,d2]} }
fun UCE[p: Policy]: Record->Record { ReqQ.pairs & Collapse[p] }
pred Useful[p: Policy] { no UCE[p] }

-- ── COMMANDS ────────────────────────────────────────────────────

run SearchFeasible {
  some p: Policy | Useful[p]
} for exactly 12 Record, exactly 81 Policy, 7 Int

check DiagnosticPersistence {
  all pa,pb: Policy | LeP[pa,pb] implies UCE[pa] in UCE[pb]
} for exactly 12 Record, exactly 81 Policy, 7 Int

-- Evaluator after SearchFeasible:
--   #{ p: Policy | no UCE[p] }   --> number of feasible policies (expect ~38)
--   { p: Policy | no UCE[p] }    --> feasible set
