-- ================================================================
-- Experiment 0: Case Study Verification (|G|=8, N=12)
-- Reproduces Table 3 (results) from the paper exactly.
-- Run each command separately in Alloy Analyzer 6.1.0
-- ================================================================

module exp_case_study

-- ── Attribute domains ────────────────────────────────────────────
abstract sig Disease {}
one sig DM, HT, CP extends Disease {}

abstract sig Decade {}
one sig D40s, D60s, D70s extends Decade {}

abstract sig AgeGroup {}
one sig Adult, Senior extends AgeGroup {}

abstract sig ExactAge {}
one sig Age43, Age45, Age64, Age66,
        Age71, Age72 extends ExactAge {}

abstract sig GenLevel {}
one sig G0, G1, G2, G3 extends GenLevel {}

abstract sig SuppChoice {}
one sig S0, S1 extends SuppChoice {}

-- ── Records ──────────────────────────────────────────────────────
abstract sig Record {
  disease  : one Disease,
  exactAge : one ExactAge,
  decade   : one Decade,
  agegroup : one AgeGroup
}
one sig DM01, DM02, DM03, DM04,
        HT01, HT02, HT03, HT04,
        CP01, CP02, CP03, CP04 extends Record {}

fact Dataset {
  DM01.disease=DM  DM01.exactAge=Age43  DM01.decade=D40s  DM01.agegroup=Adult
  DM02.disease=DM  DM02.exactAge=Age45  DM02.decade=D40s  DM02.agegroup=Adult
  DM03.disease=DM  DM03.exactAge=Age64  DM03.decade=D60s  DM03.agegroup=Senior
  DM04.disease=DM  DM04.exactAge=Age71  DM04.decade=D70s  DM04.agegroup=Senior
  HT01.disease=HT  HT01.exactAge=Age43  HT01.decade=D40s  HT01.agegroup=Adult
  HT02.disease=HT  HT02.exactAge=Age45  HT02.decade=D40s  HT02.agegroup=Adult
  HT03.disease=HT  HT03.exactAge=Age64  HT03.decade=D60s  HT03.agegroup=Senior
  HT04.disease=HT  HT04.exactAge=Age72  HT04.decade=D70s  HT04.agegroup=Senior
  CP01.disease=CP  CP01.exactAge=Age43  CP01.decade=D40s  CP01.agegroup=Adult
  CP02.disease=CP  CP02.exactAge=Age45  CP02.decade=D40s  CP02.agegroup=Adult
  CP03.disease=CP  CP03.exactAge=Age66  CP03.decade=D60s  CP03.agegroup=Senior
  CP04.disease=CP  CP04.exactAge=Age71  CP04.decade=D70s  CP04.agegroup=Senior
}

-- ── Policies ─────────────────────────────────────────────────────
abstract sig Policy {
  gen : one GenLevel,
  sup : one SuppChoice
}
one sig Pi00, Pi10, Pi20, Pi30,
        Pi01, Pi11, Pi21, Pi31 extends Policy {}

fact PolicyFact {
  Pi00.gen=G0  Pi00.sup=S0
  Pi10.gen=G1  Pi10.sup=S0
  Pi20.gen=G2  Pi20.sup=S0
  Pi30.gen=G3  Pi30.sup=S0
  Pi01.gen=G0  Pi01.sup=S1
  Pi11.gen=G1  Pi11.sup=S1
  Pi21.gen=G2  Pi21.sup=S1
  Pi31.gen=G3  Pi31.sup=S1
}

-- ── Ordering ─────────────────────────────────────────────────────
pred LeG[a, b: GenLevel] {
  a=b
  or (a=G0 and (b=G1 or b=G2 or b=G3))
  or (a=G1 and (b=G2 or b=G3))
  or (a=G2 and b=G3)
}
pred LeS[a, b: SuppChoice] { a=b or (a=S0 and b=S1) }
pred LeP[pa, pb: Policy] { LeG[pa.gen,pb.gen] and LeS[pa.sup,pb.sup] }

-- ── Transformation ───────────────────────────────────────────────
pred SameReleasedAge[p: Policy, d1, d2: Record] {
  (p.gen=G0 and d1.exactAge  = d2.exactAge)
  or (p.gen=G1 and d1.decade   = d2.decade)
  or (p.gen=G2 and d1.agegroup = d2.agegroup)
  or (p.gen=G3)
}
pred SameReleasedDisease[p: Policy, d1, d2: Record] {
  (p.sup=S0 and d1.disease = d2.disease) or (p.sup=S1)
}
pred SameReleased[p: Policy, d1, d2: Record] {
  SameReleasedAge[p,d1,d2] and SameReleasedDisease[p,d1,d2]
}

-- ── Req(Q) ───────────────────────────────────────────────────────
one sig ReqQ { pairs: Record -> Record }

pred DiseaseOrder[d1, d2: Record] {
  (d1.disease=DM and d2.disease=HT)
  or (d1.disease=DM and d2.disease=CP)
  or (d1.disease=HT and d2.disease=CP)
}
pred DecadeOrder[d1, d2: Record] {
  (d1.decade=D40s and d2.decade=D60s)
  or (d1.decade=D40s and d2.decade=D70s)
  or (d1.decade=D60s and d2.decade=D70s)
}
fact ReqQFact {
  ReqQ.pairs = { d1, d2: Record |
    DiseaseOrder[d1,d2]
    or (d1.disease=d2.disease and DecadeOrder[d1,d2])
  }
}

-- ── UCE / Useful ─────────────────────────────────────────────────
fun Collapse[p: Policy]: Record -> Record {
  { d1, d2: Record | SameReleased[p,d1,d2] }
}
fun UCE[p: Policy]: Record -> Record {
  ReqQ.pairs & Collapse[p]
}
pred Useful[p: Policy] { no UCE[p] }

-- ================================================================
-- COMMANDS — run each separately, read results in Evaluator
-- ================================================================

-- [1] Sanity: |Req(Q)| should be 63
assert ReqQCount { #ReqQ.pairs = 63 }
check ReqQCount
  for exactly 12 Record, exactly 8 Policy, 7 Int

-- [2] Find feasible policies
run SearchFeasible {
  some p: Policy | Useful[p]
} for exactly 12 Record, exactly 8 Policy, 7 Int

-- [3] Extract collapse witnesses
run ExtractWitnesses {
  some p: Policy | some UCE[p]
} for exactly 12 Record, exactly 8 Policy, 7 Int

-- [4] Diagnostic Persistence check (no counterexample expected)
check DiagnosticPersistence {
  all pa, pb: Policy | LeP[pa,pb] implies UCE[pa] in UCE[pb]
} for exactly 12 Record, exactly 8 Policy, 7 Int

-- ================================================================
-- After running [2] or [3], open the Alloy Evaluator and type:
--
--   #ReqQ.pairs          --> should be 63
--   #UCE[Pi00]           --> 0  (feasible)
--   #UCE[Pi10]           --> 0  (feasible)
--   #UCE[Pi20]           --> 3
--   #UCE[Pi30]           --> 15
--   #UCE[Pi01]           --> 8
--   #UCE[Pi11]           --> 18
--   #UCE[Pi21]           --> 27
--   #UCE[Pi31]           --> 63
-- ================================================================
