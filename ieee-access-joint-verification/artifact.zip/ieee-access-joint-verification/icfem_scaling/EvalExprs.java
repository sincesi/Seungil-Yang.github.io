import edu.mit.csail.sdg.alloy4.A4Reporter;
import edu.mit.csail.sdg.ast.*;
import edu.mit.csail.sdg.parser.*;
import edu.mit.csail.sdg.translator.*;
/** java EvalExprs model.als Command expr1 expr2 ... : runs Command (MiniSat JNI), prints result and each expression's value. */
public class EvalExprs {
 public static void main(String[] a) throws Exception {
  CompModule m=CompUtil.parseEverything_fromFile(A4Reporter.NOP,null,a[0]);
  A4Options o=new A4Options(); o.solver=A4Options.SatSolver.MiniSatJNI;
  for(Command c:m.getAllCommands()){
   long t=System.nanoTime();
   A4Solution s=TranslateAlloyToKodkod.execute_command(A4Reporter.NOP,m.getAllReachableSigs(),c,o);
   System.out.println("RESULT\t"+c.label+"\t"+(c.check?"check":"run")+"\t"+(s.satisfiable()?"SAT":"UNSAT")+"\t"+(System.nanoTime()-t)/1000000);
   if(c.label.equals(a[1]) && s.satisfiable())
     for(int i=2;i<a.length;i++) System.out.println("EVAL\t"+a[i]+"\t"+s.eval(CompUtil.parseOneExpression_fromString(m,a[i])));
  }
 }
}
