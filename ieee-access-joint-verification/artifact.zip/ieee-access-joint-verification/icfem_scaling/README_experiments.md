# ICFEM Scaling Experiments — Alloy Execution Guide

## 실험 목적
Lattice-guided pruning (Algorithm 1)의 실제 효율을 측정한다.
- Exhaustive SAT calls vs Pruning SAT calls 비교
- |G| 증가에 따른 reduction % 측정

---

## 파일 구성

| 파일 | |G| | Config |
|---|---|---|
| exp_case_study.als | 8 | 4×2 (논문 case study) |
| exp_scaling_G16.als | 16 | 4×2×2 |
| exp_scaling_G81.als | 81 | 3×3×3×3 |

(G=256, 625, 1296은 Alloy로 직접 돌리기 어려울 수 있음 — Python 결과 사용 가능)

---

## 실행 방법

### Step 1: Alloy Analyzer 열기
Alloy Analyzer 6.1.0 실행 → File → Open → 해당 .als 파일

### Step 2: SAT invocation 수 측정 방법

Alloy Analyzer는 SAT call 수를 직접 출력하지 않는다.
대신 **두 가지 방법**으로 측정한다:

#### 방법 A: 수동 policy별 실행 (정확, 권장)

각 policy를 하나씩 Evaluator에서 확인:
```
#UCE[P000]   --> 0이면 Useful, >0이면 infeasible
#UCE[P001]
...
```
Useful인 policy에서만 successors를 탐색하는 것이 Algorithm 1.

#### 방법 B: 시간 측정

Alloy Analyzer Options에서 **Verbosity를 높이면** solver 통계가 출력됨.
각 `run` 명령의 실행 시간을 기록.

---

## 측정해야 할 수치 (Table 1 for paper)

### exp_case_study.als (|G|=8) — 이미 검증됨
```
Exhaustive: 8 policy checks
Pruning (Algorithm 1):
  - check π₀₀ (0,0): Useful → explore successors (1,0), (0,1)
  - check π₁₀ (1,0): Useful → explore successors (2,0), (1,1)
  - check π₀₁ (0,1): NOT Useful → prune (1,1),(2,1),(3,1)
  - check π₂₀ (2,0): NOT Useful → prune (3,0),(2,1),...
  - check π₁₁: already pruned
  Total: 4 checks
  Reduction: (8-4)/8 = 50.0%
```

### exp_scaling_G16.als (|G|=16)
Evaluator에서 실행 후:
```
{ p: Policy | no UCE[p] }   -- feasible set
```
Algorithm 1 BFS를 수동으로 트레이스하거나,
Python 결과(8 calls, 50.0% reduction) 참조 가능.

---

## Evaluator 명령어 모음

SearchFeasible 실행 후 Evaluator에서:

```alloy
-- 기본 확인
#ReqQ.pairs                        -- should be 63

-- 각 policy의 UCE 수
#UCE[Pi00]    -- 0  feasible
#UCE[Pi10]    -- 0  feasible  ← maximal feasible
#UCE[Pi20]    -- 3
#UCE[Pi30]    -- 15
#UCE[Pi01]    -- 8
#UCE[Pi11]    -- 18
#UCE[Pi21]    -- 27
#UCE[Pi31]    -- 63

-- feasible set
{ p: Policy | no UCE[p] }

-- maximal feasible (no strictly stronger feasible policy)
{ p: Policy | no UCE[p] and
  (all q: Policy | LeP[p,q] and p!=q implies some UCE[q]) }

-- infeasible region size
#{ p: Policy | some UCE[p] }
```

---

## Python 결과 (Alloy 실행이 어려운 경우)

Python 재현 결과 (`icfem_scaling_experiment.py`):

```
Table 1: Policy-Space Scaling (N=12 records)
|G|    Config    Exhaust  Pruning  Pruned  Reduction
  16   4×2×2         16        8       8     50.0%
  81   3×3×3×3       81       40      41     50.6%
 256   4×4×4×4      256       76     180     70.3%
 625   5×5×5×5      625      124     501     80.2%
1296   6×6×6×6     1296      184    1112     85.8%
```

모든 수치는 Alloy 모델의 relational logic을 Python으로 정확히 재현한 것.
case study (|G|=8)에서 8가지 UCE 수치가 논문과 일치함을 검증.

---

## 논문에 쓸 최종 수치

- 최대 reduction: **85.8%** (|G|=1296)
- 논문 표현: "up to 85.8% reduction in SAT invocations"
  (이전 초안의 "89.3%"는 실제값 아님 → 85.8%로 수정 필요)
