-- ================================================================
-- Experiment A-1: Policy-Space Scaling  |G| = 16  (4×2×2)
-- Three quasi-identifiers: Age(4 levels), Disease(2), Extra(2)
-- ================================================================

module exp_scaling_G16

abstract sig Disease {}
one sig DM, HT, CP extends Disease {}

abstract sig Decade {}
one sig D40s, D60s, D70s extends Decade {}

abstract sig AgeGroup {}
one sig Adult, Senior extends AgeGroup {}

abstract sig ExactAge {}
one sig Age43, Age45, Age64, Age66, Age71, Age72 extends ExactAge {}

-- Age: 4 levels (G0=exact, G1=decade, G2=agegroup, G3=suppressed)
abstract sig AgeLevel {}
one sig A0, A1, A2, A3 extends AgeLevel {}

-- Disease: 2 levels (D0=keep, D1=suppress)
abstract sig DisLevel {}
one sig Dis0, Dis1 extends DisLevel {}

-- Extra QI: 2 levels (E0=keep, E1=suppress)
abstract sig ExtLevel {}
one sig E0, E1 extends ExtLevel {}

abstract sig Record {
  disease  : one Disease,
  exactAge : one ExactAge,
  decade   : one Decade,
  agegroup : one AgeGroup
}
one sig DM01, DM02, DM03, DM04,
        HT01, HT02, HT03, HT04,
        CP01, CP02, CP03, CP04 extends Record {}

fact Dataset {
  DM01.disease=DM  DM01.exactAge=Age43  DM01.decade=D40s  DM01.agegroup=Adult
  DM02.disease=DM  DM02.exactAge=Age45  DM02.decade=D40s  DM02.agegroup=Adult
  DM03.disease=DM  DM03.exactAge=Age64  DM03.decade=D60s  DM03.agegroup=Senior
  DM04.disease=DM  DM04.exactAge=Age71  DM04.decade=D70s  DM04.agegroup=Senior
  HT01.disease=HT  HT01.exactAge=Age43  HT01.decade=D40s  HT01.agegroup=Adult
  HT02.disease=HT  HT02.exactAge=Age45  HT02.decade=D40s  HT02.agegroup=Adult
  HT03.disease=HT  HT03.exactAge=Age64  HT03.decade=D60s  HT03.agegroup=Senior
  HT04.disease=HT  HT04.exactAge=Age72  HT04.decade=D70s  HT04.agegroup=Senior
  CP01.disease=CP  CP01.exactAge=Age43  CP01.decade=D40s  CP01.agegroup=Adult
  CP02.disease=CP  CP02.exactAge=Age45  CP02.decade=D40s  CP02.agegroup=Adult
  CP03.disease=CP  CP03.exactAge=Age66  CP03.decade=D60s  CP03.agegroup=Senior
  CP04.disease=CP  CP04.exactAge=Age71  CP04.decade=D70s  CP04.agegroup=Senior
}

abstract sig Policy {
  alev : one AgeLevel,
  dlev : one DisLevel,
  elev : one ExtLevel
}
-- 4 * 2 * 2 = 16 policies
one sig
  P000, P001, P010, P011,
  P100, P101, P110, P111,
  P200, P201, P210, P211,
  P300, P301, P310, P311
  extends Policy {}

fact PolicyFact {
  P000.alev=A0  P000.dlev=Dis0  P000.elev=E0
  P001.alev=A0  P001.dlev=Dis0  P001.elev=E1
  P010.alev=A0  P010.dlev=Dis1  P010.elev=E0
  P011.alev=A0  P011.dlev=Dis1  P011.elev=E1
  P100.alev=A1  P100.dlev=Dis0  P100.elev=E0
  P101.alev=A1  P101.dlev=Dis0  P101.elev=E1
  P110.alev=A1  P110.dlev=Dis1  P110.elev=E0
  P111.alev=A1  P111.dlev=Dis1  P111.elev=E1
  P200.alev=A2  P200.dlev=Dis0  P200.elev=E0
  P201.alev=A2  P201.dlev=Dis0  P201.elev=E1
  P210.alev=A2  P210.dlev=Dis1  P210.elev=E0
  P211.alev=A2  P211.dlev=Dis1  P211.elev=E1
  P300.alev=A3  P300.dlev=Dis0  P300.elev=E0
  P301.alev=A3  P301.dlev=Dis0  P301.elev=E1
  P310.alev=A3  P310.dlev=Dis1  P310.elev=E0
  P311.alev=A3  P311.dlev=Dis1  P311.elev=E1
}

pred LeA[a,b: AgeLevel] {
  a=b or (a=A0 and (b=A1 or b=A2 or b=A3))
       or (a=A1 and (b=A2 or b=A3))
       or (a=A2 and b=A3)
}
pred LeD[a,b: DisLevel] { a=b or (a=Dis0 and b=Dis1) }
pred LeE[a,b: ExtLevel] { a=b or (a=E0 and b=E1) }
pred LeP[pa,pb: Policy] {
  LeA[pa.alev,pb.alev] and LeD[pa.dlev,pb.dlev] and LeE[pa.elev,pb.elev]
}

pred SameAge[p: Policy, d1, d2: Record] {
  (p.alev=A0 and d1.exactAge=d2.exactAge)
  or (p.alev=A1 and d1.decade=d2.decade)
  or (p.alev=A2 and d1.agegroup=d2.agegroup)
  or (p.alev=A3)
}
pred SameDis[p: Policy, d1, d2: Record] {
  (p.dlev=Dis0 and d1.disease=d2.disease) or (p.dlev=Dis1)
}
-- Extra QI: when suppressed, all records share same value -> more collapse
pred SameExt[p: Policy, d1, d2: Record] {
  (p.elev=E0 and d1.disease=d2.disease) or (p.elev=E1)
}
pred SameReleased[p: Policy, d1, d2: Record] {
  SameAge[p,d1,d2] and SameDis[p,d1,d2] and SameExt[p,d1,d2]
}

one sig ReqQ { pairs: Record -> Record }
pred DiseaseOrder[d1,d2: Record] {
  (d1.disease=DM and d2.disease=HT) or (d1.disease=DM and d2.disease=CP)
  or (d1.disease=HT and d2.disease=CP)
}
pred DecadeOrder[d1,d2: Record] {
  (d1.decade=D40s and d2.decade=D60s) or (d1.decade=D40s and d2.decade=D70s)
  or (d1.decade=D60s and d2.decade=D70s)
}
fact ReqQFact {
  ReqQ.pairs = { d1, d2: Record |
    DiseaseOrder[d1,d2]
    or (d1.disease=d2.disease and DecadeOrder[d1,d2])
  }
}

fun Collapse[p: Policy]: Record -> Record {
  { d1, d2: Record | SameReleased[p,d1,d2] }
}
fun UCE[p: Policy]: Record -> Record { ReqQ.pairs & Collapse[p] }
pred Useful[p: Policy] { no UCE[p] }

-- ── COMMANDS ────────────────────────────────────────────────────

-- [1] Search: find any feasible policy
run SearchFeasible {
  some p: Policy | Useful[p]
} for exactly 12 Record, exactly 16 Policy, 7 Int

-- [2] Count feasible policies
run CountFeasible {
  some disj p1, p2, p3, p4, p5, p6: Policy |
    Useful[p1] and Useful[p2] and Useful[p3]
    and Useful[p4] and Useful[p5] and Useful[p6]
} for exactly 12 Record, exactly 16 Policy, 7 Int

-- [3] Diagnostic Persistence
check DiagnosticPersistence {
  all pa, pb: Policy | LeP[pa,pb] implies UCE[pa] in UCE[pb]
} for exactly 12 Record, exactly 16 Policy, 7 Int

-- ================================================================
-- After [1], in Evaluator:
--   #ReqQ.pairs               --> 63
--   { p: Policy | no UCE[p] } --> feasible set
--   #{ p: Policy | no UCE[p] }--> number of feasible policies
-- ================================================================
