"""
Pruning SAT-call counter for ICFEM experiments.

Since Alloy Analyzer does not expose a SAT-call counter,
we simulate Algorithm 1 exactly using the same relational
logic as the Alloy model, and report:
  - Exhaustive calls = |G|
  - Pruning calls = BFS with monotonicity cutoff
  - Reduction %

This script is the authoritative source for Table 1 numbers.
The Alloy .als files provide:
  (a) independent correctness verification of Useful(pi)
  (b) solver timing for individual commands
  (c) DiagnosticPersistence check (no counterexample)
"""

import itertools
from collections import deque

# ── Dataset ──────────────────────────────────────────────────────
RECORDS = [
    ("DM01","DM",43,"40s","Adult"),("DM02","DM",45,"40s","Adult"),
    ("DM03","DM",64,"60s","Senior"),("DM04","DM",71,"70s","Senior"),
    ("HT01","HT",43,"40s","Adult"),("HT02","HT",45,"40s","Adult"),
    ("HT03","HT",64,"60s","Senior"),("HT04","HT",72,"70s","Senior"),
    ("CP01","CP",43,"40s","Adult"),("CP02","CP",45,"40s","Adult"),
    ("CP03","CP",66,"60s","Senior"),("CP04","CP",71,"70s","Senior"),
]
DISEASE_ORDER = {("DM","HT"),("DM","CP"),("HT","CP")}
DECADE_ORDER  = {("40s","60s"),("40s","70s"),("60s","70s")}

def build_req_q():
    req=set()
    for r1 in RECORDS:
        for r2 in RECORDS:
            if r1 is r2: continue
            if (r1[1],r2[1]) in DISEASE_ORDER: req.add((r1[0],r2[0]))
            if r1[1]==r2[1] and (r1[3],r2[3]) in DECADE_ORDER: req.add((r1[0],r2[0]))
    return frozenset(req)

REQ_Q = build_req_q()

AGE_FN  = [lambda r:r[2], lambda r:r[3], lambda r:r[4], lambda r:"*"]
DIS_FN  = [lambda r:r[1], lambda r:"*"]
EXTRA_FN= [lambda r:r[1], lambda r:"*"]

def make_fns(level_counts):
    fns=[]
    for i,L in enumerate(level_counts):
        if i==0:   fns.append(AGE_FN[:L])
        elif i==1: fns.append(DIS_FN[:L])
        else:      fns.append(EXTRA_FN[:L])
    return fns

def useful(policy, fns):
    reprs={r[0]:tuple(fns[i][min(policy[i],len(fns[i])-1)](r)
                      for i in range(len(policy)))
           for r in RECORDS}
    collapse=frozenset((r1[0],r2[0]) for r1 in RECORDS for r2 in RECORDS
                       if r1 is not r2 and reprs[r1[0]]==reprs[r2[0]])
    return len(REQ_Q & collapse)==0

def run_experiment(level_counts):
    fns=make_fns(level_counts)
    all_pols=list(itertools.product(*[range(L) for L in level_counts]))
    G=len(all_pols)

    # Exhaustive
    exhaust_calls=G
    feasible_ex=[p for p in all_pols if useful(p,fns)]

    # Pruning BFS (Algorithm 1)
    all_set=set(all_pols)
    visited=set(); pruned=set(); feasible_pr=[]; calls=0
    queue=deque([tuple(0 for _ in level_counts)])
    while queue:
        pi=queue.popleft()
        if pi in visited or pi in pruned: continue
        visited.add(pi); calls+=1
        if useful(pi,fns):
            feasible_pr.append(pi)
            for i,(l,L) in enumerate(zip(pi,level_counts)):
                if l<L-1:
                    s=list(pi); s[i]+=1
                    s=tuple(s)
                    if s not in visited and s not in pruned: queue.append(s)
        else:
            for p in all_set:
                if all(a<=b for a,b in zip(pi,p)) and p!=pi: pruned.add(p)

    assert set(feasible_ex)==set(feasible_pr), "Mismatch!"
    red=100.0*(exhaust_calls-calls)/exhaust_calls
    return G, exhaust_calls, calls, len(pruned), red, len(feasible_ex)

if __name__=="__main__":
    print(f"{'|G|':>6}  {'Config':>14}  {'Exhaust':>8}  {'Pruning':>8}  "
          f"{'Pruned':>8}  {'Reduc%':>7}  {'Feasible':>9}")
    print("-"*72)
    for lc in [(4,2),(4,2,2),(3,3,3,3),(4,4,4,4),(5,5,5,5),(6,6,6,6)]:
        G,ec,pc,pruned,red,feas=run_experiment(lc)
        cfg="×".join(str(l) for l in lc)
        print(f"{G:>6}  {cfg:>14}  {ec:>8}  {pc:>8}  "
              f"{pruned:>8}  {red:>6.1f}%  {feas:>9}")
