"""Arithmetic and 12-record utility checks; NOT a JISA benchmark rerun."""
from itertools import combinations
import json
from pathlib import Path
records=[(d,a) for d,ages in [('DM',[43,45,64,71]),('HT',[43,45,64,72]),('CP',[43,45,66,71])] for a in ages]
def label(r,kind):
 d,a=r
 return (d, {'none':0,'group':int(a>=60),'decade':a//10,'exact':a}[kind])
def transform(r,i,j):
 d,a=r
 return ([a,a//10,int(a>=60),'*'][i],d if j==0 else '*')
expected_req=[48,60,63,66]
expected_frontiers=[[(3,0)],[(2,0)],[(1,0)],[(0,0)]]
results={}
for kind,expected,frontier_expected in zip(['none','group','decade','exact'],expected_req,expected_frontiers):
 req=[(a,b) for a,b in combinations(range(12),2) if label(records[a],kind)!=label(records[b],kind)]
 counts={(i,j):sum(transform(records[a],i,j)==transform(records[b],i,j) for a,b in req) for i in range(4) for j in range(2)}
 f=[p for p,c in counts.items() if c==0]
 frontier=[p for p in f if not any(p!=q and all(a<=b for a,b in zip(p,q)) for q in f)]
 assert len(req)==expected and frontier==frontier_expected
 results[kind]={'requirements':len(req),'frontier':frontier,'witness_counts':{str(k):v for k,v in counts.items()}}
assert [results['decade']['witness_counts'][str((i,j))] for j in range(2) for i in range(4)]==[0,0,3,15,8,18,27,63]
assert sum([14,1,42,3])==60
assert 14+42==56
for f,b,short,pruned in [(15,1,75,31),(1,3,61,5)]:
 assert 60+f==short and 2*f+b==pruned
print(json.dumps({'checks':'passed','scope':'Arithmetic and independent finite 12-record utility reconstruction only; no JISA timing or Alloy benchmark reproduced.','utility':results},indent=2))
