module symbolic_utility
// Illustrative bounded specification, not the archived JISA benchmark.
sig Age {}
sig Decade {}
sig Disease {}
sig AgeOut {}
sig DiseaseOut {}
one sig Schema { decadeOf: Age -> one Decade }
sig Record {
  age: one Age,
  decade: one Decade,
  disease: one Disease
}
fact DerivedLabels { all r: Record | r.decade = r.age.(Schema.decadeOf) }
sig Policy {
  ageMap: Age -> one AgeOut,
  diseaseMap: Disease -> one DiseaseOut
}
fun Required: Record -> Record {
  {a,b: Record | a.disease != b.disease or a.decade != b.decade}
}
fun Released[p: Policy, r: Record]: AgeOut -> DiseaseOut {
  r.age.(p.ageMap) -> r.disease.(p.diseaseMap)
}
fun UCE[p: Policy]: Record -> Record {
  {a,b: Record | a->b in Required and Released[p,a] = Released[p,b]}
}
pred Useful[p: Policy] { no UCE[p] }
// Kernel inclusion on each source attribute implies factorization on
// that attribute's finite image. This defines a semantic preorder;
// quotient equivalent policies if an antisymmetric policy order is needed.
pred coarser[p,q: Policy] {
  all a,b: Age | a.(p.ageMap) = b.(p.ageMap)
    implies a.(q.ageMap) = b.(q.ageMap)
  all a,b: Disease | a.(p.diseaseMap) = b.(p.diseaseMap)
    implies a.(q.diseaseMap) = b.(q.diseaseMap)
}
assert IrreflexiveRequirement { no (Required & iden) }
assert Persistence {
  all p,q: Policy | coarser[p,q] implies UCE[p] in UCE[q]
}
pred Consistent { some Required and some Policy }
pred MixedOutcomes { some p,q: Policy | Useful[p] and not Useful[q] }
run Consistent for 4
run MixedOutcomes for 4
check IrreflexiveRequirement for 4
check Persistence for 4
